// context.js — "על מי אני עומד בפריוריטי".
//
// ⭐ זה כל מה שהתוסף הזה יודע לעשות, וזו הנקודה.
// בתוסף של עוגן הזהר היה כאן מרשם מסכים ידני: לכל מסך נרשם באיזה מספר שדה
// יושב הטלפון, באיזה השם ובאיזה מספר הלקוח. זה עבד, וזה גם היה החוסם
// מספר 1 של המוצר: כל מסך חדש, ובעצם כל לקוח חדש, דרש סבב אבחון מחדש,
// כי מיקומי השדות נגזרים מהגדרת המסך אצל הלקוח.
//
// כאן אין מרשם. אנחנו אוספים את כל הערכים שנראים בשורה ושולחים אותם
// לשרת כמועמדים. השרת מצליב מול 1,271 הלקוחות שכבר מסונכרנים אצלנו
// ומחזיר מי מהם זה. אין אשף, אין מיפוי, ואין מה לתחזק.
//
// 🔴 מה שכן חשוב לשלוח: גם המספרים וגם הטקסט. התאמה של מספר לבדו
// יכולה להיות מקרית (כמות, מספר שורה, תאריך מספרי), ולכן השרת מסמן אותה
// כ"סביר". היא הופכת לוודאית רק כשגם השם של אותו לקוח מופיע בשורה.
// מסנן שהיה משאיר רק ספרות היה מוריד את כל ההתאמות לוודאות נמוכה.

(function (root) {
  "use strict";

  const D = root.RashalDataset;
  const P = root.RashalPrinter;

  const SERVICE = /Service\.svc/i;
  const ACTIVE_OPS = /FormStartEx|FormKey|FormAutomaticActivate|FormQuery/i;
  const GRID_OPS = /FormStartEx|FormQuery/i;
  const NOISE_OPS = /ExtMessages|ValidPassword|GetRecentUpdates|Login|Logout|KeepAlive|Ping|GetVersion|Language|MarketGate|Feed|UserValuesGet|GeneralHomePage|GeneralHomePageSet|GeneralMailCustnote/i;
  const HOME_OPS = /^HomePage$/i;
  const MIN_BODY = 3000; // תשובות קטנות = פולינג ואישורים

  // ⭐ ביקון הטלמטריה של פריוריטי מכריז על שם המסך בגלוי:
  //   monitor.priority-software.com/monitor/b.aspx?u=...&t=Form%20Start&f=CUSTOMERS
  // זה מזהה מסך חינם, בלי לפרסר SOAP בכלל.
  // 🟡 אבל זו טלמטריה ולא ממשק מתועד, ולכן היא רמז מהיר בלבד: השם מ-SOAP
  // תמיד גובר עליה כשהוא קיים.
  const BEACON = /monitor\.priority-software\.com/i;

  let currentForm = "";
  let beaconForm = "";
  let gridCells = null;
  let lastSig = "";
  const listeners = [];
  let lastKey = "";

  // ── המסמך ──────────────────────────────────────────────
  //
  // ⭐ ההפקה היא של פריוריטי עצמה, בתוך הסשן הפתוח בדפדפן: מריצים את
  // אותה פרוצדורת הדפסה שהעובד מריץ ידנית, ואוספים את כתובת ה-PDF
  // שהיא מחזירה. אין רינדור משלנו, אין רישיון API, ואפס פעימות.
  //
  // 🔴 **ושם הפרוצדורה נלמד מהדפסה ידנית אחת ולא נכתב בקוד.** זה אותו
  // עיקרון שמייתר כאן את מיפוי השדות: מה שנגזר מהגדרת המסך אצל הלקוח
  // נלמד מהמסך, לא מונח מראש. אצל לקוח חדש מדפיסים פעם אחת בכל מסך וזהו.
  const PDF_URL = /^https?:\/\/\S+\.pdf$/i;
  const pdfs = {};      // "form|line" → { url, at }
  let lastRow = "";     // מפתח השורה שמוצגת כרגע
  let lastLine = null;  // ומה שצריך כדי להפיק ממנה
  let lastState = null;
  let lastFields = null;

  function rememberPdf(url) {
    if (!lastRow || !url) return;
    pdfs[lastRow] = { url, at: Date.now() };
  }

  // ⭐ אותו תא בפוקוס שפריוריטי עצמו שלח באותה בקשה.
  // 🔴 זה העיקרון שהחזיק את המוצר בעוגן הזהר: **לשחזר את מה שהדפדפן
  // שלח, לא להמציא מצב.** מצב מורכב משלנו עבד בשני מסכים ונשבר בשלישי,
  // היחיד עם תת-טפסים, כי FormActivate חזר בלי link.
  // הגיבוי היחיד הוא עמודת המפתח (שדה 1), שתמיד מאוכלסת.
  // 🔴🔴 **ההנחה שעמודת המפתח תמיד מאוכלסת נשברה (22/08/2026).**
  // בתעודת משלוח, כשהעובד עמד על עמודה ריקה, מסרנו לפריוריטי תא ריק
  // כמזהה של שורה, והיא החזירה `FormActivate` בלי `link`. מבחוץ זה
  // נראה כמו מוצר גחמני: מתא אחד זה שולח ומתא אחר לא.
  // ⭐ הכלל מעכשיו: **לעולם לא למסור ערך ריק.** אם התא שבפוקוס ריק,
  // לוקחים תא אחר **באותה שורה** שיש בו ערך.
  // 🔴 והערך נלקח תמיד מהרשת שפריוריטי עצמה שלחה, אף פעם לא מומצא:
  // `FormActivate` נושא `<value>` כמו הקלדה, וערך שאינו זהה למה שיושב
  // בתא היה נרשם כעריכה של נתון אמיתי.
  function focus() {
    const st = lastState || {};
    const fields = lastFields || {};
    const line = st.line || lastLine;
    const val = (f) => String(fields[f] == null ? "" : fields[f]).trim();

    // 1. מה שהדפדפן שלח, כשיש בו ערך. זה תמיד העדיף.
    if (st.field && String(st.value || "").trim()) {
      return { field: st.field, curtab: st.curtab, line, value: st.value };
    }

    // 2. אותו תא בדיוק, עם הערך שקראנו מהרשת. קורה כשהמשתמש רק סימן
    //    את התא ופריוריטי שלחה אותו בלי ערך.
    if (st.field && val(st.field)) {
      return { field: st.field, curtab: st.curtab, line, value: val(st.field) };
    }

    // 3. התא הראשון בשורה שיש בו ערך. הנמוך ביותר, כלומר עמודת המפתח
    //    כשהיא מאוכלסת, ואחרת מה שבא אחריה.
    const first = Object.keys(fields)
      .map(Number)
      .filter((n) => !isNaN(n))
      .sort((a, b) => a - b)
      .map(String)
      .find((f) => val(f));
    if (first) return { field: first, curtab: "0", line, value: val(first) };

    // 4. אין ולו תא אחד עם ערך. מוסרים מה שיש, כדי שהשגיאה תהיה מדברת.
    return { field: st.field || "1", curtab: st.curtab || "0", line, value: "" };
  }

  function emit(ctx) {
    for (const fn of listeners) {
      try { fn(ctx); } catch (e) { console.warn("[RashalWA] מאזין נפל:", e); }
    }
  }

  function reset() {
    gridCells = null;
    lastKey = "";
    emit(null);
  }

  function opOf(requestBody) {
    return ((requestBody || "").match(/<s:Body><([A-Za-z0-9]+)/) || [])[1] || "";
  }

  // המועמדים: כל ערך שנראה בשורה שעל המסך.
  // מנוקה רק ממה שבוודאות אינו מפתח (ריק, ארוך מדי, או תאריך).
  function candidatesFrom(fields, state) {
    const out = new Set();
    const add = (v) => {
      const s = String(v == null ? "" : v).trim();
      if (!s || s.length > 60) return;
      // תאריכים לא מזהים לקוח, והם רועשים במיוחד ברשתות.
      if (/^\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}$/.test(s)) return;
      out.add(s);
    };
    for (const k of Object.keys(fields || {})) add(fields[k]);
    if (state && state.value) add(state.value);
    return [...out];
  }

  function handle(m) {
    const url = m.url || "";

    // ⭐ הרמז החינמי: שם המסך מתוך הביקון.
    if (BEACON.test(url)) {
      const f = (url.match(/[?&]f=([^&]+)/) || [])[1];
      if (f) beaconForm = decodeURIComponent(f);
      return;
    }

    const op = opOf(m.requestBody);

    // המדפסת לומדת מכל קריאה אמיתית: כתובת השירות, כותרת ההזדהות, הסשן
    // של הטופס ו-SOAPAction. בלי אלה אי אפשר לשחזר קריאה בקוד.
    try {
      P.remember(m);
      // ⭐ הדפסה ידנית אחת מלמדת את שם הפרוצדורה של המסך הזה, לתמיד.
      // 🔴 מועמדת בלבד. היא תיצרב רק אם ההרצה הזאת החזירה קובץ, אחרת
      // לחיצה על פעולה לא נכונה הייתה נדבקת למסך והתוסף היה מריץ אותה
      // לבד על נתונים אמיתיים.
      if (op === "ProcStartActivate") P.notePending(currentForm, m.requestBody);
      // ⭐ פרמטרי הדיאלוג של ההדפסה הידנית. שונים בין מסכים ואי אפשר לנחשם.
      if (op === "ProcAskPrintOK") P.notePrintArgs(m.requestBody);
      // הרצה שהסתיימה בלי מסמך לא מלמדת כלום.
      if (op === "ProcEnd") P.dropPending();
    } catch (_) {}

    if (!SERVICE.test(url)) return;
    if (!op || NOISE_OPS.test(op)) return;

    // ⭐ תפיסת ה-PDF ברגע שפריוריטי מכריז עליו, גם בהדפסה ידנית של העובד.
    // כאן, ורק כאן, המועמדת הופכת לידע: היא הפיקה מסמך בפועל.
    if (!ACTIVE_OPS.test(op) && /^Proc/i.test(op)) {
      const info = D.analyzeProc(m.responseBody);
      const u = info && info.fields && info.fields.url;
      if (u && PDF_URL.test(u)) {
        try { P.commitPending(); } catch (_) {}
        rememberPdf(u);
      }
      return;
    }

    if (HOME_OPS.test(op)) {
      currentForm = "";
      reset();
      return;
    }

    // 🔴 שם הטופס לא מגיע בכל בקשה (ל-FormActivate ול-Proc אין <form>),
    // ולכן היעדרו אינו "עזבנו את המסך" והוא לא מאפס את ההקשר.
    const form = D.formName(m.requestBody);
    if (form && form !== currentForm) {
      currentForm = form;
      reset();
    }

    if (!ACTIVE_OPS.test(op)) return;

    const body = m.responseBody || "";
    if (GRID_OPS.test(op) && body.length >= MIN_BODY) {
      const sig = url + body.length + op;
      if (sig !== lastSig) {
        lastSig = sig;
        const cells = D.decode(body);
        if (cells && cells.size) gridCells = cells;
      }
    }

    const state = D.requestState(m.requestBody);

    // איזו שורה מוצגת: זו שנבחרה, ואם לא נבחרה כלום, הראשונה ברשת.
    let line = state.line;
    if (!line && gridCells) {
      const lines = D.gridLines(gridCells);
      line = lines.length ? String(lines[0]) : null;
    }
    if (!line && !state.value) return;

    const fields = gridCells ? D.headerFields(gridCells, line) : {};
    const candidates = candidatesFrom(fields, state);
    if (!candidates.length) return;

    // 🔴 אותה שורה שכבר דווחה: לא מדווחים שוב. פריוריטי יורה את אותה
    // שורה שוב ושוב, וכל דיווח מריץ קריאה לשרת ומצייר את החלונית מחדש,
    // כלומר מוחק טקסט שהמשתמש כבר הקליד.
    // 🔴 תמונת השורה מתעדכנת גם כשלא מדווחים שוב. הדילוג שמיד אחרי הוא
    // על **ציור** מיותר, אבל התא שבפוקוס משתנה בכל לחיצה בתוך אותה שורה,
    // וההפקה צריכה את האחרון שנראה ולא את הראשון.
    lastRow = (currentForm || beaconForm) + "|" + line;
    lastLine = line;
    lastState = state;
    lastFields = fields;

    const key = (currentForm || beaconForm) + "|" + line + "|" + candidates.join("");
    if (key === lastKey) return;
    lastKey = key;

    emit({
      form: currentForm || beaconForm || "",
      line,
      candidates,
    });
  }

  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    const m = e.data;
    if (!m || m.source !== "ogen-wa-rashal" || m.kind !== "network") return;
    try {
      handle(m);
    } catch (err) {
      console.warn("[RashalWA] שגיאה בעיבוד קריאה:", err);
    }
  });

  root.RashalContext = {
    onChange(fn) { listeners.push(fn); },

    // ── המסמך שעל המסך ───────────────────────────────────
    // 🔴 שלוש שאלות נפרדות, ולכל אחת הודעה אחרת לעובד: האם המסך נלמד,
    // האם נלכדה כבר קריאה לפריוריטי, והאם כבר יש קובץ לשורה הזאת.
    // מיזוג שלהן ל"אי אפשר" אחד היה משאיר את העובד בלי מה לעשות.
    doc: {
      learned() { return P.procFor(currentForm); },
      ready() { return P.ready(); },
      missing() { return P.missing(); },
      here() { return (lastRow && pdfs[lastRow]) || null; },
      forget() { P.forget(currentForm); },
      /** מה שנלמד אצל אחרים, מהשרת. ראה `adopt` ב-printer.js. */
      adopt(map) { return P.adopt(map); },
      /** מה שנלמד כאן ועוד לא נשלח, כדי שכל החברה תקבל אותו. */
      onLearn(fn) { P.setOnLearn(fn); },

      async produce() {
        const spec = P.procFor(currentForm);
        if (!spec) throw new Error("המסך הזה עוד לא נלמד");
        const f = focus();
        const r = await P.print({
          form: currentForm,
          table: spec.table,
          ename: spec.ename,
          avoidmessages: spec.avoidmessages,
          printArgs: spec.printArgs,
          line: f.line,
          field: f.field,
          curtab: f.curtab,
          value: f.value,
        });
        rememberPdf(r.url);
        return r;
      },

      // 🔴🔴 **הבייטים נמשכים כאן, בדפדפן, ולא בשרת.**
      // הכתובת שפריוריטי מחזירה דורשת את הסשן, ומחוץ לדפדפן היא מחזירה
      // **200 עם דף ההתחברות של פריוריטי** ולא שגיאה. נמדד חי
      // (22/08/2026) על מסמך אמיתי: `text/html`, 16,563 בייט, `priform`.
      // השרת בדק רק שהקוד תקין, ולכן העלה ל-heyy דף התחברות בשם המסמך.
      // ⭐ התוסף רץ בתוך הסשן, ולכן הוא היחיד שיכול להביא את הקובץ.
      async bytes() {
        const pdf = (lastRow && pdfs[lastRow]) || null;
        if (!pdf || !pdf.url) throw new Error("אין מסמך להביא");

        const res = await fetch(pdf.url, { credentials: "include" });
        if (!res.ok) throw new Error("פריוריטי החזירה " + res.status + " על המסמך");

        const buf = new Uint8Array(await res.arrayBuffer());

        // 🔴 אותה בדיקה גם כאן, ולא רק בשרת. עצירה בדפדפן חוסכת העלאה
        // מיותרת, ובעיקר אומרת לעובד את האמת: הסשן פג, לא הקובץ פגום.
        if (buf.length < 5 || String.fromCharCode(buf[0], buf[1], buf[2], buf[3], buf[4]) !== "%PDF-") {
          console.warn("[RashalWA] מה שהתקבל אינו PDF:", {
            url: pdf.url,
            size: buf.length,
            type: res.headers.get("content-type"),
          });
          throw new Error("פריוריטי החזירה דף במקום מסמך. רענן את פריוריטי והדפס שוב");
        }

        // 🔴 `btoa` על מחרוזת ארוכה דרך `apply` מפוצץ את המחסנית, ולכן
        // ממירים בגושים. הבייטים כאן בינאריים (0 עד 255) ולכן `btoa`
        // תקין עליהם, בניגוד לטקסט עברי. ראה את התאום ב-`printer.js`.
        let bin = "";
        for (let i = 0; i < buf.length; i += 0x8000) {
          bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
        }
        return { base64: btoa(bin), url: pdf.url, size: buf.length };
      },
    },

    // לאבחון בקונסולה בלבד.
    debug() { return { currentForm, beaconForm, cells: gridCells ? gridCells.size : 0 }; },
  };
})(window);
