// config.js — כל מה שקושר את התוסף ללקוח מסוים, במקום אחד.
//
// ⭐ **נוצר על ידי `build.mjs` מתוך `clients/rashal.json`.** אין לערוך ביד.
//
// 🔴 `supabaseAnon` הוא מפתח ציבורי, אותו אחד שיושב ממילא בקוד של
// הדשבורד בדפדפן. הוא אינו מקנה גישה בלי משתמש מחובר, וכל ההרשאות
// נאכפות ב-RLS. לעולם לא להכניס לכאן מפתח service role.

self.OGEN_WA_CONFIG = {
  id: "rashal",
  brandName: "ר.שעל",
  supabaseUrl: "https://kukstfxtznymfkirdmty.supabase.co",
  supabaseAnon: "sb_publishable_y1Yu79WEqhtCckKV3JrVTQ_7t4l09wD",
  api: "https://rashal-dashboard.vercel.app",
  emailDomain: "rashal.internal",
};
