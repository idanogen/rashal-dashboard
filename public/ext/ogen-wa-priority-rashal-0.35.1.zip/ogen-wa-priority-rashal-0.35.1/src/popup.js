// popup.js — מסך ההתחברות של התוסף.
//
// 🔴 הסיסמה לא נשמרת כאן ולא נוגעת ב-storage. היא עוברת ל-service worker,
// משם ישירות ל-Supabase, ומה שחוזר ונשמר הוא טוקן בלבד.

const $ = (id) => document.getElementById(id);

function send(type, payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, payload }, (r) => resolve(r || { ok: false, error: "אין תשובה מהתוסף." }));
  });
}

function show(signedIn, user) {
  $("signedout").hidden = signedIn;
  $("signedin").hidden = !signedIn;
  $("who").textContent = user && user.email ? user.email : "";
}

async function refreshView() {
  const r = await send("WHO");
  show(Boolean(r && r.signedIn), r && r.user);
}

async function doSignIn() {
  const btn = $("signin");
  const err = $("error");
  err.hidden = true;
  btn.disabled = true;
  btn.textContent = "מתחבר…";

  const r = await send("SIGN_IN", { handle: $("handle").value, password: $("password").value });

  btn.disabled = false;
  btn.textContent = "התחבר";
  $("password").value = "";

  if (r && r.ok) {
    show(true, r.user);
    return;
  }
  err.textContent = (r && r.error) || "ההתחברות נכשלה.";
  err.hidden = false;
}

$("signin").addEventListener("click", doSignIn);
$("password").addEventListener("keydown", (e) => { if (e.key === "Enter") doSignIn(); });
$("handle").addEventListener("keydown", (e) => { if (e.key === "Enter") $("password").focus(); });
$("signout").addEventListener("click", async () => {
  await send("SIGN_OUT");
  refreshView();
});

// הגרסה מהמניפסט, לא מחרוזת כתובה ביד שנשכחת מאחור.
$("version").textContent = "גרסה " + chrome.runtime.getManifest().version;

refreshView();
