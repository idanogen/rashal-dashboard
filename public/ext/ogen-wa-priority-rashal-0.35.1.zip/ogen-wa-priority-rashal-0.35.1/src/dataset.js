// dataset.js — עותק של מפענח ה-DataSet מהתוסף של עוגן הזהר.
// המקור: ~/Idan-HQ/company/wa-priority/extension/src/dataset.js
// 🔴 שינוי כאן שאינו מגיע גם לשם (או להפך) יוצר שני מפענחים שמתפצלים בשקט.
//
// dataset.js — פענוח ה-DataSet הקנייני של פריוריטי.
//
// המבנה, כפי שפוענח ואומת בפרודקשן במהלך 06-07/2026:
//   Priority Web הוא GWT/SOAP ולא OData. כל הקריאות הן POST ל-/wcf/Service.svc,
//   והנתונים מגיעים Base64 בתוך <...Result>.
//   אחרי הפענוח: טוקנים מופרדים ב-"\n\t\r", וכל תא הוא
//     "<table>\t<field>\t<line>\t0\t0\t<value>"
//   טבלה 1 = כותרת המסמך או הרשת (line = אינדקס השורה ברשת, מ-1).
//   טבלה 2 = שורות המסמך.
//
// 🔴 latin1 ולא utf-8. הפענוח בקופיילוט נעשה ב-latin1 והוא מה שאומת;
// atob בדפדפן מחזיר בדיוק את זה (בייט לתו).

(function (root) {
  "use strict";

  const HEB = /[֐-׿]/;

  // ⭐ אומת חי 17/08/2026: **פריוריטי מקודד את המחרוזות ב-UTF-8** בתוך הבלוק,
  // ואילו atob מחזיר בייטים כתווים (latin1). בלי הנירמול הזה כל שם עברי יוצא
  // ג'יבריש מסוג "××¢××××ª". ההוכחה הגיעה מה-statexml, שבו הערך חזר לא מנורמל.
  // 🔴 הנירמול חייב לחול על **כל** מקור טקסט שמגיע מפריוריטי, לא רק על
  // ה-DataSet. הוא נשאר הגנתי (מנסה, ומעדיף רק אם באמת יצאה עברית) כדי
  // לא להישבר אם סביבה אחרת תתנהג אחרת.
  function normalize(v) {
    if (!v || HEB.test(v)) return v;
    if (!/[-ÿ]/.test(v)) return v;
    try {
      const bytes = Uint8Array.from(v, (c) => c.charCodeAt(0) & 0xff);
      const dec = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
      return HEB.test(dec) ? dec : v;
    } catch (_) {
      return v;
    }
  }

  // מפענח את כל בלוקי ה-base64 בתשובה ומחזיר את זה שהניב הכי הרבה תאים.
  // 🔴 למה "הכי הרבה" ולא "הראשון": תשובת טעינת-רשת מכילה כמה בלוקים,
  // והראשון אינו בהכרח ה-DataSet של הרשת.
  function decode(responseBody) {
    const blobs = (responseBody || "").match(/[A-Za-z0-9+/]{300,}={0,2}/g);
    if (!blobs) return null;
    let best = null;
    for (const blob of blobs) {
      let decoded;
      try {
        decoded = atob(blob);
      } catch (_) {
        continue;
      }
      if (decoded.indexOf("\t") < 0) continue;
      const cells = new Map(); // "table.field.line" -> value
      for (const tok of decoded.split("\n\t\r")) {
        const p = tok.split("\t");
        if (p.length >= 6 && /^\d+$/.test(p[0]) && /^\d+$/.test(p[1]) && /^\d+$/.test(p[2])) {
          cells.set(p[0] + "." + p[1] + "." + p[2], normalize(p.slice(5).join("\t")));
        }
      }
      if (cells.size && (!best || cells.size > best.size)) best = cells;
    }
    return best;
  }

  // כל התאים של טבלה 1 בשורה מסוימת: field -> value
  function headerFields(cells, line) {
    const out = {};
    if (!cells) return out;
    for (const [k, v] of cells) {
      const p = k.split(".");
      if (p[0] === "1" && p[2] === String(line)) out[p[1]] = v;
    }
    return out;
  }

  // כל השורות שקיימות בטבלה 1 (אינדקסים של הרשת), ממוינות.
  function gridLines(cells) {
    const set = new Set();
    if (!cells) return [];
    for (const k of cells.keys()) {
      const p = k.split(".");
      if (p[0] === "1") set.add(Number(p[2]));
    }
    return [...set].sort((a, b) => a - b);
  }

  // 🔎 צייד טלפונים: סורק את **כל** הטבלאות, לא רק את טבלה 1.
  // נבנה כדי לסגור ויכוח אמיתי: עידן רואה טלפון בהזמנת לקוח, ובשורת הרשת
  // (טבלה 1) אין אחד. ההשערה היא שהוא יושב בלשונית "פרטי הלקוח", כלומר
  // בטבלה אחרת. הפונקציה מחזירה קואורדינטות מלאות כדי שאפשר יהיה לקבע.
  function findPhones(cells) {
    const out = [];
    if (!cells) return out;
    const PHONE = /^0\d{8,9}$/;
    for (const [k, v] of cells) {
      const val = (v || "").trim().replace(/[\s\-]/g, "");
      if (!PHONE.test(val)) continue;
      const p = k.split(".");
      out.push({ table: p[0], field: p[1], line: p[2], value: val });
    }
    return out;
  }

  // 🔎 מנתח תשובת פרוצדורה.
  //
  // ⭐ מבנה התשובה פוענח ב-17/08 והוא **שונה** מה-DataSet של הרשת. זהו עץ
  // מסודר של טוקנים מופרדים ב-"\n\t\r", בשלשות:
  //     S · <עומק> · <שם> · <ערך>   ...   V · <ערך>   ...   E · <שם>
  // דוגמה אמיתית מתשובת FormActivate של הדפסת תעודת משלוח:
  //     S 3 table DOCUMENTS ... S 3 link c:/tmp/a0377200012 ... S 3 linkid 8296:...
  //
  // ⭐⭐ **המנגנון: פריוריטי מייצר את המסמך כקובץ זמני בשרת ומחזיר `link`
  // ו-`linkid`.** הוא לא זורם בייטים ולא מוריד ישירות, ולכן לחיצה על הדפסה
  // אינה מייצרת שום בקשת רשת של PDF.
  const KEYS = /^(link|linkid|step|title|exec|filename|dfilename|file|url|format|session|hasextfiles|table|error|message)$/i;

  function analyzeProc(responseBody) {
    const raw = responseBody || "";
    const out = {};
    const fields = {};
    let pdfInside = false;
    const urls = [];

    for (const blob of raw.match(/[A-Za-z0-9+/]{200,}={0,2}/g) || []) {
      let dec;
      try { dec = atob(blob); } catch (_) { continue; }
      // חתימת PDF: אם היא כאן, הקובץ עצמו עובר בתשובה
      if (dec.indexOf("%PDF") >= 0) pdfInside = true;

      const toks = dec.split("\n\t\r");
      for (let i = 0; i < toks.length - 3; i++) {
        if (toks[i] !== "S") continue;
        const name = (toks[i + 2] || "").trim();
        const val = (toks[i + 3] || "").trim();
        if (!name || !val) continue;
        const interesting = KEYS.test(name) || /\.(pdf|xlsx?|docx?|html?|csv)\b|^[a-z]:[\\/]|\/tmp\/|https?:\/\//i.test(val);
        if (interesting && !fields[name]) fields[name] = normalize(val).slice(0, 160);
      }
      for (const u of dec.match(/https?:\/\/[^\s"'<>&\x00-\x1f]{12,}/g) || []) {
        if (!/schemas\.xmlsoap|oasis-open|tempuri|w3\.org/i.test(u)) urls.push(u);
      }
    }

    if (pdfInside) out.pdfInside = true;
    if (Object.keys(fields).length) out.fields = fields;
    if (urls.length) out.urls = [...new Set(urls)].slice(0, 6);
    return out;
  }

  // 🔴🔴 מיסוך פרטי הזדהות. **חובה לפני כל שימוש בגוף בקשה.**
  // כל בקשת SOAP של פריוריטי נושאת UsernameToken עם הסיסמה. גוף בקשה שנכנס
  // לאבחון, ללוג, ללוח או לצ'אט חייב לעבור כאן קודם. זו פדיחה שכבר נעשתה
  // פעם אחת בקופיילוט (07/06) ותוקנה, ואסור לחזור עליה.
  function maskSecrets(requestBody) {
    return (requestBody || "")
      .replace(/(<[\w:]*Password[^>]*>)[\s\S]*?(<\/[\w:]*Password>)/gi, "$1***$2")
      .replace(/(<[\w:]*Nonce[^>]*>)[\s\S]*?(<\/[\w:]*Nonce>)/gi, "$1***$2")
      .replace(/(<[\w:]*Username[^>]*>)[\s\S]*?(<\/[\w:]*Username>)/gi, "$1***$2");
  }

  // 🔎 צילום בקשה, לצורך שחזור הפעולה בקוד.
  // מחזיר את הבקשה ממוסכת, ואת ה-statexml שלה מפוענח, כי שם יושבים
  // הפרמטרים האמיתיים של השלב.
  function captureRequest(requestBody) {
    const masked = maskSecrets(requestBody);
    const out = { body: masked.slice(0, 6000) };
    const m = (requestBody || "").match(/<statexml>([^<]+)<\/statexml>/);
    if (m) {
      try { out.statexml = normalize(atob(m[1])).slice(0, 3000); } catch (_) {}
    }
    return out;
  }

  // ה-statexml של הבקשה מקודד base64 ומכיל את השורה שנבחרה ואת ערך התא.
  function requestState(requestBody) {
    const m = (requestBody || "").match(/<statexml>([^<]+)<\/statexml>/);
    if (!m) return {};
    let xml;
    try {
      xml = atob(m[1]);
    } catch (_) {
      return {};
    }
    const line = xml.match(/<line>(\d+)<\/line>/);
    const value = xml.match(/<value>([\s\S]*?)<\/value>/);
    // 🔴 גם field ו-curtab, ולא רק line.
    // הרכבה של מצב משלנו (שדה תאריך + לשונית 0) נכשלה במסך עם תת-טפסים:
    // `FormActivate` לא החזיר link. מה שעובד הוא לשחזר את **המצב שפריוריטי
    // עצמו שלח**, בדיוק כמו שמיחזרנו את כותרת ההזדהות במקום להמציא אותה.
    const field = xml.match(/<field>(\d+)<\/field>/);
    const curtab = xml.match(/<curtab>(\d+)<\/curtab>/);
    return {
      field: field ? field[1] : null,
      curtab: curtab ? curtab[1] : null,
      line: line ? line[1] : null,
      // 🔴 גם כאן חובה נירמול. זה המקום שבו הבאג התגלה ב-17/08.
      value: value ? normalize(value[1].trim()) : null,
    };
  }

  // ⭐ שם הטופס יושב בבקשה עצמה. זה הסימן האמין לזיהוי המסך, בצד לקוח,
  // ובלי לנחש לפי תוכן התשובה.
  function formName(requestBody) {
    const m = (requestBody || "").match(/<form>([A-Za-z0-9_]+)<\/form>/);
    return m ? m[1] : null;
  }

  root.RashalDataset = { decode, headerFields, gridLines, requestState, formName, normalize, findPhones, analyzeProc, maskSecrets, captureRequest };
})(window);
