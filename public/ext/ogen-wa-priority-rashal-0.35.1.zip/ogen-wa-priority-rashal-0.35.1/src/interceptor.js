// interceptor.js — עותק של המנוע שנבנה לתוסף של עוגן הזהר.
// המקור: ~/Idan-HQ/company/wa-priority/extension/src/interceptor.js
// 🔴 שינוי כאן שאינו מגיע גם לשם (או להפך) יוצר שני מנועים שמתפצלים בשקט.
//
// interceptor.js — רץ ב-MAIN world של העמוד.
// תופס כל קריאת רשת של פריוריטי (בקשה + תשובה) ומשדר החוצה ב-postMessage.
//
// 🔴 עיקרון-על: לעולם לא לחסום ולא להאט את הקריאה של פריוריטי עצמה.
// הלכידה תמיד ברקע, על עותק, ואחרי שהתשובה כבר הוחזרה לדף.
// (בקופיילוט היה כאן `await res.clone().text()` לפני ה-return, וזה יכול היה
// לתקוע streaming. אל תחזיר לשם.)
(function () {
  const MAX_CAPTURE = 5_000_000; // תשובות ענק (הורדות/קבצים) לא משכפלים

  function post(data) {
    try {
      // 🔴 יעד "*" חובה. חלק ממסכי פריוריטי רצים ב-iframe עם origin אטום
      // (location.origin === "null"), ואז postMessage ליעד מפורש לא נמסר
      // ל-bridge והפאנל פשוט לא עולה. הקשחה נגד דליפה נעשית ב-bridge
      // (בדיקת e.source + חתימת source), לא דרך targetOrigin.
      window.postMessage(
        Object.assign({ source: "ogen-wa-rashal", kind: "network", ts: Date.now() }, data),
        "*"
      );
    } catch (_) {}
  }

  // ---- fetch ----
  const origFetch = window.fetch;
  window.fetch = function (...args) {
    const p = origFetch.apply(this, args); // מוחזר כפי שהוא, פריוריטי לא מחכה לנו
    p.then((res) => {
      try {
        const url = typeof args[0] === "string" ? args[0] : args[0] && args[0].url;
        const method = ((args[1] && args[1].method) || (args[0] && args[0].method) || "GET").toUpperCase();
        const requestBody = (args[1] && args[1].body) || null;
        // 🔎 כותרות הבקשה. נדרשות כדי לשחזר קריאה בקוד: WCF דורש SOAPAction,
        // ובלעדיה הקריאה נדחית. הן אינן מכילות סוד (הסיסמה יושבת בגוף).
        let requestHeaders = null;
        try {
          const h = args[1] && args[1].headers;
          if (h) {
            requestHeaders = {};
            if (typeof h.forEach === "function" && !Array.isArray(h)) h.forEach((v, k) => { requestHeaders[k] = v; });
            else Object.assign(requestHeaders, h);
          }
        } catch (_) {}
        const cl = Number(res.headers.get("content-length") || 0);
        const ct = res.headers.get("content-type") || "";
        // 🔎 גם כשלא מעתיקים את הגוף, מדווחים שהקריאה קרתה.
        // בלי זה הורדת PDF הייתה נעלמת לגמרי, ואיתה הדרך לצרף קובץ.
        if (cl > MAX_CAPTURE || /pdf|octet-stream|zip|image\//i.test(ct)) {
          post({ method, url, requestBody: null, requestHeaders, responseBody: null, contentType: ct, size: cl });
          return;
        }
        res.clone().text().then((responseBody) => {
          if (responseBody && responseBody.length <= MAX_CAPTURE) {
            post({ method, url, requestBody, requestHeaders, responseBody, contentType: ct });
          }
        }).catch(() => {});
      } catch (_) {}
    }).catch(() => {});
    return p;
  };

  // ---- יצירת Blob URL ----
  // 🔎 אם פריוריטי מקבל את בייטי המסמך בתוך תשובת SOAP ובונה מהם קובץ בדפדפן,
  // זה יקרה כאן ובשום מקום אחר. הסוג והגודל מספיקים כדי לדעת שזה ה-PDF,
  // והכתובת מאפשרת למשוך אותו בלי לבקש שוב מפריוריטי.
  const origCreateURL = URL.createObjectURL;
  if (origCreateURL) {
    URL.createObjectURL = function (obj) {
      const url = origCreateURL.apply(this, arguments);
      try {
        post({
          method: "BLOB",
          url: String(url || ""),
          contentType: (obj && obj.type) || "",
          size: (obj && obj.size) || 0,
          responseBody: null,
        });
      } catch (_) {}
      return url;
    };
  }

  // ---- פתיחת חלון/לשונית ----
  // 🔎 פריוריטי עשוי להגיש מסמך מודפס בניווט ולא בקריאת רשת. בלי הקרס הזה
  // המסלול הזה בלתי נראה לחלוטין.
  const origOpen2 = window.open;
  window.open = function (url) {
    try { post({ method: "OPEN", url: String(url || ""), responseBody: null }); } catch (_) {}
    return origOpen2.apply(this, arguments);
  };

  // ---- XMLHttpRequest ----
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__ogenwa = { method: method, url: url, headers: {} };
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    try { if (this.__ogenwa) this.__ogenwa.headers[k] = v; } catch (_) {}
    return origSetHeader.apply(this, arguments);
  };
  /**
   * 🔴🔴 **`InvalidStateError` שמופיע כאן אינו שלנו, וכדאי שזה יהיה כתוב.**
   * נצפה אצל עידן ב-25/08/2026 ברשימת השגיאות של התוסף:
   *   `Failed to execute 'send' on 'XMLHttpRequest': The object's state
   *    must be OPENED` · `src/interceptor.js:135`
   *
   * מה שקורה: קוד של פריוריטי קורא ל-`send()` על XHR שאינו במצב OPENED
   * (בדרך כלל שליחה שנייה על אותו אובייקט, או אחרי `abort`). הקריאה
   * הנייטיבית זורקת, והשגיאה עוברת דרכנו כי אנחנו הפריים האחרון בערימה.
   *
   * ⭐ **שתי ראיות שזה של הדף ולא שלנו:** התוסף כולו אינו יוצר אף XHR
   * (הוא משתמש ב-`fetch` בלבד), ו-"Uncaught (in promise)" פירושו שהקורא
   * יושב בתוך שרשרת הבטחות, בזמן שהעטיפה כאן סינכרונית לגמרי.
   *
   * 🔴 **ולא בולעים אותה.** קוד של הדף עשוי להסתמך על הזריקה, ובליעה
   * שקטה היא בדיוק סוג הכשל שאנחנו נלחמים בו במקומות אחרים. מה שכן
   * נעשה: לא לתלות מאזין על אובייקט שממילא לא ייצא לדרך, ולומר בקונסולה
   * פעם אחת מי הקורא, כדי שהאבחון הבא ייקח שנייה.
   */
  let warnedBadState = false;
  XMLHttpRequest.prototype.send = function (body) {
    const self = this;
    if (this.readyState !== 1) {
      if (!warnedBadState) {
        warnedBadState = true;
        try {
          console.warn(
            "[OgenWA] send() נקרא על XHR שאינו OPENED. הקריאה מגיעה מקוד של " +
            "פריוריטי ולא מהתוסף, והשגיאה שתופיע היא של הדף.",
          );
        } catch (_) {}
      }
      return origSend.apply(this, arguments);
    }
    this.addEventListener("load", function () {
      try {
        // responseText זורק כש-responseType אינו טקסט.
        // 🔎 אבל עדיין מדווחים על הקריאה עצמה, כי דווקא היא עשויה להיות ה-PDF.
        const rt = self.responseType;
        if (rt && rt !== "text") {
          post({
            method: ((self.__ogenwa && self.__ogenwa.method) || "GET").toUpperCase(),
            url: self.__ogenwa && self.__ogenwa.url,
            requestBody: null,
            responseBody: null,
            contentType: (function () { try { return self.getResponseHeader("content-type") || ""; } catch (_) { return ""; } })(),
            binary: true,
          });
          return;
        }
        post({
          method: ((self.__ogenwa && self.__ogenwa.method) || "GET").toUpperCase(),
          url: self.__ogenwa && self.__ogenwa.url,
          requestBody: body || null,
          requestHeaders: (self.__ogenwa && self.__ogenwa.headers) || null,
          responseBody: self.responseText,
        });
      } catch (_) {}
    });
    return origSend.apply(this, arguments);
  };
})();
