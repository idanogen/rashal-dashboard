// background.js — service worker. כאן, ורק כאן, יוצאת בקשה מהתוסף.
//
// שני תפקידים:
//   1. **הסשן.** העובד מתחבר פעם אחת בפופאפ, עם אותו שם משתמש וסיסמה
//      של הדשבורד. הטוקן נשמר כאן ומתחדש לבד.
//   2. **הגישור.** כל קריאה לשרת שלנו עוברת דרך כאן.
//
// 🔴 למה דרך ה-service worker ולא ישירות מהחלונית: החלונית רצה על
// `p.priority-connect.online`, כלומר origin זר. קריאה משם לשרת שלנו היא
// חוצת-מקורות ותיחסם. ה-service worker מחזיק את `host_permissions`
// ופטור מזה. **וזה גם אומר שהטוקן לא יושב אף פעם בדף של פריוריטי.**
//
// 🔴 המפתח למטה הוא ה-publishable key של Supabase, ציבורי לחלוטין (הוא
// כבר משודר בבאנדל של הדשבורד). ה-service role key לעולם לא כאן.

// ⭐ **כל מה שקושר ללקוח מסוים יושב ב-`config.js`, ורק שם.** התוסף הוא
// מוצר מדף של עוגן סולושנס, ולקוח חדש הוא קובץ אחד ב-`clients/` ובנייה
// אחת, לא חיפוש והחלפה בקוד.
importScripts("./config.js");
const CFG = self.OGEN_WA_CONFIG;
const SUPABASE_URL = CFG.supabaseUrl;
const SUPABASE_ANON = CFG.supabaseAnon;
const API = CFG.api;
const EMAIL_DOMAIN = CFG.emailDomain;
const BRAND = CFG.brandName;

// ── מיפוי שם משתמש למייל הסינתטי ────────────────────────
// 🔴 חייב להיות זהה בית-בבית ל-`src/lib/username.ts` בדשבורד ול-
// `usernameToEmail` ב-`api/admin-users.ts`. שלושה מימושים של אותו מיפוי,
// ומי שיסטה יגרום לכך ששם משתמש עברי ייכנס לדשבורד ולא ייכנס כאן.
const ASCII_HANDLE = /^[a-zA-Z0-9._-]+$/;

async function handleToEmail(raw) {
  const username = String(raw || "").trim().normalize("NFC").toLowerCase();
  if (!username) return "";
  if (username.includes("@")) return username;
  if (ASCII_HANDLE.test(username)) return username + "@" + EMAIL_DOMAIN;
  const bytes = new TextEncoder().encode(username);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  const hex = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
  return "u" + hex.slice(0, 40) + "@" + EMAIL_DOMAIN;
}

// ── הסשן ─────────────────────────────────────────────────
async function getSession() {
  const s = await chrome.storage.local.get(["session"]);
  return s.session || null;
}

async function setSession(session) {
  if (session) await chrome.storage.local.set({ session });
  else await chrome.storage.local.remove("session");
}

function sessionFromToken(json) {
  return {
    accessToken: json.access_token,
    refreshToken: json.refresh_token,
    // 🔴 רגע התפוגה נשמר כזמן מוחלט ולא כ"עוד כך וכך שניות". מחשב שנרדם
    // ומתעורר אחרי שעתיים היה ממשיך לספור מהמקום שבו נעצר, ומגיש טוקן מת.
    expiresAt: Date.now() + (Number(json.expires_in) || 3600) * 1000,
    user: json.user ? { id: json.user.id, email: json.user.email } : null,
  };
}

/**
 * 🔴🔴 **הודעה לכל לשונית פריוריטי פתוחה שמצב ההתחברות השתנה.**
 *
 * עידן, 25/08/2026: "גם אחרי שאני מתחבר לתוסף הוא ממשיך לבקש להתחבר.
 * לדעתי אם ארענן את הפריוריטי זה יעבוד, אבל לא בטוח." הוא צדק בשני
 * הדברים, וזה בדיוק הבאג: החלונית שאלה `WHO` פעם אחת בטעינת הדף ולא
 * שאלה שוב לעולם. מי שהתחבר בפופאפ נשאר מול "צריך להתחבר פעם אחת" עד
 * שרענן ידנית, ולא הייתה שום דרך לדעת שזה מה שצריך לעשות.
 *
 * ⭐ בלי הרשאת `tabs` חדשה: `host_permissions` על פריוריטי מספיקות
 * לשאילתה הזאת, והוספת הרשאה בעדכון הייתה משביתה את התוסף עד שהמשתמש
 * מאשר אותה מחדש.
 *
 * 🔴 וכשלון כאן אינו קריטי: לחלונית יש גם דגימה עצמית.
 */
async function announceAuth(signedIn) {
  try {
    const tabs = await chrome.tabs.query({ url: "https://*.priority-connect.online/*" });
    for (const t of tabs) {
      if (t.id == null) continue;
      // לשונית בלי מאזין (עדיין לא נטענה) דוחה, וזה תקין.
      Promise.resolve(chrome.tabs.sendMessage(t.id, { type: "AUTH_CHANGED", signedIn }))
        .catch(() => {});
    }
  } catch (_) { /* החלונית תדגום בעצמה */ }
}

async function signIn(handle, password) {
  const email = await handleToEmail(handle);
  if (!email || !password) return { ok: false, error: "צריך שם משתמש וסיסמה." };

  try {
    const res = await fetch(SUPABASE_URL + "/auth/v1/token?grant_type=password", {
      method: "POST",
      headers: { apikey: SUPABASE_ANON, "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || !json.access_token) {
      return { ok: false, error: "שם המשתמש או הסיסמה לא נכונים." };
    }
    const session = sessionFromToken(json);
    await setSession(session);
    announceAuth(true);
    return { ok: true, user: session.user };
  } catch (e) {
    return { ok: false, error: "אין חיבור לשרת: " + ((e && e.message) || e) };
  }
}

async function refresh(session) {
  try {
    const res = await fetch(SUPABASE_URL + "/auth/v1/token?grant_type=refresh_token", {
      method: "POST",
      headers: { apikey: SUPABASE_ANON, "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: session.refreshToken }),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || !json.access_token) {
      // 🔴 רענון שנכשל = הסשן מת. מוחקים, כדי שהמשתמש יראה "התחבר"
      // ולא ישב מול חלונית ריקה שמסתובבת.
      await setSession(null);
      return null;
    }
    const next = sessionFromToken(json);
    await setSession(next);
    return next;
  } catch (_) {
    return null; // תקלת רשת רגעית: לא מוחקים את הסשן
  }
}

/** טוקן תקף, עם רענון מקדים דקה לפני התפוגה. */
async function validToken() {
  let session = await getSession();
  if (!session) return null;
  if (Date.now() > session.expiresAt - 60_000) {
    session = await refresh(session);
    if (!session) return null;
  }
  return session.accessToken;
}

// ── קריאה לשרת שלנו ──────────────────────────────────────
async function call(path, init, retryOn401 = true, timeoutMs = 15000) {
  const token = await validToken();
  if (!token) return { ok: false, status: 401, error: "not_signed_in" };

  // 🔴 שעון עצר. בלעדיו בקשה שנתקעת משאירה את החלונית על "טוען…" לנצח,
  // וזה נראה בדיוק כמו חלונית מקולקלת. הלקח הזה כבר עלה שני סבבי אבחון
  // בתוסף של עוגן הזהר.
  //
  // 🔴 **אבל שעון עצר קצר מדי גרוע מאין שעון עצר.** שליחה עם מסמך נושאת
  // את הבייטים של ה-PDF, והשרת מעלה אותם ל-heyy ואז שולח. 15 שניות לא
  // מספיקות לזה, והתוצאה הייתה **הודעה שיצאה ללקוח בזמן שהחלונית כותבת
  // "לא הייתה תשובה"** — כלומר העובד שולח שוב, והלקוח מקבל פעמיים.
  // לכן המסלול הזה מקבל חלון ארוך.
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);

  try {
    const res = await fetch(API + path, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
        ...(init && init.headers),
      },
      signal: ctrl.signal,
    });

    if (res.status === 401 && retryOn401) {
      const s = await getSession();
      if (s && (await refresh(s))) return call(path, init, false, timeoutMs);
      return { ok: false, status: 401, error: "not_signed_in" };
    }

    const json = await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, data: json };
  } catch (e) {
    // 🔴 המספר בהודעה נגזר מהחלון בפועל. טקסט קבוע "15 שניות" היה משקר
    // במסלול המסמך, שמחכה הרבה יותר.
    const msg = e && e.name === "AbortError"
      ? "לא הייתה תשובה תוך " + Math.round(timeoutMs / 1000) + " שניות"
      : (e && e.message) || String(e);
    return { ok: false, status: 0, error: msg };
  } finally {
    clearTimeout(timer);
  }
}

// ── החיווי: כמה לקוחות מחכים לתשובה ──────────────────────
//
// ⭐ **הנקודה יושבת על אייקון התוסף עצמו**, ולכן היא נראית גם כשהחלונית
// סגורה לגמרי וגם כשעידן עומד על לשונית אחרת. זו בדיוק הבקשה: לדעת
// שנכנסה הודעה בלי לחפש אותה.
//
// 🔴 **דגימה ולא חיבור חי, ובכוונה.** ה-service worker של כרום נכבה
// אחרי חצי דקה של שקט, ולכן חיבור מתמשך היה מת בשקט אחרי הפעם הראשונה.
// `chrome.alarms` שורד את הכיבוי ומעיר את ה-worker מחדש, וזה המנגנון
// היחיד כאן שאפשר לסמוך עליו.
//
// 🔴 ותקרה נוספת: המרווח המינימלי של alarms הוא דקה. לכן זו דקה, ולא
// 30 שניות כפי שתכננתי. כשהחלונית פתוחה היא מרעננת לבד מהר יותר.
const BADGE_ALARM = "rwa-waiting";

async function refreshBadge() {
  const r = await call("/api/conversation?tab=waiting&limit=1", { method: "GET" }, true, 12000);

  // 🔴 **לא מחובר אינו אפס.** אפס אומר "אין ממתינים" והוא מידע; חוסר
  // חיבור הוא היעדר מידע, והצגתו כאפס הייתה משדרת שקט שאין לו כיסוי.
  if (!r || r.status === 401) {
    await chrome.action.setBadgeText({ text: "" });
    await chrome.action.setTitle({ title: BRAND + " וואטסאפ · לא מחובר" });
    return;
  }
  if (!r.ok || !r.data || !r.data.ok) return;

  const n = Number((r.data.counts && r.data.counts.waiting) || 0);
  await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
  await chrome.action.setBadgeText({ text: n > 0 ? (n > 99 ? "99+" : String(n)) : "" });
  await chrome.action.setTitle({
    title: n > 0 ? n + " לקוחות מחכים לתשובה" : "אין לקוחות שמחכים לתשובה",
  });
}

chrome.alarms.create(BADGE_ALARM, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === BADGE_ALARM) refreshBadge().catch(() => {});
});
// גם בהתעוררות של הדפדפן, בלי לחכות לדקה הראשונה.
chrome.runtime.onStartup.addListener(() => refreshBadge().catch(() => {}));
refreshBadge().catch(() => {});

// ── הודעות מהחלונית ומהפופאפ ─────────────────────────────
// 🔴 הכלל היחיד כאן: **תמיד לענות.** מסלול שלא מגיע ל-respond משאיר את
// החלונית תקועה בלי שום הודעה על המסך.
const ROUTES = {
  async SIGN_IN(p) {
    return signIn(p.handle, p.password);
  },
  async SIGN_OUT() {
    await setSession(null);
    announceAuth(false);
    return { ok: true };
  },
  async WHO() {
    const s = await getSession();
    return { ok: true, signedIn: Boolean(s), user: s ? s.user : null };
  },
  async CONTEXT(p) {
    return call("/api/priority-context", { method: "POST", body: JSON.stringify(p) });
  },
  // ⭐ פתיחת קובץ ששמור אצלנו. הדלי פרטי, ולכן השרת מנפיק כתובת חתומה
  // לחמש דקות. 🔴 הלקוח מוסר מזהה הודעה ואינדקס בלבד, לעולם לא נתיב.
  // ⭐ הכרטיס המלא של הלקוח. אותה פונקציה במסד שהדשבורד קורא לה.
  async CARD(p) {
    const q = p.customer
      ? "?customer=" + encodeURIComponent(p.customer) + "&card=1"
      : "?phone=" + encodeURIComponent(p.phone) + "&card=1";
    return call("/api/conversation" + q, { method: "GET" });
  },
  // ⭐ סימון "השיחה נפתחה ונקראה". יושב על אותה נקודת קצה של השרשור, כי
  // הפרויקט על תקרת שתים-עשרה הפונקציות של Vercel.
  async MARK_READ(p) {
    const q = "?phone=" + encodeURIComponent(p.phone) + "&markRead=1";
    return call("/api/conversation" + q, { method: "GET" });
  },
  // ⭐ חיפוש לקוח בכל בסיס הלקוחות, גם כזה שאין איתו שיחה.
  async SEARCH(p) {
    return call("/api/conversation?search=" + encodeURIComponent(p.q || ""), { method: "GET" });
  },
  async MEDIA(p) {
    const q = "?message=" + encodeURIComponent(p.messageId) + "&i=" + Number(p.index || 0);
    return call("/api/wa-media" + q, { method: "GET" });
  },
  // הספירה הגלובלית, לשימוש הבועה שבתוך פריוריטי.
  async WAITING() {
    const r = await call("/api/conversation?tab=waiting&limit=1", { method: "GET" }, true, 12000);
    if (!r || !r.ok || !r.data || !r.data.ok) return { ok: false, waiting: 0 };
    // כל קריאה כזאת מרעננת גם את הנקודה על האייקון, בלי סבב נוסף.
    refreshBadge().catch(() => {});
    return { ok: true, waiting: Number((r.data.counts && r.data.counts.waiting) || 0) };
  },
  // רשימת השיחות, ושרשור של שיחה שנבחרה ממנה. שתיהן על אותה נקודת קצה:
  // בלי פרמטר לקוח היא מחזירה רשימה, ועם פרמטר שרשור.
  async INBOX(p) {
    const q = "?tab=" + encodeURIComponent(p.tab || "waiting")
      + (p.q ? "&q=" + encodeURIComponent(p.q) : "");
    return call("/api/conversation" + q, { method: "GET" });
  },
  async THREAD(p) {
    return call("/api/conversation?phone=" + encodeURIComponent(p.phone || ""), { method: "GET" });
  },
  async SEND(p) {
    // חלון ארוך רק כשיש מסמך, כדי שהודעת טקסט תמשיך להיכשל מהר.
    const withDoc = Boolean(p && p.documentBase64);
    return call("/api/wa-send", { method: "POST", body: JSON.stringify(p) }, true, withDoc ? 65000 : 15000);
  },
};

chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  const route = msg && ROUTES[msg.type];
  if (!route) return;
  route(msg.payload || {})
    .then(respond)
    .catch((e) => respond({ ok: false, error: "שגיאה פנימית: " + ((e && e.message) || e) }));
  return true; // תשובה אסינכרונית
});

chrome.runtime.onInstalled.addListener(() => {
  console.log("[RashalWA] הותקן.");
});
