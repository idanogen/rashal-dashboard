// printer.js — עותק של המנוע שנבנה לתוסף של עוגן הזהר.
// המקור: ~/Idan-HQ/company/wa-priority/extension/src/printer.js
// 🔴 שינוי כאן שאינו מגיע גם לשם (או להפך) יוצר שני מנועים שמתפצלים בשקט.
//
// printer.js — הרצת ההדפסה של פריוריטי מתוך הקוד, בלי שהמשתמש ילחץ.
//
// ⭐ הרצף פוענח מיירוט חי ב-17/08/2026 (עוגן, מסך DOCUMENTS_D):
//
//   FormActivate        → מחזיר link + linkid
//   ProcStartActivate   type=P · ename=<שם הפרוצדורה> · table · link · linkid
//                       → מחזיר session של הפרוצדורה
//   ProcClientContinue  session + data ריק
//                       → מחזיר step=askprint
//   ProcAskPrintOK      session · mode=2 (הצגה) · pdf=true
//                       → מחזיר step=displayurl + כתובת ה-PDF
//
// אין כאן שום ערך שהדפדפן מחשב לבד. הכל מושחל מתשובה לתשובה.
//
// 🔴🔴 הזדהות: כל בקשת SOAP של פריוריטי נושאת UsernameToken עם הסיסמה.
// כדי לשלוח בקשה משלנו אנחנו **ממחזרים את כותרת ההזדהות שהדף כבר שולח**,
// כפי שנלכדה מקריאה אמיתית. המשמעות:
//   · הסיסמה נשארת בזיכרון הלשונית, בדיוק כפי שהיא כבר שם
//   · היא לעולם לא נשלחת לבקאנד שלנו, לא נכתבת ולא נשמרת
//   · הפעולה נרשמת בפריוריטי על שם המשתמש המחובר, כאילו הוא לחץ
// זה שינוי אופי מודע: התוסף עובר מ"מקשיב" ל"פועל בשם המשתמש".

(function (root) {
  "use strict";

  const D = root.RashalDataset;

  let serviceUrl = null;   // הכתובת של Service.svc
  let headerXml = null;    // <s:Header> מלא, כולל ההזדהות
  let formSession = null;  // הסשן האחרון שנראה, גיבוי בלבד
  const sessions = {};     // שם טופס → הסשן שלו
  const actions = {};      // op → SOAPAction

  // ── למידת פרוצדורות ההדפסה ─────────────────────────────
  //
  // ⭐ `ename` יושב בגלוי בבקשת ProcStartActivate. לכן במקום לקבע שם פרוצדורה
  // לכל מסך ולכל לקוח, **התוסף לומד אותו מהדפסה ידנית אחת** וזוכר אותו לתמיד.
  // זה מה שהופך את המוצר לגנרי: אצל לקוח חדש אף אחד לא צריך למפות כלום,
  // מדפיסים פעם אחת בכל מסך וזהו.
  // 🔴 ולכן גם: מיקומי שדות ושמות פרוצדורות הם פר-סביבה, ואסור להניח
  // שמה שנכון בעוגן נכון אצל לקוח אחר.
  const learned = {}; // form → { ename, table, at }
  let onLearn = null;

  function loadLearned() {
    try {
      chrome.storage.local.get(["printProcs"], (s) => {
        Object.assign(learned, (s && s.printProcs) || {});
      });
    } catch (_) {}
  }
  loadLearned();

  // 🔴 **לומדים רק מה שהוכיח את עצמו.**
  // גרסה קודמת צרבה כל פרוצדורה שהופעלה, גם כזו שלא הפיקה שום מסמך.
  // מספיק היה שהמשתמש ילחץ פעם אחת על פעולה לא נכונה, והיא נדבקה למסך
  // לתמיד. גרוע מכך: התוסף היה מריץ אותה לבד על נתונים אמיתיים, בלי
  // שאיש יודע מה היא עושה.
  // עכשיו: ההפעלה נרשמת כ**מועמדת** בלבד, והיא נצרבת רק כשאותה הרצה
  // באמת החזירה קובץ. פעולה שלא הפיקה כלום פשוט לא נלמדת.
  let pending = null; // { form, ename, table }

  function notePending(form, requestBody) {
    if (!form || !requestBody) return;
    const ename = (requestBody.match(/<ename>([^<]+)<\/ename>/) || [])[1];
    const table = (requestBody.match(/<table>([^<]+)<\/table>/) || [])[1];
    if (!ename || !table) return;
    const avoid = (requestBody.match(/<avoidmessages>([^<]+)<\/avoidmessages>/) || [])[1];
    pending = { form, ename, table, avoidmessages: avoid || "false" };
  }

  // 🔴 פרמטרי ההדפסה **שונים בין מסכים**, ואי אפשר לנחש אותם.
  // אומת ב-17/08: תעודת משלוח שולחת `format=-3` וחשבונית מס `format=-1`,
  // בזמן שבשני המסכים הבחירה בתפריט נראית "רגילה".
  // לכן לומדים את **כל התשובה לדיאלוג** מההדפסה הידנית, ולא רק את שם
  // הפרוצדורה. זו אותה דוקטרינה: לא לנחש, ללמוד ממה שהוכיח את עצמו.
  const PRINT_ARGS = ["mode", "format", "sendattach", "copies", "pdf", "sign", "quick"];

  function notePrintArgs(requestBody) {
    if (!pending || !requestBody) return;
    const args = {};
    for (const k of PRINT_ARGS) {
      const v = (requestBody.match(new RegExp("<" + k + ">([^<]*)</" + k + ">")) || [])[1];
      if (v != null) args[k] = v;
    }
    if (Object.keys(args).length) pending.printArgs = args;
  }

  // נקרא כשהתקבלה כתובת מסמך. רק כאן המועמדת הופכת לידע.
  function commitPending() {
    if (!pending) return null;
    const { form, ename, table, avoidmessages, printArgs } = pending;
    pending = null;
    const prev = learned[form];
    // 🔴🔴 **השוואה על הערכים, לא על עצם הקיום.**
    // הגרסה הקודמת דילגה על כל למידה חוזרת שבה הפרוצדורה כבר מוכרת
    // וכבר היו לה פרמטרים, **בלי להשוות את הפרמטרים עצמם**. נתפס
    // ב-24/08/2026 כשעידן הדפיס חשבונית מס וחשבונית זיכוי מאותו מסך:
    // שתיהן `AINVOICES`, ורק אחת נשמרה. אם הן מדפיסות ב-`format` שונה,
    // הלקוח היה מקבל את הטופס הלא נכון, בשקט מוחלט.
    // ⭐ הכלל: **דילוג רק כשאין שום דבר חדש להגיד.**
    if (prev && prev.ename === ename && sameArgs(prev.printArgs, printArgs)) return prev;
    if (prev && prev.ename === ename) {
      console.log("[RashalWA] אותו מסך, פרמטרי הדפסה אחרים:", form,
        JSON.stringify(prev.printArgs), "⟵", JSON.stringify(printArgs));
    }
    learned[form] = { ename, table, avoidmessages, printArgs, at: new Date().toISOString() };
    try { chrome.storage.local.set({ printProcs: learned }); } catch (_) {}
    console.log("[RashalWA] נלמדה פרוצדורה שהוכיחה את עצמה:", form, ename);
    if (onLearn) onLearn(form, learned[form]);
    return learned[form];
  }

  /** האם שתי מערכות פרמטרים זהות. חסר מול ריק נחשבים שונים בכוונה. */
  function sameArgs(a, b) {
    const A = a || {};
    const B = b || {};
    const keys = new Set(Object.keys(A).concat(Object.keys(B)));
    for (const k of keys) if (String(A[k] == null ? "" : A[k]) !== String(B[k] == null ? "" : B[k])) return false;
    return true;
  }

  // הרצה שהסתיימה בלי מסמך: המועמדת נזרקת ולא נלמדת.
  function dropPending() { pending = null; }

  function forget(form) {
    delete learned[form];
    try { chrome.storage.local.set({ printProcs: learned }); } catch (_) {}
    console.log("[RashalWA] נמחק מה שנלמד עבור", form);
  }

  /**
   * מאמץ מה שנלמד אצל אחרים.
   *
   * ⭐⭐ **ידע על מסך הדפסה הוא של החברה, לא של המשתמש.** עד 24/08/2026
   * הוא נשמר רק כאן, בדפדפן, וכל עובד חדש התחיל מאפס. עכשיו השרת מחזיר
   * את מה שכבר נלמד, וזה מגיע לכאן.
   *
   * 🔴 **מה שנלמד מקומית תמיד מנצח.** הוא הוכיח את עצמו על המחשב הזה,
   * ברגע שהוא באמת החזיר קובץ. אימוץ שדורס אותו היה יכול להחליף
   * פרוצדורה עובדת בפרוצדורה שנכונה למישהו אחר.
   *
   * @returns כמה מסכים נוספו
   */
  function adopt(map) {
    if (!map || typeof map !== "object") return 0;
    let added = 0;
    for (const form of Object.keys(map)) {
      if (learned[form]) continue;
      const v = map[form];
      if (!v || !v.ename || !v.table) continue;
      learned[form] = {
        ename: v.ename,
        table: v.table,
        avoidmessages: v.avoidmessages,
        printArgs: v.printArgs,
        at: v.at || new Date().toISOString(),
        fromServer: true,
      };
      added++;
    }
    if (added) { try { chrome.storage.local.set({ printProcs: learned }); } catch (_) {} }
    return added;
  }

  function procFor(form) { return learned[form] || null; }
  function allLearned() { return Object.assign({}, learned); }
  function setOnLearn(fn) { onLearn = fn; }

  // ── למידה מקריאות אמיתיות שעוברות ─────────────────────
  function remember(m) {
    if (!m || !/Service\.svc/i.test(m.url || "") || !m.requestBody) return;
    serviceUrl = m.url;

    const h = (m.requestBody.match(/<s:Header>[\s\S]*?<\/s:Header>/) || [])[0];
    if (h && /Password/i.test(h)) headerXml = h;

    // 🔴 סשן **פר טופס**, לא "הסשן האחרון שראינו".
    // במסך עם תת-טפסים (הזמנת מכר: פירוטי הזמנה, פרטי הלקוח, לוג שינויים)
    // כל תת-טופס שולח סשן משלו, והוא דורס. FormActivate עם הסשן של
    // תת-הטופס לא מחזיר link, וההפקה נופלת. נתפס חי ב-17/08.
    const sess = (m.requestBody.match(/<Session xmlns="PriorityNS">([^<]*)<\/Session>/) || [])[1];
    if (sess) {
      formSession = sess;
      const f = (m.requestBody.match(/<form>([A-Za-z0-9_]+)<\/form>/) || [])[1];
      if (f) sessions[f] = sess;
    }

    const op = (m.requestBody.match(/<s:Body><([A-Za-z0-9]+)/) || [])[1];
    const sa = m.requestHeaders && (m.requestHeaders.SOAPAction || m.requestHeaders.soapaction || m.requestHeaders["SOAPAction"]);
    if (op && sa) actions[op] = String(sa).replace(/^"|"$/g, "");
  }

  function ready() {
    return Boolean(serviceUrl && headerXml);
  }

  function missing() {
    if (!serviceUrl) return "לא נלכדה עדיין קריאה לפריוריטי";
    if (!headerXml) return "לא נלכדה כותרת הזדהות";
    return null;
  }

  // SOAPAction לפעולה. אם לא ראינו אותה, גוזרים מהתבנית של פעולה מוכרת.
  // 🔴 WCF דוחה בקשה בלי SOAPAction, ולכן זה לא פרט טכני זניח.
  function actionFor(op) {
    if (actions[op]) return actions[op];
    const any = Object.keys(actions)[0];
    if (!any) return null;
    return actions[any].replace(/[^/]+$/, op);
  }

  function iso(d) { return new Date(d).toISOString().replace(/\.\d+Z$/, ".000Z"); }

  // בונה מעטפת. מרענן את חותמות הזמן, כי הכותרת שנלכדה תקפה לשש דקות בלבד.
  function envelope(op, bodyXml, withSession) {
    let head = headerXml
      .replace(/<u:Created>[^<]*<\/u:Created>/, "<u:Created>" + iso(Date.now()) + "</u:Created>")
      .replace(/<u:Expires>[^<]*<\/u:Expires>/, "<u:Expires>" + iso(Date.now() + 5 * 60000) + "</u:Expires>");

    // 🔴 ProcStartActivate נשלח **בלי** <Session> בכותרת, ו-FormActivate **עם**.
    // אומת מהיירוט. אי אפשר לשלוח את אותה כותרת לשניהם.
    const hasSession = /<Session xmlns="PriorityNS">/.test(head);
    if (withSession && !hasSession && formSession) {
      head = head.replace("<Security", '<Session xmlns="PriorityNS">' + formSession + "</Session><Security");
    } else if (!withSession && hasSession) {
      head = head.replace(/<Session xmlns="PriorityNS">[^<]*<\/Session>/, "");
    }

    return '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">' +
      head + "<s:Body>" + bodyXml + "</s:Body></s:Envelope>";
  }

  // ניתן להחלפה בבדיקות, כדי לבדוק את מסלולי הדיאלוג בלי רשת אמיתית.
  let callImpl = null;
  function call(op, bodyXml, withSession) {
    return (callImpl || realCall)(op, bodyXml, withSession);
  }

  async function realCall(op, bodyXml, withSession) {
    const action = actionFor(op);
    const headers = { "Content-Type": "text/xml; charset=utf-8" };
    if (action) headers["SOAPAction"] = '"' + action + '"';

    const res = await fetch(serviceUrl, {
      method: "POST",
      headers,
      body: envelope(op, bodyXml, withSession),
      credentials: "include",
    });
    const text = await res.text();
    if (!res.ok) throw new Error(op + " החזיר " + res.status);
    const parsed = D.analyzeProc(text) || {};
    // שגיאת SOAP מגיעה בקוד 200 עם Fault בגוף. בלי הבדיקה הזאת היא נראית כהצלחה.
    if (/<s:Fault>|<faultstring>/i.test(text)) {
      const f = (text.match(/<faultstring[^>]*>([\s\S]*?)<\/faultstring>/i) || [])[1] || "שגיאה";
      throw new Error(op + " נכשל: " + f.slice(0, 200));
    }
    return { text, fields: parsed.fields || {} };
  }

  // ערך מהמסך נכנס לתוך XML. שם לקוח עם `&` היה שובר את הבקשה בשקט.
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  // 🔴 התאום של לקח #54, בכיוון הכתיבה.
  // `atob` מחזיר latin1 ולכן צריך לנרמל בקריאה. בכתיבה זה חמור יותר:
  // **`btoa` פשוט זורק על כל תו מעל 255**, ולכן ערך עברי בתא (שם לקוח,
  // תיאור) היה מפיל את ההפקה כולה בשגיאת דפדפן. ההצהרה בראש ה-XML אומרת
  // UTF-8, ולכן מקודדים לבייטים של UTF-8 ואז ל-base64.
  function b64utf8(s) {
    const bytes = new TextEncoder().encode(s);
    let bin = "";
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  }

  // statexml מקודד base64, עם בייט 0x02 בהתחלה. אומת מהיירוט.
  function stateXml(inner) {
    return b64utf8("\x02" + '<?xml version="1.0" encoding="UTF-8"?>\n' + inner);
  }

  const EMPTY_DATA = stateXml("<NewDataSet>\n</NewDataSet>\n");

  // ── ההרצה ──────────────────────────────────────────────
  // מחזיר { url } או זורק שגיאה מדברת.
  async function print(opts) {
    const table = opts.table;
    const ename = opts.ename;
    const line = String(opts.line || 1);
    const field = String(opts.field || 1);
    const curtab = String(opts.curtab == null ? 0 : opts.curtab);
    const value = String(opts.value || "");
    // הסשן של הטופס שממנו מדפיסים, ולא של תת-טופס שדרס אותו.
    const sess = (opts.form && sessions[opts.form]) || formSession;

    if (!ready()) throw new Error(missing());
    if (!ename) throw new Error("לא ידוע שם פרוצדורת ההדפסה של המסך הזה");

    // 1. סנכרון מצב המסך. מכאן מגיעים link ו-linkid.
    const act = await call("FormActivate",
      '<FormActivate xmlns="http://tempuri.org/"><statexml>' +
      stateXml(
        "<NewDataSet>\n  <Operations>\n    <session>" + sess + "</session>\n  </Operations>\n" +
        "  <Operation>\n    <field>" + field + "</field>\n    <line>" + line + "</line>\n" +
        "    <curtab>" + curtab + "</curtab>\n    <value>" + esc(value) + "</value>\n    <active>1</active>\n" +
        "    <key>0</key>\n    <drawn>0</drawn>\n  </Operation>\n</NewDataSet>\n"
      ) +
      "</statexml><before>true</before></FormActivate>", true);

    const link = act.fields.link;
    const linkid = act.fields.linkid;
    if (!link || !linkid) {
      // לקונסולה בלבד. על המסך יושבת שורה קצרה, כי זו מערכת חיה.
      console.warn("[RashalWA] FormActivate בלי link:",
        { form: opts.form, field, line, curtab, value, fields: act.fields });
      // 🔴 ערך ריק ושורה שלא זוהתה הן שתי תקלות שונות, וההודעה מפרידה
      // ביניהן. ריק פירושו שלא מצאנו ולו תא אחד עם ערך בשורה, וזה מצב
      // שהעובד לא יכול לתקן בלחיצה. ראה `focus()` ב-`context.js`.
      throw new Error(
        value
          ? "פריוריטי לא זיהה את השורה. לחץ על שורת המסמך ונסה שוב"
          : "לא נמצא בשורה הזאת ולו שדה אחד עם ערך, ולכן אי אפשר לזהות אותה"
      );
    }

    // 2. פתיחת הפרוצדורה. מכאן מגיע סשן הפרוצדורה.
    const start = await call("ProcStartActivate",
      '<ProcStartActivate xmlns="http://tempuri.org/">' +
      "<type>P</type><ename>" + ename + "</ename><table>" + table + "</table>" +
      "<link>" + link + "</link><linkid>" + linkid + "</linkid>" +
      "<avoidmessages>" + (opts.avoidmessages || "false") + "</avoidmessages></ProcStartActivate>", false);

    const session = start.fields.session;
    if (!session) throw new Error("ProcStartActivate לא החזיר session");

    // 3-4. **מכונת מצבים, לא רצף קבוע.**
    //
    // 🔴 זו הייתה הטעות המבנית שלי. כתבתי רצף קשיח
    // (start → continue → askprint → ok), ובפועל נצפו **שלושה רצפים שונים
    // בארבעה מסכים**, כולם תקינים:
    //   · תעודת משלוח וחשבונית: start=CLIENT → continue → askprint → ok
    //   · הזמנת רכש:            start=**askprint** מיד, בלי continue בכלל
    //   · אישור הזמנה:          continue → **displayurl**, בלי דיאלוג
    // קריאת continue מיותרת מקדמת את מכונת המצבים מעבר לשלב ואז שוברת אותה.
    //
    // הפתרון: לא לנחש את הרצף. **לקרוא את `step` אחרי כל קריאה ולפעול לפיו.**
    let step = start.fields.step || null;
    let fields = start.fields;
    let url = null;
    const seen = step ? [step] : [];

    for (let i = 0; i < 8; i++) {
      if (step === "displayurl") { url = fields.url; break; }

      let res;
      if (step === "askprint") {
        // ברירת מחדל: הצגה + PDF. פרמטרים שנלמדו מהדפסה ידנית גוברים,
        // כי הם היחידים שידוע שעובדים במסך הזה. ראה notePrintArgs.
        const a = Object.assign(
          { mode: "2", format: "-1", sendattach: "true", copies: "1", pdf: "true", sign: "false", quick: "false" },
          opts.printArgs || {}
        );
        a.pdf = "true";  // 🔴 תמיד PDF
        a.mode = "2";    // 🔴 תמיד "הצגה". לעולם לא מייל או פקס מהתוסף
        res = await call("ProcAskPrintOK",
          '<ProcAskPrintOK xmlns="http://tempuri.org/"><session>' + session + "</session>" +
          PRINT_ARGS.map((k) => "<" + k + ">" + a[k] + "</" + k + ">").join("") +
          "</ProcAskPrintOK>", false);
      } else {
        res = await call("ProcClientContinue",
          '<ProcClientContinue xmlns="http://tempuri.org/"><session>' + session +
          "</session><data>" + EMPTY_DATA + "</data></ProcClientContinue>", false);
      }

      fields = res.fields;
      step = fields.step || null;
      if (step) seen.push(step);
    }

    if (!url) {
      throw new Error("הסתיים בלי כתובת מסמך. שלבים: " + (seen.join(" ← ") || "ללא"));
    }

    // שחרור הסשן. best-effort, כישלון כאן לא מבטל מסמך שכבר הופק.
    call("ProcEnd", '<ProcEnd xmlns="http://tempuri.org/"><session>' + session + "</session></ProcEnd>", false)
      .catch(() => {});

    // 🔴 לא זורקים על סיומת שאינה pdf. פריוריטי עשוי להחזיר פורמט אחר,
    // ועדיף להחזיר ולציין מאשר "נכשל" סתמי.
    return { url, link, linkid, session, isPdf: /\.pdf($|\?)/i.test(url) };
  }

  root.RashalPrinter = { remember, ready, missing, print, notePending, notePrintArgs, commitPending, dropPending,
                       forget, procFor, allLearned, adopt, setOnLearn, _learned: learned,
                       _setCall: (fn) => { callImpl = fn; },
                       _envelope: envelope, _actionFor: actionFor, _stateXml: stateXml };
})(window);
