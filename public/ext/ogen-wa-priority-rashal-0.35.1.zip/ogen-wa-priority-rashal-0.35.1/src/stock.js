/**
 * מה יש אצל הלקוח: הניסוח, בלי ציור.
 *
 * ⭐⭐ **הבקשה, כלשונו של עידן (25/08/2026):** "כמעט לכל לקוח של ר.שעל
 * יש מוצר של החברה. הייתי רוצה שישר יקפוץ לנציגה איזה מוצר יש ללקוח.
 * נכון לעכשיו אנחנו לא יודעים את זה."
 *
 * 🔴 **המודול הזה קיים כדי שיהיה אפשר לבדוק את מה שנאמר ללקוח בקול.**
 * החלונית עטופה ב-IIFE, ואי אפשר להגיע מבדיקה לפונקציה שבתוכה. משפט
 * שנאמר לאדם אמיתי בטלפון הוא בדיוק מה שחייב בדיקה, ולכן הוא כאן.
 *
 * 🔴 **וההכרעה מי נמצא אצל הלקוח נעשתה כבר במסד** (`customer_card`),
 * ולא כאן. אותה פונקציה בדיוק מזינה גם את הדשבורד, ולכן אי אפשר שכאן
 * יופיע מכשיר שהדשבורד כבר סימן כנאסף.
 */
(function (w) {
  "use strict";

  /** dd/mm/yyyy, כי זה מה שנאמר ללקוח בקול. */
  function fullDate(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    return String(d.getDate()).padStart(2, "0") + "/" +
           String(d.getMonth() + 1).padStart(2, "0") + "/" + d.getFullYear();
  }

  /** 🔴 עם שנה. ראה `shortDate` ב-panel.js: יש בציר אירועים מ-2014. */
  function shortDate(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    return String(d.getDate()).padStart(2, "0") + "/" +
           String(d.getMonth() + 1).padStart(2, "0") + "/" +
           String(d.getFullYear()).slice(2);
  }

  /**
   * השם של הפריט.
   *
   * 🔴 **`part` ריק כשבפריוריטי נרשם טקסט חופשי** (`'*'`), למשל "חגורת
   * פרפר". 167 שורות כאלה. בלי הנפילה חזרה לתיאור, הנציגה רואה שורה
   * ריקה במקום פריט.
   */
  function stockName(it) {
    if (!it) return "פריט";
    if (it.part) return String(it.part);
    const d = String(it.desc || "").replace(/^"+|"+$/g, "").trim();
    return d || "פריט";
  }

  /** התיאור, רק כשהוא מוסיף על השם. */
  function stockSub(it) {
    if (!it || !it.part || !it.desc) return "";
    return String(it.desc).replace(/"{2,}/g, '"').replace(/^"+|"+$/g, "").trim();
  }

  const SOURCE_TEXT = { service: "קריאת שירות", delivery: "אספקה", register: "מרשם המנופים" };

  const DAY = 86400000;

  /**
   * מצב האחריות.
   *
   * 🔴 **"נגמרת בקרוב" הוא סף ולא קישוט.** אחריות בתוקף היא המצב הרגיל
   * של רוב הפריטים; לו הייתה נצבעת, כל הרשימה הייתה צבועה ושום דבר לא
   * היה בולט. הסף כאן 60 יום, **זהה לזה שבדשבורד**: שני מסכים שמחשבים
   * את אותו דבר בשתי נוסחאות מתפצלים בסוף, ואז אחד מהם משקר.
   */
  function warrantyState(end, now) {
    if (!end) return { tone: "unknown", text: "" };
    const t = new Date(end).getTime();
    if (isNaN(t)) return { tone: "unknown", text: "" };
    const days = Math.floor((t - (now == null ? Date.now() : now)) / DAY);
    if (days < 0) return { tone: "expired", text: "האחריות פגה ב-" + fullDate(end) };
    if (days <= 60) return { tone: "ending", text: "האחריות נגמרת ב-" + fullDate(end) };
    return { tone: "active", text: "באחריות עד " + fullDate(end) };
  }

  /**
   * שורת התחתית: אחריות, ומאיפה הפריט ידוע.
   *
   * 🔴 **פריט בלי מקור הוא בדיוק מה שנציגה תגיד בביטחון ותיפול עליו.**
   * קריאת שירות נאמרת ראשונה כי היא העדות החזקה ביותר: טכנאי ראה את
   * המכשיר אצל הלקוח, בעוד שהזמנה רק מעידה שהוא יצא מהמחסן.
   */
  function stockFoot(it, now) {
    const out = [];
    const w = warrantyState(it && it.warrantyEnd, now);
    if (w.text) out.push(w.text);
    const src = (it && it.sources) || [];
    const labels = ["service", "delivery", "register"]
      .filter((k) => src.indexOf(k) >= 0).map((k) => SOURCE_TEXT[k]);
    if (labels.length) out.push(labels.join(" · "));
    return { text: out.join(" · "), tone: w.tone };
  }

  /**
   * המשפט.
   *
   * 🔴🔴 **אחריות שפגה לא נאמרת כאילו היא בתוקף.** הנציגה קוראת את זה
   * בקול, ו"אתה באחריות" שנאמר בטעות עולה כסף ואמון.
   *
   * 🔴 **וכשאין כלום, המשפט אומר למה.** רשימה ריקה נראית בדיוק כמו
   * פיצ'ר שלא הותקן, והנציגה לא יכולה להבחין בין "אין לו ציוד" לבין
   * "אנחנו לא יודעים".
   */
  /**
   * המשפט על המכשירים בלבד.
   * ⭐ מחולץ כדי שגם "התשובה ללקוח" תוכל לומר אותו, ולא תסתור את הרצועה.
   */
  function devicePhrase(devices, now) {
    const list = devices || [];
    if (!list.length) return null;
    const f = list[0];
    const bits = ["יש לו " + stockName(f)];
    // ⭐ מספר סידורי נאמר רק כשהוא חד-משמעי. שניים על אותו קוד
    // פירושם שני מכשירים, ואז המספר אינו מזהה אף אחד מהם.
    if ((f.serials || []).length === 1) bits.push("מספר סידורי " + f.serials[0]);
    const w = warrantyState(f.warrantyEnd, now);
    if (w.tone === "expired") bits.push("האחריות כבר פגה");
    else if (w.text) bits.push(w.text);
    const rest = list.length - 1;
    // ⭐ יחיד ורבים. "יש לו מנוף (ועוד 1)" אינו משפט שאדם אומר בטלפון.
    const tail = rest === 0 ? "" : rest === 1 ? " ועוד מכשיר אחד." : " ועוד " + rest + " מכשירים.";
    return bits.join(", ") + "." + tail;
  }

  function stockText(stock) {
    const devices = (stock && stock.devices) || [];
    const acc = (stock && stock.accessories) || [];
    const ret = (stock && stock.returned) || [];

    const phrase = devicePhrase(devices);
    if (phrase) return { tone: "rwa-ok", text: phrase };

    if (acc.length) {
      const names = acc.slice(0, 2).map(stockName).join(" ו-");
      const rest = acc.length - Math.min(2, acc.length);
      return { tone: "", text: "אין מכשיר רשום, יש " + names + (rest ? " ועוד " + rest + " פריטים" : "") + "." };
    }

    if (ret.length) {
      return {
        tone: "",
        text: "אין ציוד אצלו כרגע. מה שהיה נאסף בחזרה, האחרון " + stockName(ret[0]) +
              (ret[0].at ? " ב-" + shortDate(ret[0].at) : "") + ".",
      };
    }

    // 🔴 גבול החלון מגיע מהמסד ולא נכתב כאן. תאריך קשיח היה נשאר
    // נכון-למראה עד הייבוא ההיסטורי, ואז משקר בשקט.
    const since = stock && stock.since ? fullDate(stock.since) : null;
    return {
      tone: "",
      text: since
        ? "לא רשום אצלנו ציוד. אנחנו יודעים מה סופק ומה נאסף מ-" + since +
          " ואילך, וציוד ישן יותר יופיע רק אם נפתחה עליו קריאת שירות."
        : "לא רשום אצלנו ציוד אצל הלקוח הזה.",
    };
  }

  /**
   * מה לומר כשהלקוח לא זוהה לפי הטלפון שממנו הוא כותב.
   *
   * 🔴🔴 נתפס חי ב-25/08/2026: לקוחה כתבה ממספר שאינו רשום בפריוריטי,
   * והכרטיס אמר "לא מזוהה" ו"לא רשום אצלנו ציוד" על לקוחה שיש לה מנוף
   * שסופק שבוע קודם. לקוחות ר.שעל הם מטופלים, ומי שכותב בוואטסאפ הוא
   * לרוב בן משפחה עם טלפון אחר.
   */
  function identityNote(c) {
    if (!c) return null;
    // 🔴 חזק, אבל לא הטלפון הרשום של הלקוח: הסדרן הקליד אותו על ההזמנה.
    if (c.identifiedBy === "document") {
      return "הטלפון הזה אינו רשום על כרטיס הלקוח. הוא מופיע על הזמנה או קריאה של הלקוח הזה.";
    }
    if (c.identifiedBy !== "survey") return null;
    // ⭐ "ל" נדבקת לשם, בלי מקף.
    return "הטלפון הזה אינו רשום בפריוריטי. חיברנו אותו " +
      (c.identifiedHint ? "ל" + c.identifiedHint : "ללקוח") +
      " לפי סקר ששלחנו למספר הזה.";
  }

  w.RashalStock = {
    stockName: stockName, stockSub: stockSub, stockFoot: stockFoot,
    stockText: stockText, warrantyState: warrantyState, fullDate: fullDate,
    identityNote: identityNote, devicePhrase: devicePhrase,
  };
})(typeof window !== "undefined" ? window : globalThis);
