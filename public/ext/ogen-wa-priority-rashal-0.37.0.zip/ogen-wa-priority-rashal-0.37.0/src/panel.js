// panel.js — החלונית שיושבת בתוך הפריוריטי.
//
// זה לא כפתור ששולח. זו כל השיחה בוואטסאפ מול הלקוח שעל המסך, על פני כל
// המסמכים וכל העובדים, בתוך המערכת שבה הצוות כבר עובד.
//
// 🎨 ברירת המחדל היא בועה סגורה בפינה. החלונית נפתחת בלחיצה, ואף פעם לא
// קופצת מעצמה: מסך שקופץ באמצע הקלדה בפריוריטי הוא הדבר הראשון שגורם
// לצוות לכבות תוסף.
//
// 🔴 והכלל שקובע כאן הכל: חלון 24 השעות של מטא. מחוץ לחלון אי אפשר לשלוח
// טקסט חופשי, רק תבנית מאושרת. החלונית מציגה את זה בגדול ומשביתה את השדה,
// אבל האכיפה האמיתית היא בשרת (`api/wa-send`), כי לשונית שנפתחה לפני
// שעתיים מחזיקה מצב חלון ישן.

(function () {
  "use strict";

  const C = window.RashalContext;
  const VERSION = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || "?";
  const POLL_MS = 20000;

  // ── מצב ────────────────────────────────────────────────
  let host = null;
  let open = false;
  let ctx = null;          // מה שזוהה על המסך
  let data = null;         // מה שהשרת החזיר
  let loading = false;
  let error = "";
  let signedIn = null;     // null = עוד לא נבדק
  // ⭐ הקוד שהוזרק לעמוד נותק מהתוסף, בדרך כלל אחרי עדכון שלו. ראה `signInHint`.
  let detached = false;
  let pollTimer = null;
  let draft = "";          // 🔴 נשמר מחוץ ל-DOM, כדי שציור מחדש לא ימחק הקלדה
  let sending = false;
  let notice = null;       // { text, tone }
  let tplKey = null;       // איזו תבנית נבחרה
  let tplValues = {};      // ערכי המשתנים שלה, מחוץ ל-DOM כמו הטיוטה
  // 🔴🔴 **על מי הערכים האלה.** הטופס חי מחוץ ל-DOM כדי לשרוד ציור מחדש,
  // ולכן הוא שורד גם מעבר בין לקוחות. `applyCtx` מאפס אותו במעבר שורה,
  // אבל מעבר בין שיחות בתיבה אינו עובר דרכו. בלי המזהה הזה אפשר לבחור
  // לקוח בתיבה ולראות בטופס את שם הלקוח הקודם, ולשלוח לו ברכה בשם של
  // מישהו אחר. [[label_and_math_from_two_mechanisms]]
  let tplFor = null;
  // ⭐ מספר שהוקלד ידנית. null = משתמשים במספר שעל כרטיס הלקוח.
  // 🔴 נדרש כדי שאפשר יהיה לבדוק את המערכת בלי לשלוח ללקוח אמיתי, ובקשה
  // של עידן מהתוסף של עוגן הזהר: גם כשיש מספר, חייב להיות אפשר להקליד אחר.
  let phoneOverride = null;
  // ⭐ כמה לקוחות מחכים לתשובה **בכל המערכת**, לא רק זה שעל המסך.
  // 🔴 עד 0.8.0 הבועה הציגה נקודה רק כשללקוח שעומדים עליו היה חוב מענה,
  // כלומר הודעה מלקוח אחר לא הייתה מייצרת שום סימן. זה בדיוק ההפך ממה
  // שחיווי אמור לעשות: להגיד שקרה משהו שאתה לא מסתכל עליו.
  let waitingCount = 0;

  // ⭐⭐ **כתובות של תמונות שכבר נחתמו, כדי שהן לא יהבהבו.** השרשור מצויר
  // מחדש כל עשרים שניות, וציור מחדש בונה `<img>` חדש. בלי המטמון הזה כל
  // רענון היה מבקש חתימה חדשה לכל תמונה, והתמונה הייתה נעלמת ומופיעה.
  //
  // 🔴 **המילוי נעשה אחרי טעינה, לא בתוך הציור.** `card()` לא מתחיל
  // עבודה, וזה חוק ברזל כאן: ציור שמתחיל טעינה הוליד כבר שתי חלוניות
  // ושתי בועות בלחיצה אחת. [[render_must_not_start_work]]
  // ⭐⭐ **כרטיס הלקוח, בתוך החלונית.** עידן, 25/08/2026: "איפה הכרטיס
  // לקוח?... זה כבר פרטים על הלקוח". הרצועה עונה על "מה פתוח", והתיק
  // המלא הוא מסך משלו.
  let cardMode = false;      // מציגים את הכרטיס במקום השיחה
  let cardData = null;       // מה שהשרת החזיר
  let cardFor = null;        // למי הוא שייך, כדי שלא יוצג על לקוח אחר
  let cardLoading = false;

  const thumbs = new Map();   // "messageId:index" -> { url, at }
  const thumbsWanted = new Set();
  // החתימה חיה חמש דקות בשרת. מרעננים אחרי ארבע, כדי שהעדכון יקדים.
  const THUMB_TTL_MS = 4 * 60 * 1000;


  // ⭐⭐ **שני מצבים לחלונית, וזו הבקשה המרכזית של עידן (22/08/2026):**
  // "אני רוצה לנהל שיחות עם הלקוחות **גם בלי קשר למיקום בפריוריטי**".
  //
  // 🔴 עד 0.9.0 החלונית הייתה כולה נגזרת של השורה שעומדים עליה, ובמסך
  // הבית של פריוריטי היא אמרה "עמוד על שורה" וזהו. כלומר הודעה שנכנסה
  // מלקוח הייתה מחייבת לנחש על מי לעמוד כדי לקרוא אותה.
  //
  // 🔴🔴 **ואין יותר "מצב".** היה כאן `view` עם שלושה ערכים, והוא מה
  // שאפשר לחלונית להחליף צורה מתחת לידיים ולהיראות כמו שני מוצרים.
  // עכשיו הצורה אחת, ומה שמוצג בצד **נגזר ממה שקיים**: שיחה שנבחרה,
  // אחרת הלקוח שעל המסך, אחרת כלום. מצב שאפשר לגזור אינו מצב.
  let inbox = null;        // { items, counts }
  let inboxTab = "waiting";
  // ⭐ **כשאף אחד לא מחכה, "ממתינים" היא לשונית ריקה** (בקשת עידן,
  // 23/08/2026). המסך נפתח על מה שיש, לא על מה שאין. 🔴 פעם אחת בלבד:
  // אחרי שהמשתמש נגע בלשוניות, הבחירה שלו גוברת.
  let tabAutoSwitched = false;
  let inboxQ = "";
  let people = null;        // תוצאות חיפוש לקוחות, ראה `loadPeople`
  let peopleFor = "";
  let inboxLoading = false;
  let chat = null;         // { phone, title, data }
  let chatLoading = false;
  /** האם השרשור צמוד לתחתית. נשמר בין רינדורים, כי ה-DOM נבנה מחדש. */
  let chatStick = true;
  /** האם בשיחה שנבחרה מוצג טופס התבנית במקום שדה הטקסט. */
  let chatTpl = false;
  // ⭐ תבנית עם מסמך מתוך רצועת המקור, גם כשהחלון פתוח. ראה `screenStrip`.
  let rowTpl = false;
  // ── שיוך מספר לא מזוהה ללקוח (06/09/2026) ──
  let linkOpen = false;      // תיבת "שייך ללקוח" פתוחה מתחת לרצועה
  let linkQ = "";            // חיפוש
  let linkHits = null;       // תוצאות החיפוש
  let linkPicked = null;     // {customer_number, customer_name, city}
  let linkLabel = "";        // "הבת, מיכל"
  let linkRemember = true;
  let linkBusy = false;
  // "שלח למספר אחר": לזכור את המספר ללקוח שעל המסך אחרי השליחה.
  let rememberOther = true;
  let otherLabel = "";
  // ── להרזות את ההתכתבות (06/09/2026) ──
  let openedAuto = {};       // שורות מערכת שנפתחו לבועה מלאה, לפי מזהה
  let includeAuto = false;   // "כל השיחות": להציג גם שיחות אוטומטיות בלבד
  // 🔴 **רק למסך צר.** מתחת ל-620 פיקסל אין מקום לשתי רשומות, ואז ה-CSS
  // מציג אחת בלבד. הדגל הזה קובע איזו. במסך רגיל הוא חסר משמעות, ולכן
  // גם הכפתור שמפעיל אותו מוצג רק שם.
  let narrowList = false;
  // ⭐ שדות התבנית מוסתרים כברירת מחדל, ומה שמוצג הוא הטקסט הסופי
  // (החלטת עידן, 22/08/2026). שם הלקוח ומספר המסמך כבר ידועים מהמסך,
  // ושלושה שדות פתוחים רק כדי להראות ערכים שאיש לא עורך הם שלוש שורות
  // שגונבות את המקום מהדבר היחיד שחשוב: מה שהלקוח יקרא.
  // 🔴 הטקסט הסופי עריך, והשלד הקבוע קפוא אצל מטא. עריכה ששברה את
  // השלד מסומנת כאן, חוסמת שליחה, ומתאפסת בכל ציור מלא (שמחזיר נוסח תקין).
  // 🔴 **הרשימה הנפתחת של הדפדפן היא הרכיב היחיד שאי אפשר לעצב.**
  // `<select>` פותח חלונית של מערכת ההפעלה, שחורה ומרובעת, ובאמצע כרטיס
  // זכוכית בהיר היא נראית כמו חתיכה משבור אחר. לכן הבורר הוא רכיב משלנו.
  // ⭐ והוא נפתח **בתוך הזרימה** ולא כשכבה מעל: הכרטיס הוא
  // `overflow:hidden` ואזור התבנית גולל בתוך עצמו, ושכבה צפה הייתה
  // נחתכת בדיוק כמו שכפתור השליחה נחתך בסבב קודם.
  let tplOpen = false;
  // 🔴 **לקוח שנבחר ביד גובר על הזיהוי האוטומטי**, וכל עוד לא עברנו שורה.
  // מחזיק מספר לקוח בלבד, ובכוונה: ראה `load()`.
  let picked = null;
  let matchOpen = false;
  // ⭐⭐ **מה שנלמד כאן על מסך ההדפסה, בדרך לכל החברה.**
  // 🔴 עד 24/08/2026 הידע הזה נשאר בדפדפן שבו הוא נלמד. עובד חדש התחיל
  // מאפס, החלפת מחשב מחקה אותו, והכפתור היה אפור בפעם הראשונה בכל סוג
  // מסמך. זה ידע של החברה ולא של המשתמש.
  let pendingLearn = null;

  // 🔴🔴 **מיקוד מבוקש פעם אחת, לא בכל ציור.**
  // זו הייתה מלכודת אמיתית שנתפסה בשליחה החיה הראשונה (22/08/2026):
  // שדה המספר ביקש לעצמו מיקוד **בכל ציור מחדש**, ויציאה ממנו (`blur`)
  // הפעילה ציור מחדש. כלומר כל לחיצה על משהו אחר בחלונית גררה:
  // blur ← ציור מחדש ← שדה חדש ← מיקוד חוזר לשדה. לולאה בלי מוצא.
  // מבחוץ זה נראה כמו "אי אפשר ללחוץ על הרשימה" ו"אי אפשר לצאת מהשדה",
  // שני תסמינים של אותו באג.
  // ⭐ הכלל מעכשיו: **ציור אינו אירוע משתמש.** מיקוד ניתן רק ברגע שבו
  // המשתמש ביקש להיכנס למצב, ונצרך פעם אחת.
  let focusWanted = null; // "phone" | "draft" | null

  function takeFocus(want, node) {
    if (focusWanted !== want) return;
    focusWanted = null;
    setTimeout(() => { try { node.focus(); } catch (_) {} }, 0);
  }

  // ── הסתרה לשעה ─────────────────────────────────────────
  // ⭐ כמו בתוסף של עוגן הזהר: האיקס מסתיר לשעה ואז הבועה חוזרת לבד.
  // כפתור שמעלים את עצמו בלי דרך גלויה להחזיר הוא מלכודת.
  const HIDE_MS = 60 * 60 * 1000;
  let hiddenUntil = 0;
  let hideTimer = null;

  try {
    chrome.storage.local.get(["bubbleHiddenUntil"], (s) => {
      const until = (s && s.bubbleHiddenUntil) || 0;
      if (until > Date.now()) { hiddenUntil = until; render(); scheduleReturn(); }
    });
  } catch (_) {}

  function hideForAnHour() {
    hiddenUntil = Date.now() + HIDE_MS;
    try { chrome.storage.local.set({ bubbleHiddenUntil: hiddenUntil }); } catch (_) {}
    open = false;
    render();
    scheduleReturn();
  }

  function scheduleReturn() {
    if (hideTimer) clearTimeout(hideTimer);
    const left = hiddenUntil - Date.now();
    if (left <= 0) return;
    hideTimer = setTimeout(() => {
      hiddenUntil = 0;
      hideTimer = null;
      try { chrome.storage.local.remove("bubbleHiddenUntil"); } catch (_) {}
      render();
    }, left);
  }

  // ── תקשורת עם ה-service worker ─────────────────────────
  // 🔴 הכלל היחיד: תמיד לענות. מסלול שלא מגיע ל-cb משאיר את החלונית על
  // "טוען…" בלי שום הודעה, וזה נראה בדיוק כמו חלונית מקולקלת.
  /** האם הקוד שרץ בעמוד עדיין מחובר לתוסף. */
  function isAlive() {
    try { return Boolean(chrome.runtime && chrome.runtime.id); } catch (_) { return false; }
  }

  function send(type, payload) {
    return new Promise((resolve) => {
      let done = false;
      const answer = (r) => { if (!done) { done = true; resolve(r); } };

      if (!isAlive()) {
        detached = true;
        answer({ ok: false, error: "הקשר התוסף נותק. רענן את הדף." });
        return;
      }
      const timer = setTimeout(() => {
        answer({ ok: false, error: "מנוע התוסף לא ענה תוך 20 שניות." });
      }, 20000);

      try {
        chrome.runtime.sendMessage({ type, payload }, (r) => {
          clearTimeout(timer);
          let le = null;
          try { le = chrome.runtime.lastError; } catch (_) {}
          if (le) { answer({ ok: false, error: "אין קשר עם מנוע התוסף: " + le.message }); return; }
          answer(r || { ok: false, error: "אין תשובה מהתוסף." });
        });
      } catch (e) {
        clearTimeout(timer);
        answer({ ok: false, error: "הקריאה לא יצאה: " + ((e && e.message) || e) });
      }
    });
  }

  // ── טעינת ההקשר מהשרת ──────────────────────────────────
  async function load(silent) {
    if (!ctx || !ctx.candidates || !ctx.candidates.length) return;
    // אין טעם לצאת לשרת כשידוע שאין סשן. זו גם קריאה מיותרת וגם מצב
    // מהבהב: "טוען…" ואז "התחבר".
    if (signedIn === false) { render(); return; }
    if (!silent) { loading = true; error = ""; render(); }

    // 🔴 **כשהמשתמש בחר לקוח, נשלח **רק המספר** ולא גם השם.**
    // השרת מסמן "ודאי" כשהמספר **וגם השם** של אותו לקוח נראים על המסך.
    // אם היינו שולחים את השם מהמחסן שלנו, הבדיקה הזאת הייתה מאשרת את
    // עצמה תמיד, והסימון "ודאי" היה מאבד את המשמעות. בחירה ידנית נשארת
    // בחירה ידנית, והחלונית אומרת את זה במפורש.
    const cands = picked ? [picked] : ctx.candidates;
    // 🔴 נוסע יחד עם הזיהוי ולא בנקודת קצה משלו: הפרויקט על תקרת שתים-
    // עשרה הפונקציות של Vercel, והקובץ ה-13 מפיל את הפריסה בשלב
    // `Deploying outputs` עם לוג בנייה נקי. [[vercel_hobby_twelve_function_cap]]
    const outgoing = pendingLearn;
    const r = await send("CONTEXT", {
      form: ctx.form,
      candidates: cands,
      learnedProc: outgoing || undefined,
    });
    // ⭐ נמחק רק אחרי שהבקשה יצאה בשלום. כשל רשת ישאיר אותו לניסיון הבא.
    if (outgoing && r && r.ok) pendingLearn = null;
    loading = false;

    // ⭐ כל טעינה מרעננת גם את הספירה הגלובלית. זה חינם (הבקשה מבקשת שורה
    // אחת), והוא מה שהופך את החיווי למגיב: עובד שנע בין שורות בפריוריטי
    // מקבל את המספר העדכני בלי לחכות לדגימה של הדקה.
    pollWaiting().catch(() => {});

    if (r && r.status === 401) {
      signedIn = false;
      data = null;
      render();
      return;
    }
    signedIn = true;

    // ⭐ מה שנלמד אצל אחרים נכנס לכאן. מקומי תמיד מנצח, ראה `adopt`.
    if (r && r.data && r.data.procs) { try { C.doc.adopt(r.data.procs); } catch (_) {} }

    if (!r || !r.ok) {
      // ברענון שקט לא מוחקים את מה שכבר מוצג בגלל תקלת רשת רגעית.
      if (!silent) { error = (r && (r.error || (r.data && r.data.error))) || "הטעינה נכשלה."; data = null; }
      render(silent);
      return;
    }
    error = "";
    data = r.data;
    render(silent);
    prefetchThumbs(data && data.messages);
  }

  function startPolling() {
    stopPolling();
    // רענון שקט כל 20 שניות, רק כשהחלונית פתוחה. תשובה של הלקוח שמגיעה
    // בזמן שהחלונית פתוחה חייבת להופיע בלי שיצטרך ללחוץ.
    // 🔴 **גם השרשור וגם הרשימה, לא רק תצוגת השורה.** עד 23/08/2026
    // הטיימר קרא ל-`load` בלבד, שמרענן את הלקוח שעל המסך. שיחה פתוחה
    // בחלונית לא התרעננה בכלל: תשובה של לקוח לא הופיעה עד לחיצה על ↻,
    // ושעון חלון 24 השעות הציג את המספר מרגע הפתיחה. נתפס בהשוואה בין
    // שני צילומים באותה דקה: 22 שעות ו-34 דקות בחלונית מול 20 שעות
    // בדשבורד, והדשבורד צדק.
    pollTimer = setInterval(() => {
      if (!open) return;
      // ⭐ שתי הרשומות על המסך יחד, ולכן שתיהן מתרעננות יחד.
      loadInbox(true);
      if (chat) loadChat(chat.phone, chat.title, true);
      else if (ctx) load(true);
    }, POLL_MS);
  }
  function stopPolling() {
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  }

  // ── מה שהמסך מדווח ─────────────────────────────────────
  // 🔴 מעבר שורה בפריוריטי מאפס את הכל: הטיוטה, ערכי התבנית, והמספר
  // הידני. זה נכון, כי מרגע כזה מדובר במסמך אחר. אבל כשזה קורה **תוך כדי
  // שהמשתמש מקליד**, זה נראה כמו חלונית שמוחקת לו את מה שכתב.
  // ⭐ לכן המעבר נדחה עד שהמיקוד יוצא מהשדה, ואז מוחל **בשלמותו**.
  // דחיית הציור בלבד הייתה משאירה ערכים של מסמך אחד על הקשר של מסמך אחר,
  // וזה גרוע יותר מלמחוק: זה שולח בשם המסמך הלא נכון.
  let pendingCtx = null;
  let hasPendingCtx = false;

  function applyCtx(next) {
    if (!next) { ctx = null; data = null; render(); return; }
    ctx = next;
    data = null;
    notice = null;
    draft = "";
    tplValues = {};
    tplOpen = false;
    picked = null;
    matchOpen = false;
    // ⭐ **החלונית עוקבת אחרי המסך.** מעבר לשורה אחרת בפריוריטי מחזיר
    // את הצד ללקוח שעומדים עליו. 🔴 וההקלדה מוגנת בנפרד: `applyCtx`
    // נדחה כל עוד המיקוד בתוך שדה בחלונית, ראה `hasPendingCtx`.
    chat = null;
    chatTpl = false;
    rowTpl = false;
    linkOpen = false; linkQ = ""; linkHits = null; linkPicked = null; linkLabel = "";
    rememberOther = true; otherLabel = "";
    phoneOverride = null;
    // 🔴 גם הכרטיס. שורה אחרת בפריוריטי היא לקוח אחר.
    cardMode = false; cardData = null; cardFor = null;
    if (open) load(false); else render();
  }

  C.onChange((next) => {
    if (insideField()) { pendingCtx = next; hasPendingCtx = true; return; }
    applyCtx(next);
  });

  // ── עזרי DOM ───────────────────────────────────────────
  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  const WA_PATH = "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347M12.05 21.785h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413";
  function waIcon() {
    if (!document.createElementNS) return el("span", "rwa-glyph", "✆");
    const NS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    const p = document.createElementNS(NS, "path");
    p.setAttribute("d", WA_PATH);
    p.setAttribute("fill", "currentColor");
    svg.appendChild(p);
    return svg;
  }

  function timeText(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    const today = new Date();
    const sameDay = d.toDateString() === today.toDateString();
    const hh = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
    if (sameDay) return hh;
    return String(d.getDate()).padStart(2, "0") + "/" + String(d.getMonth() + 1).padStart(2, "0") + " " + hh;
  }

  // 🔴 מספר בתוך אלמנט LTR משלו. שורה עברית עם מספר מוטמע מתהפכת ויזואלית
  // ומציגה אותו הפוך. אותה מלכודת של הטרמינל, בתוך UI.
  function ltr(text, cls) {
    const n = el("span", cls || "rwa-ltr", text);
    n.dir = "ltr";
    return n;
  }

  // ── ציור ───────────────────────────────────────────────
  //
  // 🔴 הציור בונה את החלונית מחדש מאפס. זה בסדר כשהמשתמש ביקש משהו,
  // וזה הרסני כשזה קורה **מתחתיו**: רשימה נפתחת שנמחקת נסגרת באותו רגע,
  // וזה נראה כמו רשימה שאי אפשר ללחוץ עליה. הריענון השקט רץ כל 20 שניות
  // ולא שאל אף אחד.
  // ⭐ לכן ציור "רך" (כזה שאף אחד לא ביקש) מוותר כל עוד המשתמש נמצא בתוך
  // שדה בחלונית, ונדחה עד שהוא יוצא ממנו.
  let softPending = false;

  function insideField() {
    const a = document.activeElement;
    if (!host || !a || !host.contains(a)) return false;
    return a.tagName === "INPUT" || a.tagName === "TEXTAREA" || a.tagName === "SELECT";
  }

  // 🔴🔴 **ציור בתוך ציור, והבאג שנראה כמו "הכפתור לא מגיב".**
  // `card()` קרא ל-`loadInbox()` בזמן הציור, ו-`loadInbox` מצייר לפני
  // ה-await הראשון שלו. כלומר ציור פנימי רץ באמצע החיצוני, יצר **מארח
  // שני** והציב אותו ב-DOM, והחיצוני המשיך לכתוב לתוכו. נמדד: מיד אחרי
  // לחיצה אחת היו שני מארחים, **ארבע בועות ושני כרטיסים**, ורק כשתשובת
  // הרשימה חזרה זה התיישר. ברשת אמיתית זה שבריר שנייה עד שנייה שלמה,
  // ובו הבועה שנלחצת היא לפעמים היתומה, שהלחיצה עליה רק מחליפה מצב
  // ומיד נמחקת. מבחוץ: לוחצים ולא קורה כלום.
  // ⭐ שני תיקונים, ולא אחד: הציור נעשה חסין לכניסה כפולה **וגם** אינו
  // מפעיל טעינות. **ציור אינו אירוע, ואסור לו לשנות מצב.**
  let rendering = false;
  let renderAgain = false;

  function render(soft) {
    if (rendering) { renderAgain = true; return; }
    rendering = true;
    try { paint(soft); } finally { rendering = false; }
    if (renderAgain) { renderAgain = false; render(soft); }
  }

  function paint(soft) {
    if (soft && insideField()) { softPending = true; return; }
    softPending = false;

    if (host) { host.remove(); host = null; }
    if (Date.now() < hiddenUntil) return;

    host = el("div", "rwa-host" + (open ? " rwa-open" : ""));
    host.dir = "rtl";
    if (open) host.appendChild(card());
    host.appendChild(bubble());
    // מה שנדחה מתבצע ברגע שהמיקוד יוצא מהשדה, ולא נשכח.
    host.addEventListener("focusout", () => {
      setTimeout(() => {
        if (insideField()) return;
        if (hasPendingCtx) {
          const next = pendingCtx;
          pendingCtx = null;
          hasPendingCtx = false;
          softPending = false;
          applyCtx(next);
          return;
        }
        if (softPending) render();
      }, 0);
    });
    document.body.appendChild(host);
  }

  function bubble() {
    const wrap = el("div", "rwa-bubblewrap");

    const b = el("button", "rwa-bubble");
    b.title = "השיחה בוואטסאפ מול הלקוח";
    b.appendChild(waIcon());
    b.onclick = () => {
      open = !open;
      if (open) {
        focusWanted = "draft";
        // ⭐ **הרשימה תמיד על המסך, ולכן תמיד נטענת בפתיחה.**
        // 🔴 וזה נעשה כאן ולא בזמן הציור. `card()` קרא ל-`loadInbox()`
        // בתוך הציור, וזה מה שיצר מארח שני וגרם ללחיצה להיראות כאילו
        // אינה מגיבה. ראה את ההערה מעל `render`.
        loadInbox();
        load(false);
        // ⭐ במסך צר מוצגת רשומה אחת בלבד. כשאין למי להיצמד, הרשימה היא
        // מה שרוצים לראות. ההחלטה נעשית כאן, באירוע, ולא בזמן הציור.
        narrowList = !ctx && !chat;
        startPolling();
      } else {
        stopPolling();
      }
      render();
    };
    wrap.appendChild(b);

    // ⭐ הספירה הגלובלית. מספר ולא נקודה, כי "יש משהו" ו"מחכים לך שבעה"
    // הן שתי הודעות שונות לגמרי.
    if (waitingCount > 0) {
      const n = el("span", "rwa-count", waitingCount > 99 ? "99+" : String(waitingCount));
      n.title = waitingCount + " לקוחות מחכים לתשובה";
      wrap.appendChild(n);
    } else if (data && data.conversation && data.conversation.waiting) {
      // הלקוח שעל המסך מחכה, גם אם הספירה עוד לא הגיעה.
      // 🔴 `waiting` ולא `unansweredSince`: אחרי שקראנו את השיחה היא
      // ירדה מהרשימה, ונקודה כתומה עליה הייתה סותרת את המונה שלידה.
      wrap.appendChild(el("span", "rwa-dot"));
    }

    const x = el("button", "rwa-x", "×");
    x.title = "הסתר לשעה";
    x.onclick = (e) => { if (e && e.stopPropagation) e.stopPropagation(); hideForAnHour(); };
    wrap.appendChild(x);

    return wrap;
  }

  /**
   * ⭐⭐ **צורה אחת לחלונית, תמיד.** הרשימה מימין, ומשמאל מה שנבחר:
   * השיחה שלחצת עליה, או הלקוח שעל המסך בפריוריטי.
   *
   * 🔴🔴 **וזה תיקון של החלטה שלי, לא בקשת עיצוב.** היו כאן שתי צורות,
   * "תצוגת שורה" צרה ו"תיבה" רחבה, ומעבר ביניהן דרש כפתור. עידן פתח את
   * החלונית על שורה, קיבל את הצרה, ושאל פעמיים "למה חזרנו לעיצוב
   * הקודם?". וזה היה תיאור מדויק: מבחינתו החלונית פשוט מחליפה צורה בלי
   * שביקש. שתי צורות למוצר אחד הן מוצר שנראה כמו שני מוצרים.
   *
   * ⭐ והשורה שעל המסך לא איבדה כלום. היא פשוט הפכה לשיחה שנבחרה
   * מראש, עם אותו טופס תבנית ואותה הפקת מסמך.
   */
  function card() {
    const c = el("div", "rwa-card rwa-wide");
    c.appendChild(head());

    if (signedIn === false) { c.appendChild(signInHint()); return c; }

    const split = el("div", "rwa-split" + (narrowList ? " show-list" : ""));
    split.appendChild(inboxView());
    split.appendChild(sidePane());
    c.appendChild(split);
    return c;
  }

  /** מה שמוצג בצד: השיחה שנבחרה, או הלקוח שעל המסך, או כלום. */
  /**
   * הכרטיס עצמו, בשפת החלונית.
   *
   * ⭐ **אותו תוכן שבדשבורד, בעיצוב אחר.** שניהם קוראים מאותה פונקציה
   * במסד, ולכן אי אפשר שאחד יגיד "שובץ ליום רביעי" והשני משהו אחר.
   * העיצוב שונה כי המסך שונה: כאן 380 עד 500 פיקסלים מעל מסך עבודה.
   */
  function cardView(customerNumber, phone, title) {
    const w = el("div", "rwa-chat");

    const head = el("div", "rwa-who");
    const line = el("div", "rwa-cardhead");
    line.appendChild(el("div", "rwa-whoname", (cardData && cardData.customer && cardData.customer.name) || title || "לקוח"));
    line.appendChild(cardToggle(customerNumber, phone));
    head.appendChild(line);
    w.appendChild(head);

    if (cardLoading && !cardData) { w.appendChild(empty("טוען את הכרטיס…")); return w; }
    if (!cardData || cardData.ok === false) { w.appendChild(empty("לא הצלחתי לטעון את הכרטיס.")); return w; }

    const c = cardData.customer || {};
    const body = el("div", "rwa-cardbody");

    // ── מי הלקוח ──
    const meta = el("div", "rwa-whometa");
    if (c.customerNumber) { meta.appendChild(el("span", null, "לקוח ")); meta.appendChild(ltr(c.customerNumber)); meta.appendChild(el("span", "rwa-sep", "·")); }
    if (c.phone) meta.appendChild(ltr(c.phone));
    body.appendChild(meta);
    const addr = [c.address, c.city].filter(Boolean).join(", ");
    if (addr) body.appendChild(el("div", "rwa-cardsub", addr));
    const tags = [c.healthFund, c.agent ? "סוכן: " + c.agent : ""].filter(Boolean);
    if (tags.length) body.appendChild(el("div", "rwa-cardsub", tags.join(" · ")));

    // ── התשובה ללקוח ──
    const ans = answerText(cardData.open, cardData.stock);
    const ansBox = el("div", "rwa-answer " + ans.tone);
    ansBox.appendChild(el("div", "rwa-answerlb", "התשובה ללקוח"));
    ansBox.appendChild(el("div", "rwa-answertx", ans.text));
    body.appendChild(ansBox);

    // 🔴 הטלפון שכותב אינו הטלפון שרשום בפריוריטי.
    const idn = S().identityNote(c);
    if (idn) body.appendChild(el("div", "rwa-idnote", idn));

    // ── מה יש אצל הלקוח ──
    // ⭐ לפני הפתוחים ולפני ציר הפעילות: זו השאלה הראשונה שנשאלת
    // כשלקוח מתקשר, והיא לא צריכה גלילה.
    body.appendChild(stockStrip(cardData.stock, { full: true }));

    // ── פתוחים ──
    const strip = openStrip(cardData.open);
    if (strip) body.appendChild(strip);

    // ── ציר הפעילות ──
    const tl = (cardData.timeline || []);
    if (tl.length) {
      body.appendChild(el("div", "rwa-cardtitle", "ציר הפעילות"));
      const list = el("div", "rwa-tl");
      for (const e of tl.slice(0, 14)) {
        const row = el("div", "rwa-tlrow rwa-k-" + (e.kind || "note"));
        const h = el("div", "rwa-tlhead");
        h.appendChild(el("span", "rwa-tldt", shortDate(e.at)));
        h.appendChild(el("span", "rwa-tlti", e.title || ""));
        if (e.ref) h.appendChild(ltr(e.ref));
        row.appendChild(h);
        if (e.detail) row.appendChild(el("div", "rwa-tlds", String(e.detail).slice(0, 120)));
        list.appendChild(row);
      }
      body.appendChild(list);
      if (tl.length > 14) body.appendChild(el("div", "rwa-openmore", "ועוד " + (tl.length - 14) + " אירועים"));
    }

    // ── סקרים ──
    const sv = cardData.surveys || [];
    if (sv.length) {
      body.appendChild(el("div", "rwa-cardtitle", "סקר שביעות רצון"));
      for (const s2 of sv.slice(0, 3)) {
        const row = el("div", "rwa-eqrow");
        row.appendChild(el("div", "rwa-tlti", (s2.q1 == null ? "—" : s2.q1) + " מתוך 5 · " + shortDate(s2.at)));
        if (s2.comment) row.appendChild(el("div", "rwa-tlds", '"' + s2.comment + '"'));
        body.appendChild(row);
      }
    }

    // ── מסמכים ──
    const docs = (cardData.documents && cardData.documents.notes) || [];
    const invs = (cardData.documents && cardData.documents.invoices) || [];
    if (docs.length || invs.length) {
      body.appendChild(el("div", "rwa-cardtitle", "מסמכים אחרונים"));
      for (const d of docs.slice(0, 4)) {
        const row = el("div", "rwa-docrow");
        row.appendChild(el("span", null, "תעודה"));
        row.appendChild(ltr(String(d.ref || "")));
        row.appendChild(el("span", "rwa-docdt", shortDate(d.date)));
        body.appendChild(row);
      }
      for (const d of invs.slice(0, 4)) {
        const row = el("div", "rwa-docrow");
        row.appendChild(el("span", null, "חשבונית"));
        row.appendChild(ltr(String(d.ref || "")));
        row.appendChild(el("span", "rwa-docdt", shortDate(d.date)));
        body.appendChild(row);
      }
    }

    w.appendChild(body);
    return w;
  }

  /**
   * המשפט שהנציג אומר ללקוח.
   *
   * 🔴 **"שובץ" נגזר מהעצירה ביומן ולא מהסטטוס**, וההכרעה עצמה נעשתה
   * כבר בשרת. כאן רק מנסחים אותה. אותו ניסוח בדיוק קיים בדשבורד
   * (`lib/customer-answer.ts`), ושם הוא גם נבדק ביחידה.
   */
  function answerText(open, stock) {
    const orders = (open && open.orders) || [];
    const calls = (open && open.calls) || [];
    const sched = orders.filter((o) => o.scheduled)[0];
    if (sched) {
      // ⭐ במשפט שנאמר ללקוח בטלפון, שנה מלאה. הוא לא רואה את המסך.
      const bits = ["שובץ ל" + S().fullDate(sched.date)];
      if (sched.driver) bits.push("נהג " + sched.driver);
      const head = orders.length > 1 ? "יש " + orders.length + " משלוחים פתוחים, אחד מהם" : "יש משלוח פתוח,";
      return { tone: "rwa-ok", text: head + " " + bits.join(", ") + "." };
    }
    if (orders.length) {
      const age = waitText(minutesSince(orders[0].created));
      const head = orders.length > 1 ? "יש " + orders.length + " משלוחים פתוחים, עדיין לא שובצו" : "יש משלוח פתוח, עדיין לא שובץ";
      return { tone: "rwa-wait", text: head + " לאספקה. ממתין " + age + "." };
    }
    const cs = calls.filter((c) => c.scheduled)[0];
    if (cs) return { tone: "rwa-ok", text: "אין משלוח פתוח. קריאת שירות שובצה ל" + S().fullDate(cs.date) + "." };
    if (calls.length) return { tone: "rwa-wait", text: "אין משלוח פתוח. יש קריאת שירות פתוחה שלא שובצה." };
    // 🔴🔴 **"אין שום פריט פתוח" לבד הוא חצי תשובה.** עידן, 25/08/2026:
    // "זה מבלבל בגלל שיש אצלו מוצר." הקופסה אמרה "אין כלום" והרצועה
    // שמתחתיה אמרה "יש לו מנוף", ושתיהן צדקו.
    const owned = S().devicePhrase(stock && stock.devices);
    if (owned) return { tone: "rwa-ok", text: "אין משלוח, קריאה או איסוף פתוחים. " + owned };
    return { tone: "", text: "אין ללקוח הזה שום פריט פתוח." };
  }

  function sidePane() {
    // ⭐ הכרטיס מחליף את הפאנל כולו, ולא נדחס לצידו. ברוחב הזה שתי
    // עמודות היו הופכות את שתיהן לבלתי קריאות.
    if (cardMode) {
      if (chat) return cardView((chat.data && chat.data.conversation && chat.data.conversation.customerNumber) || null, chat.phone, chat.title);
      if (data && data.customer) return cardView(data.customer.customerNumber, data.customer.phone, data.customer.customerName);
      cardMode = false;
    }
    if (chat) return chatView();
    if (!ctx) {
      return el("div", "rwa-pane-empty",
        "בחר שיחה מהרשימה, או עמוד על לקוח בפריוריטי");
    }
    return rowPane();
  }

  // ═══════════════════════════════════════════════════════
  // רצועת המקור: על מי אני עומד, ולמה זה משנה
  // ═══════════════════════════════════════════════════════
  //
  // ⭐⭐ **עידן, 06/09/2026, מהמשרד של ר.שעל, מול צילום של החלונית על
  // לקוח שזוהה מהמסך:** "זאת הנקודה היחידה במערכת שאני יכול לשלוח ללקוח
  // מסמך מתוך הפריוריטי. לדעתי זה לא מספיק בולט שאני נמצא עכשיו על לקוח
  // מהפריוריטי ולא על לקוח מהרשימה הרגילה בוואטסאפ."
  //
  // והוא צדק: הכותרת של לקוח מהמסך והכותרת של שיחה מהרשימה היו זהות
  // לגמרי (שם, מספרים, כפתור כרטיס), והחלונית הסתירה את ההבדל הכי חשוב
  // שיש בה: **מהמסך אפשר להפיק ולשלוח מסמך, מהרשימה לא.** זו גם הטעות
  // הקלה: לבחור מישהו מהרשימה, לחזור לפריוריטי, ולשלוח למי שנבחר במקום
  // למי שעל המסך.
  //
  // ⭐ **שורה אחת מעל הכותרת, לא צבע על כל החלונית.** ירוק כשהלקוח
  // מהמסך (עם המסמך שעליו עומדים וכפתור המסמך בתוכה, כדי שיהיה ברור
  // שהיכולת שייכת למצב הזה), אפור כשהוא מהרשימה, עם דרך חזרה ללקוח
  // שעל המסך. צבע על כל הכותרת היה הופך לרעש אחרי יום.

  function docTemplate(d) {
    return ((d && d.templates) || []).find((t) => t.available && t.needsDocument) || null;
  }

  function screenStrip(d) {
    const s = el("div", "rwa-origin rwa-origin-screen");
    const lead = el("div", "rwa-originlead");
    lead.appendChild(el("span", "rwa-originmark", "P"));
    const txt = el("span", "rwa-origintext");
    txt.appendChild(el("strong", null, "על המסך בפריוריטי"));
    const pf = d.prefill || {};
    if (pf.doc_type || pf.doc_number) {
      txt.appendChild(el("span", "rwa-sep", "·"));
      if (pf.doc_type) txt.appendChild(el("span", null, pf.doc_type + " "));
      if (pf.doc_number) txt.appendChild(ltr(pf.doc_number));
    }
    lead.appendChild(txt);
    s.appendChild(lead);

    // ⭐ כפתור המסמך יושב ברצועה: מכאן, ורק מכאן, יוצא מסמך מפריוריטי.
    // 🔴 עד היום, כשחלון 24 השעות היה פתוח, הצד של השורה הציג טקסט חופשי
    // בלבד ותבנית עם מסמך לא הייתה נגישה בכלל. הכפתור פותח אותה בכל מצב.
    const tpl = docTemplate(d);
    if (tpl && !rowTpl) {
      const b = el("button", "rwa-originbtn");
      b.appendChild(el("span", null, "📎"));
      // 🔴 "שלח מסמך מכאן" נקרא כשליחה מיידית (עידן, 06/09/2026, ברגע
      // ההתקנה במשרד: "זה ישר שולח?"). הכפתור רק בוחר את תבנית המסמך;
      // השליחה נשארת בכפתור "הפק ושלח מסמך" שמתחת לתצוגה המקדימה.
      b.appendChild(el("span", null, "הכן מסמך לשליחה"));
      b.onclick = () => { tplKey = tpl.key; tplValues = {}; tplOpen = false; rowTpl = true; render(); };
      s.appendChild(b);
    }
    return s;
  }

  // ─── שיחה לא מזוהה: הצעה ושיוך (עידן, 06/09/2026) ──────────────────
  // "יש לקוחות ששולחים לנו תמונות לוואטסאפ אבל אין להם כרטיס לקוח" (הבת
  // שולחת מהטלפון שלה). המערכת מציעה (ת.ז. שנכתבה בתשובה, או טלפון שרשום
  // אצל כמה לקוחות) והעובד מחליט בלחיצה. אף פעם לא שיוך בלי לחיצה.
  function unidentifiedStrip(conv) {
    const s = el("div", "rwa-origin rwa-origin-unk");
    const lead = el("div", "rwa-originlead rwa-originlead-wrap");
    lead.appendChild(el("strong", null, "לא מזוהה"));
    const sug = Array.isArray(conv.suggested) ? conv.suggested.slice(0, 3) : [];
    if (sug.length) {
      lead.appendChild(el("span", "rwa-sep", "·"));
      lead.appendChild(el("span", null, "נראה שזה:"));
      for (const c of sug) {
        const b = el("button", "rwa-originbtn");
        const how = c.by === "id" ? " (לפי ת.ז.)" : c.by === "phone" ? " (הטלפון רשום אצלו)" : c.by === "contact" ? " (איש קשר: " + (c.label || "") + ")" : c.by === "name" ? " (לפי השם)" : "";
        b.textContent = "כן, זה " + (c.customer_name || c.customer_number) + how;
        b.disabled = linkBusy;
        b.onclick = () => doLink(conv.id, c.customer_number, c.label || "", true);
        lead.appendChild(b);
      }
    } else if (conv.identityAskedAt) {
      lead.appendChild(el("span", "rwa-sep", "·"));
      lead.appendChild(el("span", null, "ביקשנו שם ות.ז., עדיין אין תשובה"));
    } else {
      lead.appendChild(el("span", "rwa-sep", "·"));
      lead.appendChild(el("span", null, "המספר לא שייך לאף לקוח"));
    }
    s.appendChild(lead);
    const open = el("button", "rwa-originbtn rwa-originbtn-amber", linkOpen ? "סגור" : "שייך ללקוח");
    open.onclick = () => { linkOpen = !linkOpen; if (linkOpen) focusWanted = "linkq"; render(); };
    s.appendChild(open);
    return s;
  }

  async function doLink(conversationId, customerNumber, label, remember) {
    if (linkBusy) return;
    linkBusy = true; render();
    const r = await send("LINK", { conversationId, customerNumber, label: label || null, remember: remember !== false });
    linkBusy = false;
    const payload = (r && r.data) || {};
    if (r && r.ok && payload.ok) {
      const photos = Number(payload.photos || 0);
      notice = { text: "שויך ל" + (payload.customerName || customerNumber) + "." + (photos ? " " + photos + " תמונות עברו לכרטיס ויעלו לפריוריטי." : ""), tone: "ok" };
      linkOpen = false; linkQ = ""; linkHits = null; linkPicked = null; linkLabel = "";
      if (chat) { await loadChat(chat.phone, payload.customerName || chat.title); loadInbox(); }
    } else {
      notice = { text: payload.error || (r && r.error) || "השיוך נכשל.", tone: "bad" };
    }
    render();
  }

  let linkTimer = null;
  function linkBox(conv) {
    const box = el("div", "rwa-linkbox");
    if (!linkPicked) {
      const inp = document.createElement("input");
      inp.className = "rwa-input rwa-linkq";
      inp.dir = "rtl";
      inp.placeholder = "שם, מספר לקוח, טלפון או מספר מסמך";
      inp.value = linkQ;
      inp.addEventListener("input", () => {
        linkQ = inp.value;
        if (linkTimer) clearTimeout(linkTimer);
        if (linkQ.trim().length < 2) { linkHits = null; return; }
        linkTimer = setTimeout(async () => {
          const r = await send("SEARCH", { q: linkQ.trim() });
          linkHits = (r && r.ok && r.data && r.data.people) || [];
          focusWanted = "linkq";
          render();
        }, 300);
      });
      box.appendChild(inp);
      takeFocus("linkq", inp);
      if (linkHits && linkHits.length === 0) box.appendChild(el("div", "rwa-linkempty", "אין לקוח שמתאים לחיפוש."));
      if (linkHits && linkHits.length) {
        const list = el("div", "rwa-picklist rwa-linklist");
        for (const c of linkHits.slice(0, 10)) {
          if (!c.customer_number) continue;
          const o = el("button", "rwa-pickopt");
          const st = el("span", "rwa-pickstack");
          st.appendChild(el("span", null, (c.customer_name || "לקוח") + (c.city ? " · " + c.city : "")));
          st.appendChild(ltr(c.customer_number));
          o.appendChild(st);
          o.onclick = () => { linkPicked = { customer_number: c.customer_number, customer_name: c.customer_name, city: c.city }; focusWanted = "linklabel"; render(); };
          list.appendChild(o);
        }
        box.appendChild(list);
      }
      return box;
    }
    const chosen = el("div", "rwa-linkchosen");
    const st = el("span", "rwa-pickstack");
    st.appendChild(el("span", null, (linkPicked.customer_name || "לקוח") + (linkPicked.city ? " · " + linkPicked.city : "")));
    st.appendChild(ltr(linkPicked.customer_number));
    chosen.appendChild(st);
    const swap = el("button", "rwa-link", "החלף");
    swap.onclick = () => { linkPicked = null; focusWanted = "linkq"; render(); };
    chosen.appendChild(swap);
    box.appendChild(chosen);

    const lab = document.createElement("input");
    lab.className = "rwa-input rwa-linklabel";
    lab.dir = "rtl";
    lab.placeholder = "מי זה? (לא חובה) · הבת, מיכל";
    lab.value = linkLabel;
    lab.addEventListener("input", () => { linkLabel = lab.value; });
    box.appendChild(lab);
    takeFocus("linklabel", lab);

    const chk = el("label", "rwa-chk");
    const cb = document.createElement("input");
    cb.type = "checkbox"; cb.checked = linkRemember;
    cb.addEventListener("change", () => { linkRemember = cb.checked; });
    chk.appendChild(cb);
    chk.appendChild(el("span", null, "לזכור את המספר ללקוח. הודעות ותמונות ממנו יזוהו כשלו, וההודעות האוטומטיות יישלחו גם אליו."));
    box.appendChild(chk);

    const row = el("div", "rwa-row rwa-row-split");
    row.appendChild(el("span", "rwa-rowspacer", ""));
    const go = el("button", "rwa-send", linkBusy ? "משייך…" : "שייך");
    go.disabled = linkBusy;
    go.onclick = () => doLink(conv.id, linkPicked.customer_number, linkLabel, linkRemember);
    row.appendChild(go);
    box.appendChild(row);
    return box;
  }

  // "שלח למספר אחר": אחרי שליחה מוצלחת, המספר נשמר ללקוח שעל המסך.
  async function rememberIfAsked(phone, d) {
    if (phoneOverride == null || !rememberOther) return;
    const cust = d && d.customer && d.customer.customerNumber;
    if (!cust || !isMobileNumber(phone)) return;
    const r = await send("REMEMBER", { customerNumber: cust, phone, label: otherLabel || null });
    if (r && r.ok && r.data && r.data.ok) {
      notice = { text: (notice ? notice.text + " " : "") + "המספר " + phone + " נשמר כאיש קשר של " + (d.customer.customerName || "הלקוח") + ".", tone: "ok" };
    }
  }

  function listStrip() {
    const conv = chat && chat.data && chat.data.conversation;
    if (conv && !conv.customerNumber) return unidentifiedStrip(conv);
    const s = el("div", "rwa-origin rwa-origin-list");
    const txt = el("span", "rwa-origintext");
    txt.appendChild(el("strong", null, "מהרשימה"));
    txt.appendChild(el("span", "rwa-sep", "·"));
    txt.appendChild(el("span", null, "בלי מסמך מפריוריטי"));
    s.appendChild(txt);
    const sc = data && data.customer;
    if (ctx && sc) {
      const b = el("button", "rwa-link rwa-originback",
        "חזרה ל" + (sc.customerName || "לקוח") + " שעל המסך");
      b.onclick = () => { chat = null; chatTpl = false; render(); };
      s.appendChild(b);
    }
    return s;
  }

  /**
   * הלקוח שעל המסך בפריוריטי, כשיחה בצד.
   *
   * ⭐ זה בדיוק מה שהיה "תצוגת השורה", כולל הפקת מסמך מהמסך. רק המקום
   * השתנה: הוא יושב עכשיו באותו חלון שבו יושבת כל שיחה אחרת.
   */
  function rowPane() {
    const w = el("div", "rwa-chat");

    if (loading && !data) { w.appendChild(empty("טוען…")); return w; }
    if (error) { w.appendChild(empty(error, "rwa-bad")); return w; }
    if (!data) { w.appendChild(empty("טוען…")); return w; }
    if (!data.customer) {
      w.appendChild(empty("לא זיהיתי כאן לקוח. השורה הזאת לא מכילה מספר לקוח שמוכר לנו."));
      return w;
    }

    w.appendChild(screenStrip(data));
    w.appendChild(who(data));
    const win = windowBanner(data.window);
    if (win) w.appendChild(win);

    // ⭐ **אזור השיחה נעלם כשאין שיחה** (החלטת עידן, 22/08/2026).
    // קודם הוא תפס אזור בגובה מלא כדי לומר "עוד לא דיברתם", וזו שורה
    // אחת של מידע ששילמה בשליש מגובה הכרטיס. כשאין היסטוריה, המשפט
    // יושב בשורת המשנה של הלקוח.
    const msgs = data.messages || [];
    if (msgs.length) w.appendChild(thread(msgs));

    const comp = composer(data);
    // טופס התבנית גבוה. כשהוא פתוח הוא מקבל תקרה, אחרת השרשור נמחק
    // והטופס נדחס. ראה `panel.css`.
    if (comp.querySelector(".rwa-tplbox")) comp.classList.add("rwa-tplmode");
    w.appendChild(comp);
    return w;
  }

  // ═══════════════════════════════════════════════════════
  // התיבה: כל השיחות, בלי קשר לשורה שעל המסך
  // ═══════════════════════════════════════════════════════

  /**
   * ⭐⭐ **לקוחות שאין איתם שיחה.**
   *
   * עידן, 25/08/2026, מול צילום של מסך הלקוחות בפריוריטי: "למה אני לא
   * רואה את כל השלומים האלה?" החיפוש בחלונית חיפש בתוך השיחות בלבד,
   * כלומר בתוך 42 שורות, בזמן שבמחסן יושבים עשרות אלפי לקוחות.
   *
   * 🔴 **שתי אותיות לפחות.** אות אחת מחזירה מאות שורות ובקשה על כל
   * הקלדה.
   */
  async function loadPeople() {
    const q = String(inboxQ || "").trim();
    if (q.length < 2) { people = null; peopleFor = ""; return; }
    if (peopleFor === q) return;
    peopleFor = q;
    const r = await send("SEARCH", { q: q });
    // 🔴 רק אם עוד מחפשים את אותו דבר. תשובה איטית שחוזרת אחרי הקלדה
    // נוספת הייתה מציגה תוצאות של חיפוש קודם.
    if (peopleFor !== q) return;
    people = (r && r.ok && r.data && r.data.ok) ? (r.data.people || []) : [];
    // 🔴🔴 **הציור הזה בונה מחדש את שדה החיפוש, ולכן חייב להחזיר אליו
    // את הסמן.** עידן, 25/08/2026: "הסמן בחיפוש מידי פעם מאבד את השדה,
    // אני לוחץ לחפש והסמן יוצא משם לבד." זה נכנס איתי: תשובת החיפוש
    // חוזרת אחרי כמה מאות מילישניות, בדיוק באמצע הקלדה, והציור החליף
    // את השדה מתחת לאצבעות. הנתיב השני (`loadInbox`) כבר עשה את זה.
    // 🔴 **ציור מלא ולא רך, בדיוק כמו `loadInbox`.** ציור רך נדחה כל
    // עוד הסמן בתוך שדה (`insideField`), כלומר תוצאות החיפוש לא היו
    // מופיעות בכלל כל זמן שמקלידים, וזה כל הזמן שבו הן נחוצות.
    focusWanted = "search";
    render();
  }

  /**
   * שורת לקוח שאין איתו שיחה.
   *
   * ⭐ לחיצה פותחת את **כרטיס הלקוח**, ולא שיחה. פתיחת שיחה פירושה
   * שליחת הודעה, וזו פעולה שיוצאת ללקוח אמיתי; הכרטיס הוא מה שהנציגה
   * צריכה כדי להחליט אם בכלל לפנות.
   */
  function personRow(c) {
    const row = el("button", "rwa-personrow");
    const head = el("div", "rwa-tlhead");
    head.appendChild(el("span", "rwa-tlti", c.customer_name || "לקוח"));
    if (c.customer_number) head.appendChild(ltr(String(c.customer_number)));
    row.appendChild(head);
    const bits = [];
    if (c.phone_local) bits.push(c.phone_local);
    if (c.city) bits.push(c.city);
    if (bits.length) row.appendChild(el("div", "rwa-tlds", bits.join(" · ")));
    row.onclick = () => {
      cardMode = true;
      chat = null;
      loadCard(c.customer_number || null, c.phone_local || null).catch(() => {});
      render();
    };
    return row;
  }

  async function loadInbox(silent) {
    if (inboxLoading) return;
    if (!silent) { inboxLoading = true; render(); }
    const r = await send("INBOX", { tab: inboxTab, q: inboxQ, includeAuto: includeAuto ? 1 : 0 });
    if (!silent) inboxLoading = false;
    if (r && r.status === 401) { signedIn = false; render(); return; }
    const p = (r && r.data) || {};
    if (r && r.ok && p.ok) {
      inbox = { items: p.items || [], counts: p.counts || { waiting: 0, all: 0 } };
      // ⭐ הספירה על הבועה מתעדכנת מאותה תשובה, בלי סבב נוסף.
      waitingCount = Number(inbox.counts.waiting || 0);

      // ⭐ **בחירה אוטומטית של הראשון, בדיוק כמו בדשבורד.** מסך שנפתח
      // עם צד ריק מבקש מהמשתמש עוד לחיצה כדי להגיע למצב הברור מאליו.
      // 🔴 רק כשאין למי להיצמד: שיחה שנבחרה, או לקוח שעל המסך, גוברים.
      if (!chat && !ctx && (p.items || []).length) {
        const first = p.items[0];
        loadChat(first.phone, first.title, silent);
      }

      // ⭐ אין ממתינים, ולכן עוברים לכל השיחות. ראה `tabAutoSwitched`.
      if (!tabAutoSwitched && inboxTab === "waiting" && waitingCount === 0) {
        tabAutoSwitched = true;
        inboxTab = "all";
        inboxLoading = false;
        loadInbox(silent);
        return;
      }
    } else if (!silent) {
      notice = { text: p.message || "לא הצלחתי לטעון את השיחות.", tone: "bad" };
    }
    render(silent);
  }

  /**
   * @param silent כשאמת, השרשור שעל המסך נשאר עד שהתשובה מגיעה.
   *
   * 🔴 **בלי זה הרענון האוטומטי היה מרצד:** `chat.data = null` מרוקן את
   * השרשור, המסך מציג "טוען" לרגע, וכל 20 שניות זה היה קופץ וחוזר.
   */
  /**
   * מסמן שהעובד פתח את השיחה, ולכן היא כבר לא "ממתינה".
   *
   * 🔴🔴 **רק מלחיצה, אף פעם לא מטעינה.** החלונית טוענת שרשור לבד בכל
   * פעם שעומדים על שורה בפריוריטי, ומרעננת בשקט כל עשרים שניות. אילו
   * טעינה הייתה מסמנת קריאה, שיחה שאיש לא ראה הייתה נעלמת מהרשימה
   * ומהמונה שעל הבועה. [[render_is_not_a_user_event]]
   *
   * ⭐ ונכשל בשקט: סימון שלא נרשם משאיר את השיחה ברשימה, וזו התוצאה
   * הבטוחה מבין השתיים.
   */
  /**
   * טוען את הכרטיס. נקרא **מלחיצה**, אף פעם לא מציור.
   * [[render_must_not_start_work]]
   */
  async function loadCard(customerNumber, phone) {
    const key = (customerNumber || "") + "|" + (phone || "");
    if (cardFor === key && cardData) return;
    cardFor = key;
    cardData = null;
    cardLoading = true;
    render();
    const r = await send("CARD", { customer: customerNumber || null, phone: phone || null });
    cardLoading = false;
    if (r && r.status === 401) { signedIn = false; render(); return; }
    const p = (r && r.data) || {};
    // 🔴 רק אם עוד עומדים על אותו לקוח. תשובה איטית שחוזרת אחרי מעבר
    // הייתה מציגה את התיק של מישהו אחר.
    if (cardFor === key) cardData = (r && r.ok && p.ok) ? p.card : null;
    render();
  }

  /** הכפתור שמחליף בין השיחה לכרטיס. */
  function cardToggle(customerNumber, phone) {
    // ⭐ הכיתוב אומר לאן חוזרים, ולא "חזרה" סתם. נכנסים לכרטיס גם משיחה
    // וגם מלקוח שעומדים עליו בפריוריטי, ואלה שני מקומות שונים.
    const back = chat ? "חזרה לשיחה" : "חזרה ללקוח";
    const b = el("button", "rwa-cardtog" + (cardMode ? " rwa-on" : ""),
      cardMode ? back : "כרטיס לקוח");
    b.onclick = () => {
      cardMode = !cardMode;
      if (cardMode) loadCard(customerNumber, phone); else render();
    };
    return b;
  }

  async function markRead(phone) {
    if (!phone) return;
    try {
      await send("MARK_READ", { phone: phone });
    } catch (_) { return; }
    // הרשימה והמונה נשאלים מחדש, כדי שהתג הכתום ירד מיד.
    loadInbox(true);
    pollWaiting().catch(() => {});
  }

  async function loadChat(phone, title, silent) {
    if (!silent) {
      chatStick = true;
      // 🔴 שיחה חדשה פותחת תמיד בכתיבה חופשית. טופס תבנית שנשאר פתוח
      // מלקוח קודם הוא בדיוק איך ששולחים למישהו את מה שלא התכוונו.
      chatTpl = false;
      chat = { phone: phone, title: title, data: null };
      // 🔴 כרטיס של לקוח קודם שנשאר פתוח היה מציג תיק של מישהו אחר.
      cardMode = false; cardData = null; cardFor = null;
      chatLoading = true;
      // ⭐ במסך צר, בחירה מהרשימה פירושה שרוצים לראות את השיחה עצמה.
      narrowList = false;
      render();
    }
    const r = await send("THREAD", { phone: phone });
    if (!silent) chatLoading = false;
    if (r && r.status === 401) { signedIn = false; render(); return; }
    const p = (r && r.data) || {};
    if (r && r.ok && p.ok) {
      if (chat && chat.phone === phone) chat.data = p;
    } else if (!silent) {
      notice = { text: p.message || "לא הצלחתי לטעון את השיחה.", tone: "bad" };
    }
    render(silent);
    prefetchThumbs(p.messages);
    if (!silent) markRead(phone);
  }

  /** כמה זמן מחכים, בעברית. זהה במכוון ל-`waitLabel` שבשרת ובדשבורד. */
  function waitText(minutes) {
    if (minutes == null) return "";
    if (minutes < 1) return "עכשיו";
    if (minutes < 60) return minutes + " דקות";
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return hours === 1 ? "שעה" : hours === 2 ? "שעתיים" : hours + " שעות";
    const days = Math.floor(hours / 24);
    return days === 1 ? "יום" : days === 2 ? "יומיים" : days + " ימים";
  }

  function inboxView() {
    const w = el("div", "rwa-inbox");

    // ── הלשוניות ──
    const tabs = el("div", "rwa-tabs");
    const counts = (inbox && inbox.counts) || { waiting: 0, all: 0 };
    [["waiting", "ממתינים", counts.waiting], ["all", "כל השיחות", counts.all]].forEach(function (t) {
      const b = el("button", "rwa-tab" + (inboxTab === t[0] ? " rwa-tab-on" : ""));
      b.appendChild(el("span", null, t[1]));
      b.appendChild(el("span", "rwa-tabn", String(t[2] || 0)));
      b.onclick = () => { tabAutoSwitched = true; inboxTab = t[0]; loadInbox(); };
      tabs.appendChild(b);
    });
    w.appendChild(tabs);

    // ⭐ "כל השיחות" בלי השיחות שכולן אוטומט (189 מ-274), מאחורי מתג.
    if (inboxTab === "all") {
      const n = Number((inbox && inbox.counts && inbox.counts.autoOnly) || 0);
      const tg = el("label", "rwa-autotoggle");
      const cb = document.createElement("input");
      cb.type = "checkbox"; cb.checked = includeAuto;
      cb.addEventListener("change", () => { includeAuto = cb.checked; loadInbox(); });
      tg.appendChild(cb);
      tg.appendChild(el("span", null, "הצג גם שיחות אוטומטיות בלבד" + (n ? " (" + n + ")" : "")));
      w.appendChild(tg);
    }

    // ── החיפוש ──
    const inp = document.createElement("input");
    inp.className = "rwa-input rwa-search";
    inp.type = "text";
    inp.dir = "rtl";
    inp.value = inboxQ;
    inp.placeholder = "שם, מספר לקוח, טלפון או תוכן";
    let timer = null;
    inp.addEventListener("input", () => {
      inboxQ = inp.value;
      loadPeople().catch(() => {});
      // 🔴 השהיה קצרה. חיפוש בכל הקלדה היה מייצר בקשה לכל אות, והתשובות
      // היו חוזרות בסדר לא צפוי ומחליפות זו את זו על המסך.
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => { focusWanted = "search"; loadInbox(); }, 350);
    });
    w.appendChild(inp);
    takeFocus("search", inp);

    // ── הרשימה ──
    const list = el("div", "rwa-list");
    if (inboxLoading && !inbox) {
      list.appendChild(el("div", "rwa-empty", "טוען…"));
    } else if (!inbox || !inbox.items.length) {
      list.appendChild(el("div", "rwa-empty",
        inboxTab === "waiting" ? "אף לקוח לא מחכה לתשובה."
          : inboxQ ? "אין שיחה שמתאימה לחיפוש." : "עוד אין שיחות."));
    } else {
      inbox.items.forEach(function (it) {
        list.appendChild(inboxRow(it));
      });
    }

    // ⭐ לקוחות בלי שיחה, מתחת לרשימה. 🔴 בלי לשכפל את מי שכבר מופיע.
    if (String(inboxQ || "").trim().length >= 2 && people && people.length) {
      const seen = {};
      for (const it of ((inbox && inbox.items) || [])) if (it.phone) seen[it.phone] = 1;
      const rest = people.filter((c) => !c.phone_local || !seen[c.phone_local]);
      if (rest.length) {
        list.appendChild(el("div", "rwa-peoplehead", "לקוחות בלי שיחה (" + rest.length + ")"));
        for (const c of rest.slice(0, 25)) list.appendChild(personRow(c));
      }
    }
    w.appendChild(list);
    return w;
  }

  /**
   * 🔴 **מעל כמה זמן המתנה היא באמת חריגה.** עידן, 25/08/2026:
   * "הצהוב הזה צורם לי בעין... אני רוצה משהו נעים ועדין יותר."
   *
   * השורש לא היה הגוון אלא הכמות: **כל שורה שמישהו מחכה בה** נצבעה
   * בענבר, וברשימה שרובה כזאת הענבר מפסיק לסמן חריגה ונהיה הרקע.
   * צבע שמופיע על הכל אינו צבע, הוא רעש. מעכשיו הענבר שמור למי שבאמת
   * מחכה יותר משעתיים, וגם אז הוא **טקסט ולא מילוי**.
   */
  const LATE_MINUTES = 120;

  function inboxRow(it) {
    const waiting = it.waitingMinutes != null;
    const late = waiting && it.waitingMinutes >= LATE_MINUTES;
    // ⭐ השיחה של הלקוח שעל המסך בפריוריטי מסומנת גם ברשימה, כדי שגם
    // כשגוללים רואים מי הלקוח הנוכחי. ראה `screenStrip`.
    const sc = data && data.customer;
    const onScreen = Boolean(sc && (
      (it.customerNumber && it.customerNumber === sc.customerNumber) ||
      (it.phone && sc.phone && it.phone === sc.phone)));
    const r = el("button", "rwa-lrow" + (late ? " rwa-lrow-late" : "") + (onScreen ? " rwa-lrow-screen" : "") + (it.autoOnly ? " rwa-lrow-auto" : ""));

    const top = el("div", "rwa-lname");
    const name = el("span", "rwa-ltitle");
    // ⭐ חלון פתוח נאמר בנקודה ירוקה קטנה לפני השם, במקום בתגית מלאה.
    // חלון סגור הוא המצב הרגיל, ולכן אינו נאמר בכלל.
    if (it.window && it.window.open) name.appendChild(el("span", "rwa-ldot"));
    name.appendChild(el("span", null, it.title || "לקוח"));
    if (onScreen) name.appendChild(el("span", "rwa-ltag-screen", "על המסך"));
    top.appendChild(name);
    top.appendChild(el("span", "rwa-ltime", shortTime(it.lastMessageAt)));
    r.appendChild(top);

    if (it.preview) r.appendChild(el("div", "rwa-lprev", it.preview));

    // שורת המשנה: טקסט שקט, בלי גלולות צבע.
    const bits = [];
    if (it.contactLabel) bits.push(it.contactLabel);
    if (waiting) bits.push("מחכה " + waitText(it.waitingMinutes));
    // 🔴 "לא מזוהה" נאמר בגלוי: זו השיחה שאי אפשר לקשר למסמך בפריוריטי.
    if (it.unidentified) bits.push("לא מזוהה");
    if (bits.length) {
      r.appendChild(el("div", "rwa-lmeta" + (late ? " rwa-late" : ""), bits.join(" · ")));
    }

    r.onclick = () => loadChat(it.phone, it.title);
    return r;
  }

  function shortTime(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    const today = new Date();
    if (d.toDateString() === today.toDateString()) return timeText(iso);
    const y = new Date(today.getTime() - 86400000);
    if (d.toDateString() === y.toDateString()) return "אתמול";
    return d.toLocaleDateString("he-IL", { day: "2-digit", month: "2-digit" });
  }

  function chatView() {
    const w = el("div", "rwa-chat");
    if (!chat) { w.appendChild(el("div", "rwa-empty", "לא נבחרה שיחה.")); return w; }

    w.appendChild(listStrip());
    const d = chat.data;
    if (linkOpen && d && d.conversation && !d.conversation.customerNumber) w.appendChild(linkBox(d.conversation));
    // ⭐ אותה כותרת דקה של תצוגת השורה: שם, מספר וטלפון בשורה אחת.
    // רצועת "פתוח אצל הלקוח" ירדה גם מכאן; היא חיה בכרטיס הלקוח.
    const who = el("div", "rwa-who");
    const hline = el("div", "rwa-cardhead");
    hline.appendChild(el("div", "rwa-whoname", chat.title || "לקוח"));
    const meta = el("div", "rwa-whometa rwa-whometa-inline");
    if (d && d.conversation && d.conversation.customerNumber) {
      meta.appendChild(ltr(d.conversation.customerNumber));
      meta.appendChild(el("span", "rwa-sep", "·"));
    }
    meta.appendChild(ltr(chat.phone));
    // ⭐ מי מדבר איתנו כשזה לא הלקוח עצמו ("הבת, מיכל").
    if (d && d.conversation && d.conversation.contactLabel) {
      meta.appendChild(el("span", "rwa-sep", "·"));
      meta.appendChild(el("span", "rwa-contactlabel", d.conversation.contactLabel));
    }
    hline.appendChild(meta);
    hline.appendChild(cardToggle(
      (d && d.conversation && d.conversation.customerNumber) || null, chat.phone));
    who.appendChild(hline);

    w.appendChild(who);

    if (chatLoading && !d) { w.appendChild(el("div", "rwa-empty", "טוען שיחה…")); return w; }
    if (!d) { w.appendChild(el("div", "rwa-empty", "לא הצלחתי לטעון.")); return w; }

    const win = windowBanner(d.window);
    if (win) w.appendChild(win);

    const msgs = d.messages || [];
    if (msgs.length) w.appendChild(thread(msgs));
    else w.appendChild(el("div", "rwa-empty", "עוד לא דיברתם איתו בוואטסאפ."));

    w.appendChild(chatComposer(d.window));
    return w;
  }

  /**
   * מענה מתוך התיבה: טקסט חופשי כשהחלון פתוח, ותבנית מאושרת תמיד.
   *
   * 🔴🔴 **וזה מה שהיה חסר עד 24/08/2026.** כשהחלון היה סגור, כל מה
   * שהופיע כאן היה משפט: "תבנית מאושרת עם מסמך נשלחת מהלקוח שעל המסך
   * בפריוריטי". כלומר מבוי סתום, בזמן ששתי תבניות מאושרות היו זמינות
   * לשליחה מיד, והדשבורד כבר ידע לשלוח אותן מהמסך המקביל.
   *
   * ⭐ **רק תבנית שדורשת מסמך חדש לכל הודעה** זקוקה לסשן של פריוריטי.
   * ההכרעה הזאת נעשית בשרת, ב-`toPanelTemplates`, ולכן הרשימה שמגיעה
   * לכאן היא ממילא רק מה שאפשר לשלוח מכאן.
   *
   * ⭐ ואותו `templateComposer` בדיוק משרת את שני המקומות. שני טפסים
   * לאותה שליחה היו נפרדים בשקט, וזה בדיוק מה שקרה כאן.
   */
  function chatComposer(win) {
    // ⭐ `rwa-tplmode` פותח את התקרה על גובה האזור, ראה `panel.css`.
    // בלי הסימון הזה השרשור נמחק כשהטופס נפתח.
    const wrap = el("div", "rwa-composer");
    const d = (chat && chat.data) || {};
    const open24 = Boolean(win && win.open);

    // ⭐ שם הלקוח כבר ידוע מהשיחה, ואין סיבה להקליד אותו מחדש.
    const forTpl = {
      templates: d.templates,
      conversation: d.conversation,
      prefill: {
        customer_name: (chat && chat.title) || "",
        name: (chat && chat.title) || "",
      },
    };

    if (!open24) {
      wrap.classList.add("rwa-tplmode");
      // 🔴 הבלוק הצהוב "עברו 24 שעות" ירד (30/08/2026): שורת המערכת
      // הדקה בראש השיחה (`windowBanner`) כבר אומרת בדיוק את זה.
      wrap.appendChild(templateComposer(forTpl, chat.phone, "", {
        fromRow: false,
        target: "chat:" + chat.phone,
      }));
      return wrap;
    }

    // חלון פתוח: טקסט חופשי, ותבנית מאחורי מתג. תבנית בחלון פתוח היא
    // מקרה אמיתי (סרטון הבטיחות), אבל היא אינה מה שעושים כאן בדרך כלל.
    if (chatTpl) {
      wrap.classList.add("rwa-tplmode");
      const back = el("button", "rwa-link", "חזרה לכתיבה חופשית");
      back.onclick = () => { chatTpl = false; render(); };
      wrap.appendChild(back);
      wrap.appendChild(templateComposer(forTpl, chat.phone, "", {
        fromRow: false,
        target: "chat:" + chat.phone,
      }));
      return wrap;
    }

    const ta = document.createElement("textarea");
    ta.className = "rwa-input";
    ta.dir = "rtl";
    ta.rows = 2;
    ta.value = draft;
    ta.placeholder = "כתוב תשובה…";
    ta.addEventListener("input", () => { draft = ta.value; btn.disabled = sending || !draft.trim(); });
    wrap.appendChild(ta);
    takeFocus("chatdraft", ta);

    const row = el("div", "rwa-row");
    const tplBtn = el("button", "rwa-link", "שלח תבנית מאושרת");
    tplBtn.onclick = () => { chatTpl = true; render(); };
    row.appendChild(tplBtn);
    row.appendChild(el("span", "rwa-spacer", ""));

    const btn = el("button", "rwa-send", sending ? "שולח…" : "שלח");
    btn.disabled = sending || !draft.trim();
    btn.onclick = async () => {
      const text = draft.trim();
      if (!text || sending || !chat) return;
      sending = true; notice = null; render();
      const r = await send("SEND", { phone: chat.phone, kind: "text", bodyText: text });
      sending = false;
      if (r && r.status === 401) { signedIn = false; render(); return; }
      const p = (r && r.data) || {};
      if (r && r.ok && p.ok) {
        draft = "";
        notice = { text: "יצא אל heyy. הסטטוס יתעדכן כאן.", tone: "ok" };
        await loadChat(chat.phone, chat.title);
        loadInbox();
      } else {
        notice = { text: p.message || "השליחה נכשלה.", tone: "bad" };
        render();
      }
    };
    row.appendChild(btn);
    wrap.appendChild(row);
    return wrap;
  }

  function head() {
    const h = el("div", "rwa-head");
    const mark = el("span", "rwa-mark");
    mark.appendChild(waIcon());
    h.appendChild(mark);
    h.appendChild(el("span", "rwa-title", "וואטסאפ"));
    h.appendChild(el("span", "rwa-spacer", ""));

    // ⭐ **המתג בין הרשימה לשיחה, במסך צר בלבד.** במסך רגיל שתיהן על
    // המסך ואין מה להחליף, ולכן ה-CSS מסתיר אותו שם. בלעדיו, במסך צר,
    // הרשימה הייתה מסך שנכנסים אליו ולא יוצאים ממנו.
    const swap = el("button", "rwa-pillbtn rwa-narrowonly rwa-hasdot");
    swap.appendChild(el("span", null, narrowList ? "השיחה" : "כל השיחות"));
    swap.appendChild(el("span", "rwa-pillico", narrowList ? "→" : "☰"));
    swap.title = narrowList ? "חזרה לשיחה" : "כל השיחות";
    if (!narrowList && waitingCount > 0) swap.appendChild(el("span", "rwa-headdot", ""));
    swap.onclick = () => { narrowList = !narrowList; if (narrowList) loadInbox(); render(); };
    h.appendChild(swap);

    const refresh = el("button", "rwa-icobtn", "⟳");
    // 🔴 מספר הגרסה ירד מהכותרת. הוא מידע של מפתח על משטח של עובד, והוא
    // תפס שורה שלמה בעין. הוא עדיין נגיש, בעכבר על כפתור הרענון.
    refresh.title = "רענן · גרסה " + VERSION;
    refresh.onclick = () => {
      loadInbox();
      if (chat) loadChat(chat.phone, chat.title);
      else if (ctx) load(false);
    };
    h.appendChild(refresh);

    const close = el("button", "rwa-icobtn", "×");
    close.title = "סגור";
    close.onclick = () => { open = false; stopPolling(); render(); };
    h.appendChild(close);
    return h;
  }

  /**
   * 🔴🔴 **"צריך להתחבר" הייתה תשובה שגויה לשאלה אחרת.**
   *
   * נתפס אצל עידן 24/08/2026: הפופאפ הראה "מחובר" עם המייל שלו, ובאותו
   * רגע החלונית שעל המסך אמרה "צריך להתחבר פעם אחת". שתיהן צדקו לגבי
   * עצמן. התוסף עודכן, והקוד שכבר הוזרק לעמוד הפתוח **נותק ממנו**.
   * מנותק אינו יכול לשאול מי מחובר, וזה נקרא כמו "אינך מחובר".
   *
   * ⭐ **הכלל: לא לענות על שאלה שלא נשאלה.** "אין תשובה מהתוסף" ו"אין
   * סשן" הן שתי מציאויות שונות לגמרי, ולכל אחת פעולה אחרת. הראשונה
   * נפתרת ברענון הדף, והשנייה בהתחברות. מי שקיבל את ההנחיה הלא נכונה
   * מנסה להתחבר שוב ושוב ומגלה שהוא כבר מחובר.
   */
  function signInHint() {
    const b = el("div", "rwa-empty");
    if (detached) {
      b.appendChild(el("div", "rwa-emptytitle", "התוסף עודכן, צריך לרענן את הדף"));
      b.appendChild(el("div", null, "הלשונית הזאת נפתחה עם גרסה קודמת של התוסף. רענן אותה (F5) והחלונית תחזור."));
      return b;
    }
    b.appendChild(el("div", "rwa-emptytitle", "צריך להתחבר פעם אחת"));
    b.appendChild(el("div", null, "לחץ על אייקון התוסף בסרגל הכלים והתחבר עם שם המשתמש והסיסמה של הדשבורד."));
    return b;
  }

  function empty(text, cls) {
    const b = el("div", "rwa-empty" + (cls ? " " + cls : ""), text);
    return b;
  }

  /**
   * מי הלקוח, **ולאן ההודעה תצא**, באותו בלוק.
   *
   * 🔴 קודם היעד ישב למטה, בקופסה צהובה נפרדת מעל טופס התבנית. זה יצר
   * שתי בעיות: הכרטיס הציג את הטלפון שעל הכרטיס כאילו הוא יעד לגיטימי
   * גם כשהוא קו נייח, והתיקון התגלה רק אחרי גלילה. השאלה "על מי אני
   * עומד" ו"לאן זה הולך" הן שאלה אחת, ולכן הן שורה אחת מתחת לשנייה.
   */
  /**
   * רצועת "מה פתוח", מתוך התשובה של השרת.
   *
   * 🔴 **ההכרעה "שובץ" מגיעה מהשרת ואינה מחושבת כאן.** היא נגזרת
   * מהעצירה ביומן, במקום אחד (`customer_card` במסד), כי הסטטוס
   * בפריוריטי והיומן לא תמיד מסכימים. כאן רק מצייר.
   */
  /* ─────────────────────────────────────────────────────────
   * ציור "מה יש אצל הלקוח"
   *
   * ⭐⭐ עידן, 25/08/2026: "כמעט לכל לקוח של ר.שעל יש מוצר של החברה.
   * הייתי רוצה שישר יקפוץ לנציגה איזה מוצר יש ללקוח."
   *
   * 🔴 **הניסוח עצמו יושב ב-`src/stock.js` ולא כאן, כדי שיהיה אפשר
   * לבדוק אותו.** מה שנאמר ללקוח בקול הוא בדיוק מה שחייב בדיקה,
   * והחלונית כולה עטופה ב-IIFE שאי אפשר להגיע לתוכו מבדיקה.
   * ───────────────────────────────────────────────────────── */

  // 🔴 **נקרא בזמן הציור ולא בזמן הטעינה.** `const S = window.RashalStock`
  // בראש הקובץ קופא על `undefined` אם סדר הטעינה במניפסט משתנה אי פעם,
  // והחלונית קורסת בציור הראשון בלי שום קשר נראה לעין לשינוי.
  const S = () => window.RashalStock;

  /**
   * הרצועה.
   *
   * 🔴 **מציירת גם כשאין כלום.** רצועה שותקת נראית בדיוק כמו פיצ'ר שלא
   * הותקן, וזו כבר הייתה תלונה אמיתית של עידן על הרצועה השכנה.
   */
  function stockStrip(stock, opts) {
    const devices = (stock && stock.devices) || [];
    const acc = (stock && stock.accessories) || [];
    const ret = (stock && stock.returned) || [];
    const box = el("div", "rwa-open rwa-stock");
    box.appendChild(el("div", "rwa-opentitle", "מה יש אצל הלקוח"));

    // 🔴 בכרטיס המלא, "התשובה ללקוח" שמעל כבר אמרה את המכשירים.
    // חזרה שלישית על אותה עובדה היא בדיוק "מידע מיותר".
    const full = !!(opts && opts.full);
    if (!full || !devices.length) {
      const line = S().stockText(stock);
      box.appendChild(el("div", devices.length ? "rwa-stocksay" : "rwa-openempty", line.text));
    }
    if (!full) return box;

    for (const it of devices.slice(0, 4)) box.appendChild(stockRow(it, true));
    if (acc.length) {
      box.appendChild(el("div", "rwa-stocksub", "תוספות ואביזרים"));
      for (const it of acc.slice(0, 5)) box.appendChild(stockRow(it, false));
    }
    if (ret.length) {
      box.appendChild(el("div", "rwa-openmore",
        "נאסף בחזרה: " + ret.slice(0, 3).map(S().stockName).join(" · ") + (ret.length > 3 ? " ועוד " + (ret.length - 3) : "")));
    }
    return box;
  }

  function stockRow(it, strong) {
    const row = el("div", "rwa-eqrow" + (strong ? " rwa-eqmain" : ""));
    const h = el("div", "rwa-tlhead");
    h.appendChild(el("span", "rwa-tlti", S().stockName(it)));
    if (Number(it.qty) > 1) h.appendChild(el("span", "rwa-sep", "×" + it.qty));
    for (const sn of (it.serials || []).slice(0, 2)) h.appendChild(ltr(String(sn)));
    row.appendChild(h);

    const sub = S().stockSub(it);
    if (sub) row.appendChild(el("div", "rwa-tlds", sub));

    // 🔴 הצבע כאן הוא סף. `rwa-warn` נצבע רק כשהאחריות נגמרת בתוך
    // 60 יום, אחרת כל הרשימה הייתה צבועה ושום דבר לא היה בולט.
    const foot = S().stockFoot(it);
    if (foot.text) {
      row.appendChild(el("div",
        "rwa-tlds rwa-eqfoot" + (foot.tone === "ending" ? " rwa-warn" : ""), foot.text));
    }
    return row;
  }

  function openStrip(open) {
    if (!open) return null;
    const rows = [];
    const add = (list, label) => {
      for (const it of (list || [])) rows.push({ it: it, label: label });
    };
    add(open.orders, "משלוח");
    add(open.calls, "קריאה");
    add(open.pickups, "איסוף");

    const box = el("div", "rwa-open");
    box.appendChild(el("div", "rwa-opentitle", "פתוח אצל הלקוח"));

    // 🔴🔴 **"אין פתוחים" נאמר, ולא נשתק.** עידן פתח לקוח בלי שום פריט
    // פתוח וכתב "אין לי כרטיס לקוח" (25/08/2026): רצועה שלא מציירת כלום
    // נראית בדיוק כמו פיצ'ר שלא הותקן. וזו גם התשובה שהוא צריך לומר
    // ללקוח, ולכן היא מידע ולא היעדר מידע.
    if (!rows.length) {
      box.appendChild(el("div", "rwa-openempty", "אין משלוח, קריאה או איסוף פתוחים."));
      return box;
    }
    for (const r of rows.slice(0, 4)) {
      const line = el("div", "rwa-openrow" + (r.it.scheduled ? " rwa-ok" : " rwa-wait"));
      const head = el("div", "rwa-openhead");
      head.appendChild(el("span", "rwa-openkind", r.label));
      if (r.it.ref) head.appendChild(ltr(String(r.it.ref)));
      line.appendChild(head);
      line.appendChild(el("div", "rwa-openwhen", r.it.scheduled
        ? "שובץ " + S().fullDate(r.it.date) + (r.it.driver ? " · " + r.it.driver : "")
        : "לא שובץ · " + waitText(minutesSince(r.it.created))));
      box.appendChild(line);
    }
    if (rows.length > 4) {
      box.appendChild(el("div", "rwa-openmore", "ועוד " + (rows.length - 4)));
    }
    return box;
  }

  /**
   * dd/mm/yy מתאריך ISO.
   *
   * 🔴🔴 **השנה נוספה ב-25/08/2026, ולא כקישוט.** עידן: "חסר לי חיווי
   * של שנה בתאריך." הוא צדק, ומה שהפך את זה מנוחות לתקלה הוא הייבוא
   * ההיסטורי של אותו יום: עד אז כל מה שהמערכת הכירה היה 2026, והשנה
   * הייתה מובנת מאליה. עכשיו יש בציר אירועים מ-2014, ו"02/01" נקרא
   * כאילו הוא מהחודש שעבר.
   */
  function shortDate(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    return String(d.getDate()).padStart(2, "0") + "/" +
           String(d.getMonth() + 1).padStart(2, "0") + "/" +
           String(d.getFullYear()).slice(2);
  }

  /** כמה דקות עברו, לשימוש `waitText` שכבר קיים כאן. */
  function minutesSince(iso) {
    if (!iso) return null;
    const t = new Date(iso).getTime();
    if (isNaN(t)) return null;
    return Math.max(0, Math.floor((Date.now() - t) / 60000));
  }

  function who(d) {
    const cust = d.customer;
    const w = el("div", "rwa-who");

    // ⭐ **כותרת דקה אחת** (המוקאפ המאושר, 30/08/2026): שם, מספר לקוח
    // וטלפון על שורה אחת, וכפתור הכרטיס לצידם. רצועות "מה יש אצל הלקוח"
    // ו"פתוח אצל הלקוח" ירדו מכאן: תצוגת השיחה היא שיחה, והתיק המלא
    // יושב בכרטיס הלקוח, שם שתי הרצועות קיימות ממילא (`cardView`).
    const line1 = el("div", "rwa-cardhead");
    line1.appendChild(el("div", "rwa-whoname", cust.customerName || "לקוח"));

    const meta = el("div", "rwa-whometa rwa-whometa-inline");
    meta.appendChild(ltr(cust.customerNumber));
    const targetPhone = (d.conversation && d.conversation.phone) || cust.phone || "";
    if (phoneOverride == null) {
      meta.appendChild(el("span", "rwa-sep", "·"));
      // 🔴 שורת "אל" הנפרדת ירדה, אבל לא היכולת שלה: הטלפון עצמו הוא
      // הכפתור שפותח "שלח למספר אחר", וקו נייח עדיין נאמר במקום.
      const pb = el("button", "rwa-phonebtn");
      pb.title = "שלח למספר אחר";
      pb.appendChild(ltr(targetPhone || "אין מספר"));
      if (targetPhone && !isMobileNumber(targetPhone)) {
        pb.classList.add("rwa-target-bad");
        pb.appendChild(el("span", "rwa-targetnote", "לא נייד"));
      }
      pb.onclick = () => { phoneOverride = targetPhone || ""; focusWanted = "phone"; render(); };
      meta.appendChild(pb);
    }
    line1.appendChild(meta);
    line1.appendChild(cardToggle(cust.customerNumber, cust.phone));
    w.appendChild(line1);

    if (!(d.messages || []).length) {
      w.appendChild(el("div", "rwa-whometa", "אין שיחה קודמת"));
    }

    // עריכת יעד ידנית: אותה שורה בדיוק כמו קודם, רק שהיא נפתחת מהטלפון
    // שבכותרת במקום לשבת פתוחה תמיד.
    if (phoneOverride != null) w.appendChild(targetRow(targetPhone));

    // ⭐ **הוודאות נאמרת בגלוי, אבל רק כשיש בה מה לעשות.**
    //
    // 🔴 עד 22/08 הופיעו כאן שתי אזהרות נפרדות: "זוהה לפי מספר בלבד"
    // ו"נמצאו 2 לקוחות אפשריים בשורה הזאת". שתיהן נכונות, ולשתיהן לא
    // הייתה שום פעולה: העובד יכול היה רק להסתכל על השם ולקוות.
    // עידן שאל ישירות "מה יש לי לעשות עם ההודעה הזאת", וזו הייתה
    // התשובה הנכונה: כלום. אזהרה בלי פעולה היא רעש.
    //
    // ⭐ **מה שנעשה במקום:**
    //   · זיהוי **ודאי** (המספר וגם השם של אותו לקוח על אותו מסך) לא
    //     מציג כלום. המועמד השני שם הוא רעש כמעט בהגדרה.
    //   · זיהוי לא ודאי עם כמה מועמדים הופך ל**בורר**: לוחצים, רואים
    //     את כולם, ובוחרים.
    //   · זיהוי לא ודאי עם מועמד יחיד נשאר משפט, כי אין ממה לבחור.
    if (picked) {
      const row = el("div", "rwa-chip rwa-chip-warn rwa-chip-row");
      row.appendChild(el("span", null, "הלקוח נבחר ידנית."));
      const undo = el("button", "rwa-link", "חזרה לזיהוי אוטומטי");
      undo.onclick = () => { picked = null; matchOpen = false; load(false); };
      row.appendChild(undo);
      w.appendChild(row);
      return w;
    }

    const many = (d.matches || []).length > 1;
    if (cust.confidence !== "verified") {
      const why = cust.confidence === "phone"
        ? "זוהה לפי הטלפון בלבד."
        : "זוהה לפי מספר בלבד, בלי שם תואם על המסך.";

      if (!many) {
        w.appendChild(el("div", "rwa-chip rwa-chip-warn", why + " ודא שזה הלקוח הנכון."));
        return w;
      }

      const pick = el("div", "rwa-picker" + (matchOpen ? " rwa-picker-open" : ""));
      const btn = el("button", "rwa-pickbtn rwa-pickbtn-warn");
      btn.appendChild(el("span", "rwa-picklabel", why));
      btn.appendChild(el("span", "rwa-pickval", d.matches.length + " מועמדים"));
      btn.appendChild(el("span", "rwa-pickchev", "⌄"));
      btn.onclick = () => { matchOpen = !matchOpen; render(); };
      pick.appendChild(btn);

      if (matchOpen) {
        const opts = el("div", "rwa-picklist");
        for (const m of d.matches) {
          const on = m.customerNumber === cust.customerNumber;
          const o = el("button", "rwa-pickopt" + (on ? " rwa-pickopt-on" : ""));
          o.appendChild(el("span", "rwa-pickcheck", on ? "✓" : ""));
          const t = el("span", "rwa-pickstack");
          t.appendChild(el("span", null, m.customerName || "לקוח"));
          t.appendChild(ltr(m.customerNumber));
          o.appendChild(t);
          o.onclick = () => {
            picked = m.customerNumber;
            matchOpen = false;
            load(false);
          };
          opts.appendChild(o);
        }
        pick.appendChild(opts);
      }
      w.appendChild(pick);
    }
    return w;
  }

  function windowBanner(win) {
    // 🔴 זה לא קישוט. זה מה שקובע אם מותר לכתוב טקסט חופשי.
    if (win && win.open) {
      const hours = Math.floor(win.minutesLeft / 60);
      const mins = win.minutesLeft % 60;
      const left = hours > 0 ? hours + " שעות ו-" + mins + " דקות" : mins + " דקות";
      const b = el("div", "rwa-win rwa-win-open");
      b.appendChild(el("span", "rwa-windot", ""));
      b.appendChild(el("span", null, "חלון פתוח, אפשר לכתוב חופשי עוד " + left));
      return b;
    }
    // ⭐ **חלון סגור: שורת מערכת דקה אחת** (עידן, 30/08/2026, מהמוקאפ
    // המאושר). ההיסטוריה כאן ארוכה: פס אדום ⟵ שורה אפורה ⟵ כלום (22/08),
    // ואז הבלוק הצהוב "עברו 24 שעות" בקומפוזר ירד גם הוא, וההסבר היחיד
    // למה שולחים דווקא תבנית צריך לחיות איפשהו, פעם אחת, בשקט.
    // 🔴 האכיפה עצמה לא נגעה: `api/wa-send` בודק את החלון מחדש בשנייה
    // שבה ההודעה יוצאת. זה כיתוב, לא הגנה.
    const b = el("div", "rwa-win rwa-win-shut");
    b.appendChild(el("span", "rwa-windot", ""));
    b.appendChild(el("span", null, "חלון סגור · אפשר לשלוח תבנית מאושרת"));
    return b;
  }

  function thread(messages) {
    const t = el("div", "rwa-thread");

    if (!messages.length) {
      t.appendChild(el("div", "rwa-empty", "עוד לא דיברתם איתו בוואטסאפ."));
      return t;
    }

    // ⭐⭐ **אדם מקבל בועה, אוטומט מקבל שורה** (עידן, 06/09/2026: "בקשה
    // למילוי סקר, אין סיבה שהיא תרדוף אותנו לעד"). הסיווג מגיע מהשרת
    // (`kind`, `autoKind`, `autoState`). בקשה שנענתה מוחלפת בתוצאה שלה;
    // רצף של בקשות שלא נענו מתקפל לשורה אחת שנפתחת בלחיצה. שום דבר לא
    // נמחק: השורה היא ההוכחה כשלקוח אומר "לא קיבלתי כלום".
    let lastDay = "";
    let run = []; // הודעות אוטומטיות רצופות שעוד לא צוירו
    const flush = () => {
      if (!run.length) return;
      if (run.length === 1 || run.some((m) => openedAuto[m.id])) {
        for (const m of run) t.appendChild(openedAuto[m.id] ? bubbleMsg(m) : sysLine(m));
      } else {
        t.appendChild(groupLine(run));
      }
      run = [];
    };
    for (const m of messages) {
      const day = m.sent_at ? new Date(m.sent_at).toDateString() : "";
      if (day && day !== lastDay) {
        flush();
        lastDay = day;
        t.appendChild(el("div", "rwa-daysep", dayLabel(m.sent_at)));
      }
      const isAuto = m.kind === "auto";
      if (isAuto && m.autoState !== "answered" && !openedAuto[m.id]) { run.push(m); continue; }
      flush();
      if (isAuto && m.autoState === "answered" && !openedAuto[m.id]) t.appendChild(sysLine(m));
      else t.appendChild(bubbleMsg(m));
    }
    flush();

    // 🔴 **גלילה לסוף רק אם המשתמש כבר היה בסוף.** עם רענון כל 20 שניות,
    // גלילה עיוורת הייתה חוטפת אותו חזרה למטה בדיוק כשהוא קורא הודעה
    // ישנה. `render` בונה את ה-DOM מחדש, ולכן המצב נשמר במשתנה ולא באלמנט.
    t.addEventListener("scroll", () => {
      chatStick = t.scrollHeight - t.scrollTop - t.clientHeight < 40;
    });
    if (chatStick) {
      setTimeout(() => { try { t.scrollTop = t.scrollHeight; } catch (_) {} }, 0);
    }
    return t;
  }

  const AUTO_LABEL = {
    survey: "בקשת סקר", photo_request: "בקשת תמונה", photo_reminder: "תזכורת לתמונה",
    on_way: "בדרך אליך", coordination: "תיאום הגעה", other: "הודעה אוטומטית",
  };
  function autoLabel(m) { return AUTO_LABEL[m.autoKind] || AUTO_LABEL.other; }

  /** שורת מערכת אחת: אפורה כשממתינה או פגה, ירוקה כשנענתה (התוצאה במקום הבקשה). */
  function sysLine(m) {
    const answered = m.autoState === "answered";
    const s = el("button", "rwa-sys" + (answered ? " rwa-sys-ok" : ""));
    const txt = answered && m.autoResult
      ? m.autoResult
      : autoLabel(m) + " · " + timeText(m.sent_at) + (m.autoState === "pending" ? " · ממתין" : "");
    s.appendChild(el("span", null, txt));
    s.title = "לחיצה מציגה את ההודעה המלאה";
    s.onclick = () => { openedAuto[m.id] = true; render(); };
    return s;
  }

  /** רצף של בקשות אוטומטיות שלא נענו: שורה אחת שנפתחת בלחיצה. */
  function groupLine(run) {
    const kinds = [];
    for (const m of run) { const l = autoLabel(m); if (kinds.indexOf(l) < 0) kinds.push(l); }
    const s = el("button", "rwa-sys rwa-sys-grp");
    s.appendChild(el("span", null, run.length + " הודעות אוטומטיות · " + kinds.join(", ")));
    s.appendChild(el("span", "rwa-sysx", "▾"));
    s.title = "לחיצה פותחת את ההודעות";
    s.onclick = () => { for (const m of run) openedAuto[m.id] = true; render(); };
    return s;
  }

  function dayLabel(iso) {
    const d = new Date(iso);
    const today = new Date();
    const yest = new Date(today.getTime() - 86400000);
    if (d.toDateString() === today.toDateString()) return "היום";
    if (d.toDateString() === yest.toDateString()) return "אתמול";
    return d.toLocaleDateString("he-IL", { day: "2-digit", month: "2-digit", year: "numeric" });
  }

  const STATUS_TEXT = {
    pending: "ממתין",
    sent: "נשלח",
    delivered: "נמסר",
    read: "נקרא",
    failed: "נכשל",
  };

  /**
   * מי שלח, בשם שאפשר לקרוא.
   *
   * 🔴 הערך במסד הוא `user:<email>`, ואצל לקוח ששמות המשתמש שלו
   * בעברית המייל הוא סינתטי ונראה כמו `u87770adf…` ואחריו הדומיין
   * הפנימי. הדבקה גולמית שלו על הבועה הייתה גרועה מכלום. שם משתמש
   * רגיל מוצג כמו שהוא.
   *
   * ⭐ ומה שאינו אדם (מנוע הסקרים, תזכורת יומית) נאמר במפורש ולא
   * מתחזה לעובד.
   */
  function authorLabel(raw) {
    const v = String(raw == null ? "" : raw).trim();
    if (!v) return "";
    if (!v.startsWith("user:")) return v === "cron" ? "אוטומטי" : v;
    const handle = v.slice(5).split("@")[0];
    // מייל סינתטי של שם משתמש בעברית: אין ממנו שום מידע קריא.
    return /^u[0-9a-f]{40}$/.test(handle) ? "עובד" : handle;
  }

  /**
   * פתיחת קובץ מהשרשור.
   *
   * 🔴 הקובץ אינו נפתח מהכתובת של heyy אלא מהעותק שלנו, כי הכתובת שלהם
   * פגה אחרי 24 שעות. הודעה מלפני שבוע הייתה מובילה לקישור מת.
   * ⭐ ואם ההעתקה עוד לא הספיקה, השרת אומר את זה במפורש ולא מחזיר 404
   * סתמי. ההבדל בין "אין קובץ" ל"עוד לא הועתק" הוא כל ההבדל.
   */
  /**
   * מושך חתימה לכל תמונה שבשרשור, פעם אחת, ומצייר מחדש כשהיא מגיעה.
   *
   * 🔴 נקרא **אחרי** שהתשובה מהשרת נכנסה למצב, אף פעם לא מתוך `bubbleMsg`.
   */
  async function prefetchThumbs(messages) {
    if (!Array.isArray(messages) || !messages.length) return;
    const now = Date.now();
    const jobs = [];

    for (const m of messages) {
      const atts = Array.isArray(m.attachments) ? m.attachments : [];
      for (const a of atts) {
        if (!a || a.kind !== "image" || !a.ready) continue;
        const key = m.id + ":" + a.index;
        const hit = thumbs.get(key);
        if (hit && now - hit.at < THUMB_TTL_MS) continue;
        if (thumbsWanted.has(key)) continue;
        thumbsWanted.add(key);
        jobs.push(
          send("MEDIA", { messageId: m.id, index: a.index }).then((r) => {
            thumbsWanted.delete(key);
            const p = (r && r.data) || {};
            if (r && r.ok && p.ok && p.url) thumbs.set(key, { url: p.url, at: Date.now() });
          }).catch(() => { thumbsWanted.delete(key); }),
        );
      }
    }

    if (!jobs.length) return;
    await Promise.all(jobs);
    // ⭐ ציור רך: מה שעל המסך נשאר, רק התמונות נכנסות למקומן.
    render(true);
  }

  async function openAttachment(messageId, index, btn) {
    if (!messageId || btn.disabled) return;
    const was = btn.textContent;
    btn.disabled = true;
    btn.textContent = "פותח…";
    const r = await send("MEDIA", { messageId, index });
    btn.disabled = false;
    btn.textContent = was;

    if (r && r.status === 401) { signedIn = false; render(); return; }
    const p = (r && r.data) || {};
    if (r && r.ok && p.ok && p.url) {
      window.open(p.url, "_blank", "noopener");
      return;
    }
    notice = { text: p.message || "לא הצלחתי לפתוח את הקובץ.", tone: "bad" };
    render();
  }

  /**
   * תמונה מוצגת קטנה בתוך הבועה, וכל השאר נשאר שורת אטב.
   *
   * 🔴 **"קובץ מצורף" על תמונה מסתיר את מה שהלקוח שלח.** לקוח ששולח
   * צילום של תקלה מצפה שיראו אותו, ולא שילחצו כדי לפתוח לשונית.
   * ⭐ עד שהחתימה מגיעה יש מלבן ממתין ולא ריק, וכשהיא נכשלת יורדים חזרה
   * לשורת האטב. ריבוע שבור הוא בדיוק סוג הכשל שמלמד לא לסמוך על המסך.
   */
  function attachmentNode(m, att) {
    const a = att || {};
    const name = a.name || "קובץ מצורף";
    const idx = Number(a.index || 0);

    if (a.kind === "image" && a.ready) {
      const hit = thumbs.get(m.id + ":" + idx);
      if (!hit) return el("div", "rwa-thumbwait");
      const wrap = el("button", "rwa-thumb");
      wrap.title = "פתח בגודל מלא";
      const img = document.createElement("img");
      img.src = hit.url;
      img.alt = name;
      img.loading = "lazy";
      // חתימה שפגה או תמונה שנשברה: לא משאירים ריבוע שבור על המסך.
      img.onerror = () => {
        thumbs.delete(m.id + ":" + idx);
        render(true);
      };
      wrap.appendChild(img);
      wrap.onclick = () => window.open(hit.url, "_blank", "noopener");
      return wrap;
    }

    const btn = el("button", "rwa-att rwa-attbtn", "📎 " + name);
    btn.title = a.ready === false ? "הקובץ לא הועתק אלינו" : "פתח את הקובץ";
    if (a.ready === false) btn.classList.add("rwa-attdim");
    btn.onclick = () => openAttachment(m.id, idx, btn);
    return btn;
  }

  /**
   * הקישור שהלקוח קיבל מתוך תבנית.
   *
   * 🔴🔴 **מוצג ולא לחיץ, בכוונה.** קישור הסקר נושא טוקן אישי, והשרת
   * חותם "נפתח" בפעם הראשונה שנכנסים אליו. עובד שלוחץ מכאן כדי לראות
   * מה הלקוח קיבל היה מסמן שהלקוח פתח את הסקר, והופך את המדד היחיד
   * שאומר אם הוא נגע בו לשקר. לכן העתקה, לא פתיחה.
   */
  function buttonNode(btn) {
    const wrap = el("div", "rwa-linkbox");
    wrap.appendChild(el("div", "rwa-linktitle", "🔗 " + (btn.text || "קישור")));
    if (!btn.url) return wrap;

    const row = el("div", "rwa-linkrow");
    const u = el("bdi", "rwa-linkurl", btn.url);
    u.dir = "ltr";
    u.title = btn.url;
    row.appendChild(u);

    const copy = el("button", "rwa-linkcopy", "העתק");
    copy.title = "פתיחה מכאן הייתה מסמנת שהלקוח פתח את הסקר";
    copy.onclick = () => {
      try {
        navigator.clipboard.writeText(btn.url);
        copy.textContent = "הועתק";
        setTimeout(() => { copy.textContent = "העתק"; }, 1500);
      } catch (_) { /* אין הרשאה ללוח: הכתובת עדיין מוצגת */ }
    };
    row.appendChild(copy);
    wrap.appendChild(row);
    return wrap;
  }

  function bubbleMsg(m) {
    const out = m.direction === "out";
    const b = el("div", "rwa-msg " + (out ? "rwa-out" : "rwa-in"));

    if (m.template_id) b.appendChild(el("div", "rwa-tmpl", "תבנית מאושרת"));

    // ⭐ הודעה שכולה תמונה אינה מקבלת שורת טקסט ריקה מעליה.
    if (m.body) b.appendChild(el("div", "rwa-body", m.body));

    const atts = Array.isArray(m.attachments) ? m.attachments : [];
    for (const att of atts) {
      b.appendChild(attachmentNode(m, att));
    }
    const btns = Array.isArray(m.buttons) ? m.buttons : [];
    for (const btn of btns) {
      b.appendChild(buttonNode(btn));
    }
    if (!atts.length && m.entity_key) {
      // הודעת טקסט שנשלחה מתוך מסמך, בלי קובץ. ההקשר עדיין שווה להצגה.
      b.appendChild(el("div", "rwa-att", "על " + m.entity_key));
    }

    const foot = el("div", "rwa-msgfoot");
    foot.appendChild(el("span", null, timeText(m.sent_at)));
    if (out) {
      const st = STATUS_TEXT[m.status] || m.status || "";
      if (st) {
        foot.appendChild(el("span", "rwa-sep", "·"));
        foot.appendChild(el("span", m.status === "failed" ? "rwa-bad" : null, st));
      }
      // ⭐ השרת מפענח את השם האמיתי מ-profiles (עמי גז, שלומי קורן),
      // כי המייל אצל רשעל מגובב. "עובד" נשאר רק כמוצא אחרון.
      const who = m.author_name || authorLabel(m.author);
      if (who) {
        foot.appendChild(el("span", "rwa-sep", "·"));
        foot.appendChild(el("span", null, who));
      }
    }
    b.appendChild(foot);
    return b;
  }

  // 🔴 נייד ישראלי הוא עשר ספרות שמתחילות ב-05. קו נייח (תשע ספרות) ומספר
  // ח.פ נראים דומה מספיק כדי להיתפס בטעות, וזה כבר קרה בתוסף של עוגן הזהר:
  // שדה ח.פ סווג כטלפון והחלונית הציעה לשלוח לשם חשבונית. וואטסאפ לקו נייח
  // פשוט לא מגיע, ועדיף לומר את זה כאן מאשר לשלוח לחלל.
  const isMobileNumber = (v) => /^05\d{8}$/.test(String(v == null ? "" : v).replace(/\D/g, ""));

  function composer(d) {
    const wrap = el("div", "rwa-composer");
    const cardPhone = (d.conversation && d.conversation.phone) || (d.customer && d.customer.phone) || "";
    const phone = phoneOverride != null ? phoneOverride : cardPhone;
    const isMobile = isMobileNumber(phone);
    const canText = Boolean(d.window && d.window.open) && isMobile;

    if (notice) {
      wrap.appendChild(el("div", "rwa-notice " + (notice.tone === "bad" ? "rwa-bad" : "rwa-ok"), notice.text));
    }

    if (!phone) {
      // 🔴 ההודעה חייבת להתאים למצב. "אין טלפון על הכרטיס" כשהמשתמש רק
      // ניקה את השדה הידני היא שקר קטן שמבלבל.
      wrap.appendChild(el("div", "rwa-empty rwa-bad",
        phoneOverride != null
          ? "הקלד מספר נייד."
          : "אין טלפון על כרטיס הלקוח בפריוריטי, ולכן אין לאן לשלוח."));
      return wrap;
    }

    // 🔴 **קו נייח כבר לא מבוי סתום.** קודם הכרטיס עצר כאן עם בלוק אדום
    // ולא הציג שום פעולה, כלומר העובד ראה אזהרה בלי מוצא, ואת האזהרה
    // עצמה כבר קרא שורה אחת קודם בשורת היעד. עכשיו הטופס נבנה כרגיל,
    // הכפתור סגור, והסיבה יושבת לצידו: זה מוביל אותו להחליף מספר.
    const blocked = isMobile ? "" : "המספר אינו נייד. שלח למספר אחר.";

    // ⭐ חלון סגור אינו סוף הדרך. שם עוברים לתבנית מאושרת, וזו הדרך
    // היחידה לפתוח מחדש שיחה עם לקוח ששתק יותר מ-24 שעות.
    if (!canText || rowTpl) {
      if (canText) {
        // נפתח מכפתור המסמך ברצועה בזמן שאפשר לכתוב חופשי. דרך חזרה.
        const back = el("button", "rwa-link", "חזרה לכתיבה חופשית");
        back.onclick = () => { rowTpl = false; render(); };
        wrap.appendChild(back);
      }
      wrap.appendChild(templateComposer(d, phone, blocked, {
        fromRow: true,
        target: "row:" + ((d.customer && d.customer.customerNumber) || cardPhone),
      }));
      return wrap;
    }

    const ta = document.createElement("textarea");
    ta.className = "rwa-input";
    ta.dir = "rtl";
    ta.rows = 2;
    ta.value = draft;
    ta.placeholder = "כתוב הודעה…";
    ta.addEventListener("input", () => { draft = ta.value; btn.disabled = sending || !draft.trim(); });
    wrap.appendChild(ta);

    const row = el("div", "rwa-row");
    const btn = el("button", "rwa-send", sending ? "שולח…" : "שלח");
    btn.disabled = sending || !draft.trim();
    row.appendChild(btn);
    wrap.appendChild(row);

    async function fire() {
      const text = draft.trim();
      if (!text || sending) return;
      sending = true;
      notice = null;
      btn.disabled = true;
      btn.textContent = "שולח…";

      const r = await send("SEND", {
        phone,
        kind: "text",
        bodyText: text,
        customerNumber: d.customer ? d.customer.customerNumber : null,
        // ⭐ **על מה השיחה, ולא רק עם מי.** שם המסך ומספר המסמך שהשרת
        // זיהה בשורה נשלחים יחד עם ההודעה, ונרשמים עליה בשרשור.
        // 🔴 עד 22/08/2026 נשלח רק שם המסך, ומספר המסמך לא נשלח כלל,
        // ולכן גם אחרי שהשרת יתקן את הכתיבה לא היה מה לכתוב.
        entityType: ctx ? ctx.form : null,
        entityKey: (d.prefill && d.prefill.doc_number) || null,
      });

      sending = false;

      if (r && r.status === 401) { signedIn = false; render(); return; }

      const payload = (r && r.data) || {};
      if (r && r.ok && payload.ok) {
        draft = "";
        notice = { text: "יצא אל heyy. הסטטוס יתעדכן כאן כשמטא יאשרו מסירה.", tone: "ok" };
        await rememberIfAsked(phone, d);
        // 🔴 בכוונה לא כתוב "נמסר". תשובת שליחה אינה אישור מסירה, וזו בדיוק
        // המלכודת שכבר עלתה לנו: הודעות שנראו נשלחות ונתקעו על pending לנצח.
        await load(true);
      } else {
        notice = {
          text: payload.message || (r && r.error) || "השליחה נכשלה.",
          tone: "bad",
        };
        // חלון שנסגר בין הטעינה לשליחה: מרעננים כדי שהבאנר יגיד את האמת.
        if (payload.error === "window_closed") await load(true);
      }
      render();
    }

    btn.onclick = fire;
    // Ctrl+Enter שולח. Enter רגיל נשאר שורה חדשה, כי הודעות לקוח נכתבות
    // בכמה שורות ואיבוד טיוטה בלחיצה מקרית הוא נזק אמיתי.
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); fire(); }
    });

    // אותה מלכודת בדיוק, בשדה השני: בלי התניה הריענון השקט (כל 20 שניות)
    // היה חוטף את המיקוד לתיבת ההודעה מתי שבא לו.
    takeFocus("draft", ta);
    return wrap;
  }

  // ── לאן נשלח, ואפשרות להחליף ───────────────────────────
  //
  // 🔴 העיקרון: **היעד תמיד גלוי לפני השליחה.** הודעה שיוצאת למספר שהעובד
  // לא ראה היא הודעה שיצאה בשם החברה לאדם הלא נכון.
  function targetRow(cardPhone) {
    const row = el("div", "rwa-target");

    if (phoneOverride == null) {
      const ok = isMobileNumber(cardPhone);
      row.appendChild(el("span", "rwa-targetlabel", "אל"));
      row.appendChild(ltr(cardPhone || "אין מספר"));
      // 🔴 **קו נייח נאמר כאן ולא אחרי גלילה.** מספר כמו 03-5001011 נראה
      // על הכרטיס בדיוק כמו יעד תקין, ווואטסאפ לא יגיע אליו לעולם.
      if (!ok) {
        row.classList.add("rwa-target-bad");
        row.appendChild(el("span", "rwa-targetnote", cardPhone ? "לא נייד" : ""));
      }
      const b = el("button", "rwa-link", "שלח למספר אחר");
      // נפתח עם המספר שעל הכרטיס, כדי לערוך ולא להקליד מאפס.
      b.onclick = () => { phoneOverride = cardPhone || ""; focusWanted = "phone"; render(); };
      row.appendChild(b);
      return row;
    }

    row.classList.add("rwa-target-manual");
    row.appendChild(el("span", "rwa-targetlabel", "אל"));

    const inp = document.createElement("input");
    inp.className = "rwa-phoneinput";
    inp.type = "tel";
    inp.dir = "ltr";
    inp.value = phoneOverride;
    inp.placeholder = "0521234567";
    // 🔴 בלי `render()` על כל תו: זה היה מאבד את המיקוד באמצע ההקלדה.
    // 🔴 **וגם לא על `blur`.** ציור מחדש ביציאה מהשדה הוא בדיוק מה שסגר
    // את לולאת המיקוד.
    //
    // 🔴🔴 **אבל ההערה שישבה כאן קודם אמרה "שום דבר אחר בחלונית לא נגזר
    // ממנו", וזו הייתה טעות.** כל מה שמתחת נגזר מהמספר: אם הוא נייד תקין,
    // אם מוצג טופס התבנית, ואם בכלל אפשר לשלוח. אצל לקוח **בלי טלפון על
    // הכרטיס** השדה נפתח ריק, החלונית ציירה "הקלד מספר נייד", והקלדת מספר
    // תקין לא שינתה כלום. נראה בדיוק כמו מוצר תקוע (עידן, 22/08/2026).
    // ⭐ הפתרון: לצייר מחדש **רק ברגע שהתקינות מתהפכת**, ולא על כל תו.
    // ציור אחד לכל הקלדה, והמיקוד מוחזר לשדה דרך `focusWanted`.
    let wasValid = isMobileNumber(phoneOverride);
    inp.addEventListener("input", () => {
      phoneOverride = inp.value;
      const nowValid = isMobileNumber(phoneOverride);
      if (nowValid === wasValid) return;
      wasValid = nowValid;
      focusWanted = "phone";
      render();
    });
    row.appendChild(inp);

    // 🔴 שורה אחת במקום שלוש. "חזרה למספר שעל הכרטיס" כבר אומר שזה לא
    // המספר שעל הכרטיס, ואזהרה נוספת מתחתיה היא רעש.
    const back = el("button", "rwa-link", "חזרה לכרטיס");
    back.onclick = () => { phoneOverride = null; render(); };
    row.appendChild(back);

    // ⭐ "שלח וזכור" (עידן, 06/09/2026): מספר אחר שכותבים אליו מהכרטיס של
    // הלקוח הוא כמעט תמיד בן משפחה. ברירת המחדל זוכרת אותו ללקוח, ומאז
    // הודעות ותמונות ממנו מזוהות כשלו, וההודעות האוטומטיות יוצאות גם אליו.
    const mem = el("div", "rwa-remember");
    const chk = el("label", "rwa-chk");
    const cb = document.createElement("input");
    cb.type = "checkbox"; cb.checked = rememberOther;
    cb.addEventListener("change", () => { rememberOther = cb.checked; lab.disabled = !cb.checked; });
    chk.appendChild(cb);
    chk.appendChild(el("span", null, "לזכור את המספר ללקוח אחרי השליחה"));
    mem.appendChild(chk);
    const lab = document.createElement("input");
    lab.className = "rwa-input rwa-linklabel";
    lab.dir = "rtl";
    lab.placeholder = "מי זה? (לא חובה) · הבת, מיכל";
    lab.value = otherLabel;
    lab.disabled = !rememberOther;
    lab.addEventListener("input", () => { otherLabel = lab.value; });
    mem.appendChild(lab);
    row.appendChild(mem);

    takeFocus("phone", inp);
    return row;
  }

  // ── שליחת תבנית מאושרת ─────────────────────────────────
  //
  // ⭐ העיקרון היחיד כאן: **מה שרואים על המסך הוא בדיוק מה שהלקוח יקרא.**
  // התצוגה המקדימה נבנית מאותו נוסח שהשרת שולח, ומתעדכנת בכל הקלדה. אין
  // מצב שבו העובד לוחץ "שלח" ומגלה בדיעבד מה יצא בשמו.
  //
  // 🔴 והרשימה מגיעה מהשרת, לא מהתוסף. תבנית חדשה נכנסת לשימוש בלי
  // שאף עובד יצטרך לעדכן גרסה של התוסף.
  function templateComposer(d, phone, blocked, opts) {
    const o = opts || {};
    // ⭐ **מאיפה נשלח, לא רק למי.** מהשורה שבפריוריטי אפשר להפיק מסמך,
    // מהתיבה אין שורה ולכן אין מסמך, והשרת ממילא לא מציע תבנית כזאת שם.
    const fromRow = o.fromRow !== false;
    const box = el("div", "rwa-tplbox");
    const list = (d.templates || []).filter((t) => t.available);

    // 🔴 יעד חדש מאפס את הטופס. ראה `tplFor`.
    const target = o.target || phone || "";
    if (tplFor !== target) { tplFor = target; tplValues = {}; tplOpen = false; }

    if (!list.length) {
      box.appendChild(el("div", "rwa-empty",
        fromRow ? "אין תבנית זמינה לשליחה כרגע."
          : "אין תבנית מאושרת שאפשר לשלוח מכאן. תעודה או חשבונית נשלחות מהלקוח שעל המסך בפריוריטי, כי המסמך מופק משם."));
      return box;
    }

    if (!tplKey || !list.some((t) => t.key === tplKey)) tplKey = list[0].key;
    const spec = list.find((t) => t.key === tplKey);

    // מילוי מראש ממה שהשרת זיהה על המסך, פעם אחת לכל לקוח.
    const pre = d.prefill || {};
    for (const name of spec.variables) {
      if (tplValues[name] === undefined) tplValues[name] = pre[name] || "";
    }

    // 🔴 השדות והתצוגה המקדימה יושבים באזור שגולל בתוך עצמו, וכפתור
    // השליחה מחוצה לו. במסך נמוך הכרטיס נחסם על גובה החלון, וכשהכל היה
    // בזרימה אחת `overflow:hidden` חתך את הכפתור. **פעולה שנחתכת נראית
    // בדיוק כמו פעולה מקולקלת.**
    const scroll = el("div", "rwa-tplscroll");

    // 🔴 **הצ'יפ שהסביר שהתבנית מסווגת שיווק ירד** (עידן, 22/08/2026).
    // הוא נכון עובדתית (תבנית שיווק עולה יותר וכפופה להסכמת הנמען), אבל
    // הוא הופיע על **כל** שליחה, גם כשאין מה לעשות בו: העובד לא בוחר את
    // הסיווג ולא יכול לשנות אותו. אזהרה שחוזרת ואי אפשר לפעול לפיה היא
    // רעש, והיא מלמדת את העין להתעלם גם מהאזהרות שכן חשובות.
    // ⭐ הסיווג עדיין מגיע מהשרת ונשמר בנתונים, ומי שרוצה לנהל עלויות
    // רואה אותו במסך ניהול התבניות בדשבורד, שם זו החלטה אמיתית.

    // ── תבנית שנושאת מסמך ────────────────────────────────
    //
    // ⭐ המסמך מופק מפריוריטי עצמה, בסשן הפתוח בדפדפן, ולכן אין כאן
    // רינדור משלנו ואין פעימות API.
    // 🔴 ושלוש השאלות נפרדות, כי לכל אחת יש מה לעשות בה: המסך עוד לא
    // נלמד (להדפיס ידנית פעם אחת), עוד לא נלכדה קריאה (לעבור שורה),
    // או שהכל מוכן. "אי אפשר" אחד היה משאיר את העובד בלי מוצא.
    const DOC = C.doc;
    // 🔴 גם אם תבנית עם מסמך תגיע לכאן בטעות, מהתיבה אין מאיפה להפיק אותו.
    const needsDoc = fromRow && Boolean(spec.needsDocument);
    const docLearned = needsDoc ? DOC.learned() : null;

    // 🔴 **הצ'יפ "המסך לא נלמד" ירד, כי אותו משפט כבר יושב ליד הכפתור.**
    // הוא נוצר לפני שהכפתור למד להסביר את עצמו, ואחרי שכל שאר הרעש ירד
    // הכפילות הפכה בולטת: אותה הוראה, פעמיים, במרחק שלוש שורות.
    // ⭐ המקום הנכון הוא ליד הפעולה החסומה, ולא בראש הטופס.

    // ── בורר התבנית ──────────────────────────────────────
    // ⭐ עידן ביקש שיהיה בולט יותר: זו הבחירה הראשונה שהעובד עושה, והיא
    // קובעת מה בכלל יוצא. בגרסה קודמת השתקתי אותה יותר מדי.
    if (list.length > 1) {
      const picker = el("div", "rwa-picker" + (tplOpen ? " rwa-picker-open" : ""));

      const btn = el("button", "rwa-pickbtn");
      btn.appendChild(el("span", "rwa-picklabel", "תבנית"));
      btn.appendChild(el("span", "rwa-pickval", spec.label));
      btn.appendChild(el("span", "rwa-pickchev", "⌄"));
      btn.onclick = () => { tplOpen = !tplOpen; render(); };
      picker.appendChild(btn);

      if (tplOpen) {
        const opts = el("div", "rwa-picklist");
        for (const t of list) {
          const on = t.key === tplKey;
          const o = el("button", "rwa-pickopt" + (on ? " rwa-pickopt-on" : ""));
          o.appendChild(el("span", "rwa-pickcheck", on ? "✓" : ""));
          o.appendChild(el("span", null, t.label));
          o.onclick = () => {
            // בחירת תבנית אחרת מאפסת את הערכים, כי המשתנים שלה שונים.
            if (!on) { tplKey = t.key; tplValues = {}; }
            tplOpen = false;
            render();
          };
          opts.appendChild(o);
        }
        picker.appendChild(opts);
      }
      scroll.appendChild(picker);
    }

    // 🔴 התחביר של heyy הוא {{var.name}} ולא {{name}}. זה התגלה רק כשהנוסח
    // הגיע מהסנכרון במקום מהקלדה ידנית: ביטוי שתופס \w+ בלבד לא מתאים
    // לנקודה, ואז התצוגה המקדימה מציגה את שם המשתנה במקום את הערך.
    // שתי הצורות נתמכות, כי גם נוסח ישן עדיין קיים.
    const VAR_RE = /\{\{\s*(?:var\.)?(\w+)\s*\}\}/g;

    // ⭐⭐ **מילוי במקום** (חלופה א, אושרה 05/09/2026, ערב המסירה).
    // הנוסח מוצג בדיוק כמו שיישלח, והפרטים החסרים הם משבצות בתוך המשפט
    // שמקלידים לתוכן. אין תיבת טקסט, אין "ערוך את הפרטים", אין שני מצבים.
    //
    // 🔴 **הנוסח הקבוע קפוא אצל מטא, ולכן הוא פשוט אינו עריך.** עד היום
    // הטקסט כולו ישב בתיבת טקסט, ועריכה שנגעה במילים הקבועות נחסמה עם
    // הסבר. חסימה טובה פחות מדלת שלא קיימת: כל מה שאפשר להקליד עכשיו
    // הוא בהגדרה חוקי.
    //
    // 🔴 **ובלי גלילה בתוך עצמו.** תיבת הטקסט הייתה בגובה ארבע שורות
    // מול נוסח של חמש, והחלק החשוב נגלל מהעין (הצילום של עידן, 05/09).
    // המשבצות יושבות בפסקה שגובהה הוא גובה ההודעה.
    const msg = el("div", "rwa-tplmsg");
    msg.dir = "rtl";
    const chips = new Map();
    const echoes = [];

    const addText = (txt) => {
      if (!txt) return;
      txt.split("\n").forEach((part, i) => {
        if (i) msg.appendChild(document.createElement("br"));
        if (part) msg.appendChild(document.createTextNode(part));
      });
    };
    const chipClass = (name) =>
      "rwa-chip" + ((tplValues[name] || "").trim() ? " rwa-chip-full" : "");

    VAR_RE.lastIndex = 0;
    let last = 0;
    let m;
    while ((m = VAR_RE.exec(spec.preview))) {
      addText(spec.preview.slice(last, m.index));
      const name = m[1];
      if (chips.has(name)) {
        // משתנה שחוזר פעמיים: ההופעה הראשונה עריכה, השנייה משקפת אותה.
        const echo = el("span", "rwa-chip rwa-chip-echo", tplValues[name] || "");
        echo.placeholder = VAR_LABELS[name] || name;
        echoes.push([name, echo]);
        msg.appendChild(echo);
      } else {
        const chip = el("span", chipClass(name), tplValues[name] || "");
        chip.contentEditable = "true";
        chip.spellcheck = false;
        // התווית של המשבצת הריקה מצוירת ב-CSS מתוך המאפיין, וגם נשמרת
        // כמאפיין רגיל כדי שאפשר יהיה למצוא אותה בבדיקות.
        chip.placeholder = VAR_LABELS[name] || name;
        if (chip.setAttribute) chip.setAttribute("data-ph", VAR_LABELS[name] || name);
        chip.addEventListener("input", () => {
          tplValues[name] = String(chip.textContent || "").replace(/\s+/g, " ").trim();
          chip.className = chipClass(name);
          for (const [n2, e2] of echoes) if (n2 === name) e2.textContent = tplValues[name];
          if (attline) attline.textContent = "📎 " + (tplValues.doc_number || "מסמך") + ".pdf";
          syncSend();
        });
        // Enter אינו שורה חדשה בתוך פרט; הוא עובר למשבצת הבאה, ואם אין, שולח.
        chip.addEventListener("keydown", (e) => {
          if (e.key !== "Enter") return;
          e.preventDefault();
          const all = [...chips.values()];
          const next = all[all.indexOf(chip) + 1];
          if (next && next.focus) next.focus();
          else if (canSend()) btn.onclick();
        });
        // הדבקה נכנסת כטקסט פשוט, בלי עיצוב שנוסע מהלוח.
        chip.addEventListener("paste", (e) => {
          if (!e.clipboardData || !document.execCommand) return;
          e.preventDefault();
          document.execCommand("insertText", false, e.clipboardData.getData("text/plain").replace(/\s+/g, " "));
        });
        chips.set(name, chip);
        msg.appendChild(chip);
      }
      last = m.index + m[0].length;
    }
    addText(spec.preview.slice(last));
    scroll.appendChild(msg);

    // הקובץ שנוסע עם ההודעה, בשורה אחת אפורה ולא בצ'יפ צבעוני.
    let attline = null;
    if (needsDoc && docLearned) {
      attline = el("div", "rwa-attline", "📎 " + (tplValues.doc_number || "מסמך") + ".pdf");
      scroll.appendChild(attline);
    }

    box.appendChild(scroll);

    function allFilled() {
      return spec.variables.every((n) => (tplValues[n] || "").trim());
    }

    // 🔴 מסך שלא נלמד חוסם את השליחה כאן ולא בשרת, כי הצ'יפ שמעל כבר
    // אומר בדיוק מה לעשות כדי לפתוח אותה.
    function canSend() {
      return !blocked && allFilled() && !(needsDoc && !docLearned);
    }

    /**
     * 🔴 **כפתור אפור חייב לומר למה, ליד עצמו.**
     * הסיבה כן הוצגה, בצ'יפ שיושב מעל שדות התבנית, אבל השדות והצ'יפ
     * יושבים באזור שגולל בתוך עצמו והכפתור מחוצה לו. במסך נמוך הצ'יפ
     * נגלל מהעין, והמשתמש נשאר מול כפתור שנראה מקולקל. זה עצר את עידן
     * פעמיים, ב-22/08/2026, ובשתי הפעמים ההסבר היה קיים ולא נראה.
     * **פעולה שלא מסבירה את עצמה נקראת כמו מוצר שבור.**
     */
    function blockReason() {
      if (blocked) return blocked;
      if (needsDoc && !docLearned) {
        return "המסך הזה עוד לא נלמד. הדפס בו ידנית פעם אחת, הצגה ו-PDF, ומכאן זה אוטומטי.";
      }
      const missing = spec.variables.filter((n) => !(tplValues[n] || "").trim());
      if (missing.length) {
        return "נשאר למלא: " + missing.map((n) => VAR_LABELS[n] || n).join(" · ");
      }
      return "";
    }

    // 🔴 ההסבר יושב **בשורה מלאה מעל הכפתור** ולא לצידו. הוראה כמו
    // "הדפס בו ידנית פעם אחת, הצגה ו-PDF" נדחסה לחצי שורה ונשברה לשלוש
    // שורות צרות ליד הכפתור, וזה נראה כמו תקלה ולא כמו הנחיה.
    const hint = el("div", "rwa-hint", "");
    box.appendChild(hint);

    // ההסבר בצד, הפעולה בקצה. אין יותר "ערוך את הפרטים": העריכה היא
    // המשבצות שבנוסח, ואין מצב שני.
    const row = el("div", "rwa-row rwa-row-split");
    row.appendChild(el("span", "rwa-rowspacer", ""));
    const label = needsDoc ? "הפק ושלח מסמך" : "שלח";
    const btn = el("button", "rwa-send", sending ? "שולח…" : label);
    row.appendChild(btn);
    box.appendChild(row);

    // מצב הכפתור וההסבר לצידו נקבעים במקום אחד, כדי שלא יתפצלו.
    function syncSend() {
      const why = sending ? "" : blockReason();
      btn.disabled = sending || !canSend();
      // 🔴 **וכשאין סיבה, אין שורה.** הטקסט שישב כאן קודם, "תבנית מאושרת
      // נמסרת גם כשהחלון סגור", הוא בדיוק מה ששורת המצב כבר אומרת שני
      // אזורים למעלה. אותה עובדה שלוש פעמים על מסך אחד היא רעש, לא ביטחון.
      hint.textContent = why;
      hint.className = why ? "rwa-hint rwa-hint-block" : "rwa-hint rwa-hint-empty";
    }
    syncSend();

    btn.onclick = async () => {
      if (sending || !canSend()) return;
      sending = true;
      notice = null;
      btn.disabled = true;

      // ⭐ ההפקה קודמת לשליחה, וכישלון בה עוצר לפני שיוצאת הודעה.
      // 🔴 תבנית שאומרת "מצורפת" ומגיעה בלי הקובץ היא הבטחה שבורה,
      // ולכן אין כאן נפילה אחורה לשליחה בלי מסמך.
      let documentUrl = null;
      let documentBase64 = null;
      if (needsDoc) {
        if (!DOC.here()) {
          if (!DOC.ready()) {
            sending = false;
            notice = { text: DOC.missing() + ". עבור שורה אחת בפריוריטי וזה יסתדר.", tone: "bad" };
            render();
            return;
          }
          btn.textContent = "מפיק…";
          try {
            await DOC.produce();
          } catch (e) {
            sending = false;
            notice = { text: "ההפקה נכשלה: " + ((e && e.message) || e), tone: "bad" };
            render();
            return;
          }
        }

        // 🔴 **הקובץ נמשך כאן ולא בשרת**, כי הכתובת של פריוריטי דורשת
        // את הסשן הפתוח. ההסבר המלא ב-`context.js`, ב-`doc.bytes`.
        btn.textContent = "מביא את המסמך…";
        try {
          const file = await DOC.bytes();
          documentBase64 = file.base64;
          documentUrl = file.url;
        } catch (e) {
          sending = false;
          notice = { text: "המסמך לא נמשך: " + ((e && e.message) || e), tone: "bad" };
          render();
          return;
        }
      }

      btn.textContent = "שולח…";

      const r = await send("SEND", {
        phone,
        kind: "template",
        templateKey: tplKey,
        values: tplValues,
        documentBase64,
        documentUrl,
        documentName: documentBase64 ? (tplValues.doc_number || "מסמך") + ".pdf" : null,
        customerNumber: (d.customer && d.customer.customerNumber)
          || (d.conversation && d.conversation.customerNumber) || null,
        // 🔴 **מהתיבה אין שיוך למסמך, ובכוונה.** השורה שבמקרה פתוחה
        // בפריוריטי אינה קשורה לשיחה שנבחרה מהרשימה, ושיוך שגוי בשרשור
        // גרוע מהיעדר שיוך.
        entityType: fromRow && ctx ? ctx.form : null,
        // 🔴 כאן נלקח **הערך שבשדה** ולא זה שהשרת זיהה, כי העובד יכול
        // לתקן אותו לפני השליחה. מה שנרשם בשרשור חייב להיות מה שיצא.
        entityKey: tplValues.doc_number || (d.prefill && d.prefill.doc_number) || null,
      });

      sending = false;
      if (r && r.status === 401) { signedIn = false; render(); return; }

      const payload = (r && r.data) || {};
      if (r && r.ok && payload.ok) {
        // 🔴 שוב, לא "נמסר". תשובת שליחה אינה אישור מסירה.
        notice = { text: "התבנית יצאה אל heyy. הסטטוס יתעדכן כאן.", tone: "ok" };
        if (fromRow) await rememberIfAsked(phone, d);
        tplValues = {};
        // 🔴 הרענון חייב להיות של מה שמוצג. `load` טוען את השורה שבפריוריטי,
        // ומהתיבה זו שיחה אחרת לגמרי, ואז ההודעה שיצאה לא הייתה מופיעה.
        if (fromRow) await load(true);
        else if (chat) { await loadChat(chat.phone, chat.title); loadInbox(); }
      } else {
        notice = { text: payload.message || (r && r.error) || "השליחה נכשלה.", tone: "bad" };
      }
      render();
    };

    return box;
  }

  const VAR_LABELS = {
    customer_name: "שם הלקוח",
    subject: "הנושא",
    details: "מה רוצים לומר",
    doc_type: "סוג המסמך",
    doc_number: "מספר המסמך",
  };

  const VAR_HINTS = {
    subject: "הזמנה SO26001234",
    details: "המשלוח יוצא מחר בבוקר",
    doc_type: "תעודת משלוח",
    doc_number: "SH26007394",
  };

  // ⭐ **ברגע שנלמד כאן משהו, הוא נשלח הלאה.** `printer.js` מודיע רק
  // אחרי שאותה הרצה באמת החזירה קובץ, ולכן מה שנשלח כבר הוכיח את עצמו.
  // 🔴 והשליחה נעשית בבקשת ההקשר הבאה, לא בבקשה משלה: ראה `load`.
  /**
   * 🔴🔴 **מה שנלמד נשלח תמיד, גם כשאין לקוח על המסך.**
   *
   * נתפס אצל עידן 24/08/2026: שש הדפסות נלמדו ונשמרו, והזמנת הרכש לא.
   * הסיבה: הלמידה נסעה על גבה של בקשת זיהוי הלקוח, ו-`load` יוצא מיד
   * כשאין מועמדים. בהזמנת רכש אין לקוח אלא ספק, ולכן מה שנלמד נשאר תקוע
   * בדפדפן ולא יצא לעולם.
   *
   * ⭐ **וזו הייתה טעות תכנון, לא באג:** לפרוצדורת ההדפסה אין שום קשר
   * ללקוח. הצמדתי אותה לזיהוי כי זו הייתה הבקשה שכבר יצאה, ובכך תליתי
   * ידע אחד בהצלחה של ידע אחר.
   */
  async function flushLearn() {
    if (!pendingLearn) return;
    const out = pendingLearn;
    // אין מועמדים, ולכן זו בקשה שכל תוכנה הוא מה שנלמד. השרת רושם אותה
    // לפני בדיקת המועמדים, ומחזיר 200 כשזה כל מה שהיה בה.
    const r = await send("CONTEXT", { form: out.form, candidates: [], learnedProc: out });
    if (r && r.ok) pendingLearn = null;
  }

  try {
    C.doc.onLearn((form, spec) => {
      pendingLearn = {
        form: form,
        ename: spec.ename,
        table: spec.table,
        avoidmessages: spec.avoidmessages,
        printArgs: spec.printArgs,
      };
      // הלמידה קורית תוך כדי הדפסה ידנית, ואז אין סיבה לחכות למעבר שורה.
      if (ctx && ctx.candidates && ctx.candidates.length) load(true);
      else flushLearn();
    });
  } catch (_) {}

  // ── התחלה ──────────────────────────────────────────────
  send("WHO").then((r) => { applyAuth(Boolean(r && r.signedIn)); });

  /**
   * 🔴🔴 **מצב ההתחברות נבדק שוב, ולא רק פעם אחת בטעינת הדף.**
   *
   * עידן, 25/08/2026: "גם אחרי שאני מתחבר לתוסף הוא ממשיך לבקש להתחבר.
   * לדעתי אם ארענן את הפריוריטי זה יעבוד, אבל לא בטוח." הוא צדק, וזה
   * היה מבנה ולא תקלה: `WHO` נשאל פעם אחת, ומי שהתחבר בפופאפ אחרי
   * שהלשונית כבר נטענה נשאר מול "צריך להתחבר" לנצח.
   *
   * 🔴 **ובלי לרענן את הדף**, כי רענון בפריוריטי מאבד את המסך שהמשתמש
   * עומד עליו, וזה בדיוק המסך שהחלונית נועדה לעבוד מולו.
   */
  function applyAuth(next) {
    const changed = signedIn !== next;
    signedIn = next;
    // ⭐ הקשר מנותק אינו "לא מחובר". ראה `signInHint`.
    if (!signedIn) detached = !isAlive();
    render();
    // התחברות היא רגע שבו יש פתאום מה להראות.
    if (changed && signedIn) {
      pollWaiting().catch(() => {});
      load(true).catch(() => {});
    }
  }

  // המסלול המהיר: הפופאפ מודיע ברגע ההתחברות.
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === "AUTH_CHANGED") applyAuth(Boolean(msg.signedIn));
    });
  } catch (_) { /* הדגימה למטה מכסה */ }

  // 🔴 **ורשת ביטחון, כי הודעה יכולה לא להגיע**: לשונית שנפתחה לפני
  // שה-service worker התעורר, או הודעה שאבדה. כל 20 שניות, ורק כשלא
  // מחוברים, כלומר אפס עלות במצב הרגיל.
  setInterval(() => {
    if (signedIn) return;
    send("WHO").then((r) => {
      const next = Boolean(r && r.signedIn);
      if (next !== signedIn) applyAuth(next);
    }).catch(() => {});
  }, 20000);

  /**
   * דגימת הספירה הגלובלית.
   *
   * 🔴 **רצה גם כשהחלונית סגורה**, אחרת החיווי היה מופיע רק אחרי שפותחים,
   * וזה בדיוק ההפך מחיווי. הרענון עצמו זול: הבקשה מבקשת שורה אחת ומשתמשת
   * רק במונה.
   */
  async function pollWaiting() {
    if (!signedIn) return;
    const r = await send("WAITING", {});
    if (!r || !r.ok) return;
    const n = Number(r.waiting || 0);
    if (n === waitingCount) return; // בלי ציור מיותר
    waitingCount = n;
    // 🔴🔴 **ציור רך, כי זה עדכון רקע.** עידן, 25/08/2026: "הסמן בחיפוש
    // מידי פעם מאבד את השדה." זה בדיוק "מידי פעם": הדגימה רצה כל
    // שישים שניות, ורק כשהמונה **משתנה** היא ציירה מחדש והרגה את
    // המיקוד באמצע הקלדה. מספר על תג אינו סיבה לקטוע מישהו שכותב.
    render(true);
  }

  /**
   * 🔴🔴 **שומר נוכחות: החלונית חוזרת אם המסמך נבנה מחדש מתחתיה.**
   *
   * עידן (24/08/2026): "בכניסה הראשונה למערכת הכפתור לא לחיץ, אחרי קצת
   * שוטטות בפריוריטי אפשר ללחוץ עליו." פריוריטי היא אפליקציה שמרנדרת את
   * עצמה אחרי שהתוסף כבר הוזרק, וכל החלפת מסך אצלה יכולה לנתק את
   * החלונית מהמסמך. מנותקת פירושו: קיימת במשתנה, לא על המסך, ולא לחיצה.
   *
   * ⭐ הבדיקה זולה (`contains` על צומת אחד) והתיקון הוא ציור אחד. בלי
   * זה החזרה תלויה במקרה, כלומר במעבר שורה שבמקרה מפעיל ציור, וזה בדיוק
   * ה"שוטטות" שעידן תיאר.
   */
  setInterval(() => {
    if (Date.now() < hiddenUntil) return;
    if (!host || !document.body.contains(host)) render();
  }, 2000);

  setInterval(() => { pollWaiting().catch(() => {}); }, 60000);
  setTimeout(() => { pollWaiting().catch(() => {}); }, 1500);

  console.log("[RashalWA] v" + VERSION + " פעיל.");
})();
